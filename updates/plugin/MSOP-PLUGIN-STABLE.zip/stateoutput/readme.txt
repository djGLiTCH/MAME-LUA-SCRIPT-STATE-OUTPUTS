================================================================================
MAME State Output Project (MSOP)
MSOP Plugin Readme
================================================================================

Plugin Version: 9.4.1
Plugin Date:    2026.10.14
Database Date:  2026.10.14
Created By:     Jacob Simpson (DJ GLiTCH)
License:        GNU General Public License GPL-v3.0
Repository:     https://github.com/djGLiTCH/MAME-LUA-SCRIPT-STATE-OUTPUTS
Contributors:   Muggins (tester), Hexxed (ideas), Bandicoot (tester),
                PolybiusExtreme (feedback), Argon (inspiration)
Special Thanks: Boomslangnz (FFB Arcade Plugin) and Endprodukt
                (FFBPluginRacerMAME), whose GPL v3.0 drive-board protocol
                research underpins the racing force feedback decoders

--------------------------------------------------------------------------------
OVERVIEW
--------------------------------------------------------------------------------

The MAME State Output Project or MSOP for short (previously known as the
Universal MAME Lua Script for State Outputs) is a robust solution designed to
enhance the MAME arcade emulation experience. It provides real-time state
outputs (derived from in-game state events or created in real-time based on
logic that adapts various in-game state events), enabling advanced features
like force feedback, light gun hardware support, dynamic lighting, and more.
It is highly recommended that you use MESH (Modern Emulator State Hub) - formerly the MSOP Configurator - to manage the
MSOP Plugin, as this allows automatic configuration and simplifies updates.

--------------------------------------------------------------------------------
HOW IT WORKS
--------------------------------------------------------------------------------

The plugin operates by monitoring specific memory address values within MAME 
to track game states and applies various logic to derive accurate state outputs.

* Logic Priority: The plugin utilises a sophisticated priority hierarchy to 
  ensure accurate hardware behaviour. It evaluates Player Specific Status 
  first, followed by Global Game Status, and finally applies fallback logic 
  to ensure the hardware never enters an undefined state.

* Data Handling: The plugin converts internal MAME memory values into
  actionable signals. Specifically, it tracks key events - such as ammo changes
  (recoil and/or reload), life changes (damage), lamp states (such as player
  start), and many more, to trigger external hardware response (e.g. force
  feedback, lighting, display counters, etc.).

* Variable Management: To maintain stability, the plugin employs dedicated 
  variables for distinct game states, ensuring that inputs from one player do 
  not interfere with the feedback of another.

--------------------------------------------------------------------------------
REQUIREMENTS & COMPATIBILITY
--------------------------------------------------------------------------------

* IMPORTANT: This plugin exclusively supports standalone MAME. RetroArch (and 
  its MAME cores) are NOT supported due to differences in how cores are handled.

This plugin is designed to interface with third-party "hooker" software to 
translate state outputs into physical hardware actions (force feedback, LEDs, 
etc.). Compatible software known to work with these outputs includes:

* Hook of the Reaper (by 6Bolt): https://github.com/6Bolt/Hook-Of-The-Reaper
* MAMEhooker (by Howard Casto): https://dragonking.arcadecontrols.com/static.php?page=aboutmamehooker
* OutputHooker (by PolybiusExtreme): https://github.com/PolybiusExtreme/OutputHooker
* QMamehook (by SeongGino): https://github.com/SeongGino/QMamehook

Hook of the Reaper (HOTR) remains the recommended external hooker for a
plug-and-play light gun setup. If you prefer the MAMEhooker-family tools
(MAMEhooker, OutputHooker, QMamehook), the MESH app (Modern Emulator State
Hub - formerly the MSOP Configurator) generates and maintains their per-game
ini command files automatically from your configured hardware profiles - no
hand-written inis required. MESH can also drive light guns and LED lighting
itself (its built-in Player Hardware Commands and Native LED Control
engines), so an external hooker program is entirely optional.

--------------------------------------------------------------------------------
HOW MSOP DELIVERS ITS OUTPUTS (AND WHY MESH MATTERS)
--------------------------------------------------------------------------------

MAME 0.289 removed the ability for a Lua plugin to CREATE outputs. MSOP can still
read MAME's existing (driver-created) outputs, but it can no longer hand its own
outputs to MAME for broadcasting. Everything MSOP produces - recoil, ammo, life,
lamps, the derived Clip flag - therefore has to leave MAME over MSOP's own TCP
relay connection instead.

That relay needs something listening on the other end. This is what MESH provides.

WITH MESH (recommended)
  * Works on EVERY MAME version, 0.200 through 0.289+, because MESH hosts the
    relay MSOP dials into.
  * MESH speaks MAME's own network-output protocol, so any hooker program
    connects to MESH exactly as it would to MAME - nothing about the hooker
    changes.
  * MESH can also drive your hardware directly (its Native LED Control and
    Native Peripheral Control engines), so a hooker program is optional.
  * MESH compiles and distributes each hooker's per-game ini files for you.
  * MESH receives MSOP's outputs on its own dedicated, private ingest port and
    manages port 8000 for everything else - reading it when MAME's own network
    server is broadcasting there, and serving hooker programs on it whenever a
    relay session is live. Hooker programs keep connecting to 8000 exactly as
    they always have; nothing about the hooker changes.

OUTPUT DELIVERY BY MAME VERSION
  Where each kind of output is delivered, for every MAME output setting:

  +-------------+---------------------+--------------+--------------+----------+
  | MAME        | MAME OUTPUT         | MSOP         | NATIVE       | MESH     |
  |             |                     | OUTPUTS      | OUTPUTS      | REQUIRED |
  +-------------+---------------------+--------------+--------------+----------+
  | 0.200-0.288 | none, console, auto | Relay (8004) | Relay (8004) | Yes      |
  | 0.200-0.288 | network             | MAME (8000)  | MAME (8000)  | No       |
  | 0.200-0.288 | windows             | MAME (Win32) | MAME (Win32) | No       |
  +-------------+---------------------+--------------+--------------+----------+
  | 0.289+      | none, console, auto | Relay (8004) | Relay (8004) | Yes      |
  | 0.289+      | network             | Relay (8004) | MAME (8000)  | Yes      |
  | 0.289+      | windows             | Relay (8004) | MAME (Win32) | Yes      |
  |             |                     |              | and relay    |          |
  +-------------+---------------------+--------------+--------------+----------+

  MSOP OUTPUTS are what the plugin produces for a game with an MSOP profile
  (recoil, ammo, life, game status and so on). NATIVE OUTPUTS are the ones
  MAME's own driver creates (lamps, LEDs, a game's own recoil output), and they
  are delivered for every game, with or without a profile, except a game whose
  profile is switched off with ENABLE_ROM.

  "Relay (8004)" means the plugin sends the outputs to MESH on 127.0.0.1:8004 by
  default, and MESH passes them on to your hardware and hooker programs. "MAME
  (8000)" is MAME's own network output server on port 8000, and "MAME (Win32)"
  is MAME's Windows message output. "auto" is MAME's factory default and MAME
  treats it as "none".
  "MESH REQUIRED" says whether MESH must be running for that setting to deliver
  the outputs. MESH works with every setting in the table; where it says No,
  MAME delivers the outputs itself and MESH can still read them. For 0.289 and
  later, "none" is the recommended setting.

  * 0.289+ with "network": MSOP shows a one-shot INCORRECT OUTPUT MODE notice. A
    hooker program reading MAME's port 8000 directly receives the native outputs
    only.
  * 0.289+ with "windows": this works with MESH, and MSOP shows a short one-shot
    note. A program that only reads MAME's Windows messages, such as MAMEhooker,
    receives the native outputs only; to send it MSOP's outputs as well, use
    "none" and enable "Serve Win32 output" in MESH.
  * Native outputs over the relay on 0.288 and earlier need MSOP Plugin v9.4.0
    or newer.
  * Up to and including MAME 0.289 the plugin finds native outputs in the output
    tables shipped with it; from MAME 0.290 it asks MAME which outputs the
    running game has.

WHICH PORT MSOP USES
  When the relay is in use, MSOP dials MESH's MSOP ingest listener on
  127.0.0.1:8004. That is a private port dedicated to this one job - MSOP never
  binds or dials port 8000 in any mode. Port 8000 stays exactly what it has
  always been: MAME's own '-output network' server (on builds that broadcast
  natively), or the hooker-facing side that MESH manages. MESH can move the
  ingest port per install by writing a "relayport" member into this plugin's
  plugin.json; that stamp always wins over the 8004 default. A hand-installed
  plugin needs no configuration at all - the default just works.

  When the relay is NOT in use (MAME 0.288 or earlier set to '-output network'
  or '-output windows'), MSOP opens no socket of any kind: MAME itself creates
  and broadcasts every output, MSOP's included.

HOW MSOP FINDS A GAME'S NATIVE OUTPUTS TO FORWARD
  With '-output none' or '-output console' (the recommended relay setup), MAME's own
  output modules never broadcast the game's native outputs (lamp0, Player1_Gun_Recoil,
  P1_Start_lamp, ...). MSOP forwards them itself over the relay so nothing is lost -
  including for games MSOP has no profile for. It gets the list of names two ways, and
  always prefers the first:

  1. LIVE ENUMERATION (preferred; MAME builds that expose the 'device.outputs'
     property - stock MAME 0.290 and later, where the feature proposed as
     mamedev/mame PR #15745 landed upstream). MSOP asks the running machine which
     outputs it has actually created and forwards exactly those - no lookup tables,
     always current, and correct even for a game nobody ever pre-scanned. It only
     READS the output list and creates nothing. On any build without it, MSOP
     silently falls back to (2).

  2. SHIPPED LOOKUP FILES (fallback; MAME 0.289 and earlier - note that official
     0.289, despite removing output creation, does not yet provide the
     'device.outputs' property, so it relies on these files). Two optional files
     sit in the stateoutput folder beside database.lua:
       * native_outputs_by_rom.lua    - native output names keyed by ROM, scanned for
                                        the games MSOP supports. The more specific of the
                                        two (it can include layout-derived names).
       * native_outputs_by_driver.lua - native output names keyed by MAME driver source
                                        file, scanned across the whole driver tree, so one
                                        entry covers every ROM (and clone) that driver
                                        builds. This is what lets an UNSUPPORTED game
                                        still forward its natives.
     A supported ROM uses its by_rom entry; an unsupported ROM falls back to its driver's
     by_driver entry. Both are regenerated by the compiler (msop_native_outputs_compiler.py)
     - never hand-edit them. If they are absent, nothing breaks: MSOP still delivers its
     own outputs, and unsupported games simply produce nothing extra.

  Either way the result is the same stream: the one relay connection carries BOTH the
  custom MSOP_ outputs and the game's native ones - so MSOP can be the single source
  of every state output, and MESH serves the merged stream to hooker programs on port
  8000 as usual. To forward a name no discovery route can see (e.g. another
  script's own output), list it per game in the database's ADDITIONAL_OUTPUT_FORWARDS; it
  is always honoured on top, whichever route above supplied the rest.

  Native forwarding is deliberately NOT done while MAME's own '-output network' server
  is running: MAME is already broadcasting those same natives on 8000, so forwarding
  them again over the relay would deliver each one twice to anything reading both
  ports.

  With '-output windows' on MAME 0.289 and later, the natives are forwarded over
  the relay as well as sent by MAME as Windows messages. MESH takes each one
  from MAME's own messages, so its devices and programs reading port 8000
  receive every output once.

  Cost: negligible. Forwarding is a cached read per known name per frame with no
  allocation, and a value is only ever put on the wire when it CHANGES. Measured on
  Point Blank 2 (28 candidate names) it was within about 1% of running with forwarding
  off entirely - 430% vs 435% of realtime with throttling off.

WHEN IS THE RELAY USED AT ALL?
  MSOP asks the running build whether it can create a custom output - the legacy
  output.set_value route, tested for real rather than
  guessed from a version number. If that route does not work, MAME can hold none of
  MSOP's outputs and therefore cannot broadcast them in ANY output mode, so the
  relay is the only delivery path and is switched on regardless of the setting.
  A build that reports MAME 0.289 or later is treated as relay-only as well.
  The check is on capability first and version second: custom and
  pre-release builds can report a version that does not match their behaviour, and
  guessing from the number alone left '-output windows' silently undelivered.

  EXPECTED CONSOLE MESSAGE. That probe runs in MAME's console. When the first game of a
  session starts it first prints an explicit "COMPATIBILITY TEST" line saying it is about to check whether
  this build can create state outputs, then makes the test call. On MAME 0.289 and newer,
  MAME answers with its OWN error/warning about an unknown output on the very next line -
  that message is EXPECTED, is not a fault in MSOP or the game, and is immediately followed
  by MSOP's own line confirming the result and that it has switched to relay delivery. On
  MAME 0.288 and earlier the test passes quietly and no such error appears.

IF NOTHING IS LISTENING ON THE RELAY PORT
  MSOP dials the relay; it never waits for one. A FAILED dial is not always cheap:
  on a machine that answers properly it is refused in well under a millisecond, but
  where local firewall or security software silently drops loopback connection
  attempts instead of refusing them outright, the operating system waits out its
  retransmit first - about 2 seconds, measured - and MAME's socket open is a plain
  blocking call with no timeout setting, so that pause freezes emulation until it
  returns. For that reason the number of attempts is strictly BOUNDED, timed on a
  real clock, with every attempt after the first announced on screen:

  COLD START (MESH has never answered this session):
      attempt 1  at ROM start, where the pause is hidden inside loading  - silent
      attempt 2  10 seconds later - if it fails, "MESH IS NOT RUNNING" appears and
                 announces one final attempt
      attempt 3  30 seconds after that - if it fails, "MESH NOT FOUND - STATE
                 OUTPUTS PAUSED" appears and MSOP stops dialling for the session

  LOST CONNECTION (MESH was connected and disconnected mid-game):
      "MESH DISCONNECTED" appears the moment the drop is detected, announcing one
      reconnect attempt 30 seconds later - if it fails, "MESH RECONNECT FAILED -
      STATE OUTPUTS PAUSED" appears and MSOP stops dialling for the session

  Reconnecting after MSOP has stopped dialling costs one deliberate action: after
  starting MESH, pause and unpause the game (the attempt runs at the moment of
  unpause), perform a soft reset, load a new ROM,
  or simply restart MAME. Cold start versus lost connection is judged per MAME
  session, not per ROM: until MESH has connected once, every ROM start begins a
  fresh cold sequence; once MESH has connected, any later failure - in any ROM -
  follows the lost-connection path with its single announced reconnect attempt. A
  successful connection at any point shows "MESH CONNECTED" if a problem was
  previously reported, and a game MSOP has nothing to deliver for (no profile and
  no native outputs to mirror) stops silently after the single ROM-start attempt.

  All of these on-screen (OSD) messages - including the "INCORRECT OUTPUT MODE"
  notice described below - can be disabled by setting ENABLE_OSD_CONNECTION_STATUS
  to false in the database's _default block; the matching console messages always
  print regardless, so logs stay complete. They are deliberately separate from the
  debug-gated diagnostics messages: connection problems are shown to every user,
  diagnostics only when enabled.

  RECOIL SAFETY DELAY. MSOP sends recoil outputs at each game's own rate, which
  for some games is faster than ten pulses a second (Crisis Zone fires about 20
  shots a second). The program driving your lightgun is responsible for
  protecting its solenoid. If nothing in your setup limits the rate, set
  ENABLE_RECOIL_SAFETY_DELAY to true in the database's _default block and no game
  will send recoil pulses closer together than RECOIL_SAFETY_DELAY_MS (100 by
  default). It applies to both the pulse interval (MIN_RECOIL_INTERVAL_MS) and
  the hold interval (RECOIL_HOLD_MS).

  INCORRECT OUTPUT MODE. On a MAME build that cannot create MSOP's outputs (0.289
  and above), the relay is the only delivery path in EVERY '-output' mode - so if
  such a build is set to '-output network', MSOP shows a one-shot notice
  recommending '-output none', since that mode only delivers MSOP's outputs
  natively on MAME 0.200 - 0.288 and external hooker programs may otherwise not
  receive them. '-output windows' is supported with MESH and shows a shorter note
  instead: MAME sends the game's native outputs as Windows messages while MSOP's
  own outputs reach MESH over the relay, and MESH reads both. Programs that only
  read MAME's Windows messages, such as MAMEhooker, receive the native outputs
  only in this mode; to send them MSOP's outputs as well, set '-output none' and
  enable "Serve Win32 output" in MESH. Note that '-output auto' (MAME's factory default) is
  resolved by MAME itself to the "none" output module - MSOP treats it as "none",
  it uses the relay as normal, and it never triggers this notice.

  If you are not using the relay at all, set '-output network' on MAME 0.288 or
  earlier and MSOP will not dial anything.

WITHOUT MESH (MSOP + a hooker program only)
  * MAME 0.200 - 0.288 ONLY, and MAME must be set to '-output network' (or
    '-output windows'). In that configuration MAME creates and broadcasts MSOP's
    outputs itself, and your hooker connects to MAME directly. This works well
    and needs nothing else installed.
  * On MAME 0.289+ this arrangement CANNOT work. MAME will not create MSOP's
    outputs, so it has nothing to broadcast, and MSOP's relay has nobody to dial.
    You would see the game's own native outputs (lamps, recoil lines the driver
    creates) but NONE of MSOP's - no ammo, no life, no derived recoil or reload.
  * You also give up the per-game ini generation, the supported-games list, the
    plugin/database updater, and the diagnostics MESH provides.

THE PORT ARRANGEMENT, IN ONE LINE
  MSOP feeds MESH on a private ingest port (8004) that nothing else contests;
  port 8000 remains what every hooker program expects it to be - MAME's own
  output server when MAME is broadcasting, or MESH serving the merged stream
  (MSOP's outputs plus forwarded natives) whenever a relay session is live.
  Whoever connects to 8000 always sees the richest stream available; MESH
  exists to make sure of it.

--------------------------------------------------------------------------------
OUTPUT MAPPINGS (MAMEhooker, OutputHooker, and QMamehook)
--------------------------------------------------------------------------------

For now, you can use the following Outputs in your per game ini file which will 
work across all supported games. Every output MSOP creates is prefixed with 
"MSOP_" to keep it distinct from outputs the game's own driver or MAME's core 
may already register under the same short name (e.g. a raw "Credits" or 
"Status" output belonging to something else entirely) - make sure your hooker 
software's mapping file uses the full prefixed name below, not the short name.
The three DemulShooter names (PX_CtmRecoil, PX_Damaged and PX_CtmLmpStart) are
the only outputs without the prefix.

Two tables are provided below depending on what you're building:

- CONDENSED: outputs that trigger a physical reaction (recoil, reload, lamps,
  rumble, the hit-detection pulse). Use this if you're wiring up force
  feedback or lighting hardware and don't need the informational values.
- COMPLETE: every output MSOP can produce, including the condensed set plus
  informational values (ammo, life, credits, status flags, shot/damage
  counters, plugin metadata) for building displays, logging, or scoring.

Not every output in either table will be available for every supported game -
each ROM's database entry determines which of these it actually drives. The 
condensed set is the one most consistently supported across the ROM list.

--------------------------------------------------------------------------------
CONDENSED (force feedback / physical reaction triggers)
--------------------------------------------------------------------------------

[Output]
MSOP_P1_LampStart=
MSOP_P1_Recoil=
MSOP_P1_Reload=
MSOP_P1_Rumble=
MSOP_P2_LampStart=
MSOP_P2_Recoil=
MSOP_P2_Reload=
MSOP_P2_Rumble=
P1_CtmLmpStart=
P1_CtmRecoil=
P1_Damaged=
P2_CtmLmpStart=
P2_CtmRecoil=
P2_Damaged=

Note 1: PX = Player Number (e.g. P1 = Player 1)
Note 2: MSOP currently supports up to 4 players, so the above outputs extend to P4.
Note 3: Recoil can be MSOP_PX_Recoil or PX_CtmRecoil (with demulshooter compatibility)
Note 4: Damage can be MSOP_PX_Damage or PX_Damaged (with demulshooter compatibility)

--------------------------------------------------------------------------------
COMPLETE (all outputs: triggers plus informational values)
--------------------------------------------------------------------------------

[Output]
MSOP_Credits=
MSOP_GameStatus=
MSOP_AttractStatus=
MSOP_GlobalCreditsInserted=
MSOP_Plugin_Version=
MSOP_Plugin_Date=
MSOP_Database_Date=
MSOP_ROM_ID=
MSOP_P1_LampStart=
MSOP_P1_Recoil=
MSOP_P1_Reload=
MSOP_P1_Rumble=
MSOP_P1_Damage=
MSOP_P1_DamageTaken=
MSOP_P1_Credits=
MSOP_P1_Status=
MSOP_P1_StatusAlt=
MSOP_P1_Life=
MSOP_P1_LifeAlt=
MSOP_P1_LifeLost=
MSOP_P1_Ammo=
MSOP_P1_Clip=
MSOP_P1_AmmoAlt=
MSOP_P1_AmmoGrenade=
MSOP_P1_ShotsFired=
MSOP_P1_ShotsFiredPrimary=
MSOP_P1_ShotsFiredAlt=
MSOP_P1_ShotsFiredGrenade=
MSOP_P1_CreditsInserted=
MSOP_P1_CreditsConsumed=
MSOP_P2_LampStart=
MSOP_P2_Recoil=
MSOP_P2_Reload=
MSOP_P2_Rumble=
MSOP_P2_Damage=
MSOP_P2_DamageTaken=
MSOP_P2_Credits=
MSOP_P2_Status=
MSOP_P2_StatusAlt=
MSOP_P2_Life=
MSOP_P2_LifeAlt=
MSOP_P2_LifeLost=
MSOP_P2_Ammo=
MSOP_P2_Clip=
MSOP_P2_AmmoAlt=
MSOP_P2_AmmoGrenade=
MSOP_P2_ShotsFired=
MSOP_P2_ShotsFiredPrimary=
MSOP_P2_ShotsFiredAlt=
MSOP_P2_ShotsFiredGrenade=
MSOP_P2_CreditsInserted=
MSOP_P2_CreditsConsumed=
P1_CtmLmpStart=
P1_CtmRecoil=
P1_Damaged=
P2_CtmLmpStart=
P2_CtmRecoil=
P2_Damaged=

An output is sent only by a game whose profile uses it, starting at 0 when the
game starts - this keeps your hooker software free of names that ROM never
uses. The exceptions are the global outputs (MSOP_GameStatus,
MSOP_AttractStatus and the three MSOP_Lua outputs), which every game sends, and
PX_CtmRecoil, PX_Damaged and MSOP_PX_ShotsFired, which every light gun game
sends unless DemulShooter compatibility or the shot count is switched off.

Note 1: PX = Player Number (e.g. P1 = Player 1)
Note 2: MSOP currently supports up to 4 players, so the above outputs extend to P4.
Note 3: Recoil can be MSOP_PX_Recoil or PX_CtmRecoil (with demulshooter compatibility)
Note 4: Damage can be MSOP_PX_Damage or PX_Damaged (with demulshooter compatibility)

RACING / FORCE FEEDBACK OUTPUTS:

Racing-genre games emit a dedicated force feedback vocabulary instead of the
gun set. The plugin reads the game's raw force-feedback command (a native
driver output, or an emulated memory address - the same acquisition model as
the gun games), decodes the game-specific encoding inside the plugin, and
re-emits it as standardised effect channels that any consumer (MESH, or a
hooker program) can map onto real hardware with zero game knowledge. The
game-specific decoding draws on protocol research from the FFB Arcade
Plugin projects (see Special Thanks above); the vocabulary, delivery and
acquisition model are MSOP's own. The standardised channels are:

MSOP_P1_FFB_Constant=
MSOP_P1_FFB_Spring=
MSOP_P1_FFB_Friction=
MSOP_P1_FFB_Damper=
MSOP_P1_FFB_Sine=
MSOP_P1_FFB_Rumble=
MSOP_P1_FFB_Raw=
MSOP_P1_FFB_Collision=
MSOP_P1_FFB_GearChange=
MSOP_P1_FFB_SurfaceRumble=
MSOP_P1_FFB_TyreSlip=
MSOP_P1_FFB_EngineRumble=

* Stream channels persist until changed; an explicit 0 releases them.
  FFB_Constant is signed -255..+255 (positive = force from the right, i.e.
  wheel pushed left); FFB_Spring, FFB_Friction, FFB_Damper, FFB_Sine, and
  FFB_Rumble are 0..255. FFB_Raw is the undecoded source value (diagnostics).
* Semantic events (FFB_Collision, FFB_GearChange, FFB_SurfaceRumble,
  FFB_TyreSlip, FFB_EngineRumble; 0..255, pulse/level style) are optional per
  game, read from separate per-game memory addresses, and appear only for
  games whose database entry configures them.
* FFB_Rumble is a CONTINUOUS force-correlated motor level and deliberately
  coexists with the pulse-style PX_Rumble - a consumer with a single rumble
  path should mix the two by MAX, never sum.
* Every game's database entry now carries a GAME_TYPE (lightgun default /
  racing / both): racing games emit only the FFB vocabulary (plus the global
  outputs) and skip the gun pipeline entirely, and gun games never emit FFB
  names. The racing game profiles are in the beta channel database.

--------------------------------------------------------------------------------
MESH APP (FORMERLY MSOP CONFIGURATOR): TUTORIAL & USAGE
--------------------------------------------------------------------------------

The MESH app is designed to streamline the installation and
maintenance of your plugin files and configuration database.

1. Initial Setup: Launch the MESH app. You will be prompted to select 
   your standalone MAME directory.
2. Output Selection: Optionally choose an external "hooker" program so the
   app can map the output integrations - or configure none and let MESH's
   built-in engines drive your hardware directly.
3. Channel Selection: Choose between the "Stable" or "Beta" release channels 
   (see details below, 'Stable' is highly recommended).
4. Install/Update: Run the update process to automatically download the latest 
   database mappings and copy the necessary plugin files directly into your MAME 
   folder and update your "hooker" program with command mappings if supported.

Beta vs. Stable Plugin Channels:
* Stable: The recommended track for most users. These releases have been 
  thoroughly tested for reliable force feedback and hardware compatibility.
* Beta: The bleeding-edge track. This includes newly supported games, 
  experimental features, and recent bug fixes. Use this if you want to test 
  the newest additions or help the community identify bugs.

--------------------------------------------------------------------------------
MESH APP: COMMAND LINE USAGE
--------------------------------------------------------------------------------

For advanced users and arcade cabinet front-ends, the MESH app can be
executed silently via the command line. This is particularly useful for scripting 
automated plugin updates before launching a game.

Available commands include:

-update
The recommended command. This checks for a MESH app update first.
If found, it silently updates the app, restarts itself, and
seamlessly chains into updating your MAME State Output Plugin and Hooker
configurations both silently and automatically.

-updateplugin
Bypasses MESH app update checks and exclusively updates your MAME
State Output Plugin files and Hooker configurations to match your currently
selected release channel.

-updateapp (or: -updateconfigurator)
Exclusively checks for and installs updates to the MESH app itself (the
-updateconfigurator alias is kept for older scripts).

The full headless suite goes further: -compileinis, -compiledatabase,
-fetchcontent, -verifyinstall, -checkhealth, plus live-control commands for a
running app (-led, -peripherals, -event, -shutdown). Run the executable with
-help for the complete reference.

--------------------------------------------------------------------------------
UPDATES & MAINTENANCE
--------------------------------------------------------------------------------

To ensure your arcade setup remains compatible with the latest game ROMs and 
MAME updates, please run the MESH app regularly.

Updating the Plugin:
Using the MESH app ensures you have the latest memory address mappings, bug 
fixes, and feature enhancements. It is recommended to check for updates every 
time you add new hardware or perform significant maintenance on your arcade 
cabinet, or perhaps want to check if support has been added for a new game ROM.
You can install, update, or uninstall the MSOP Plugin using the buttons on the
Home page of the MESH app.

Updating the MESH App:
When a new version of the MESH app itself is released (such as UI updates 
or new features), you will be prompted to download the update automatically
when you next open the app and are
connected to the internet.
It is worth checking the project GitHub to make sure no automatic update
changes were made that broke previous methods used to automatically update.

--------------------------------------------------------------------------------
COMMUNITY CONTRIBUTIONS
--------------------------------------------------------------------------------

If you would like to contribute to the project, such as improving the plugin 
(optimisations and/or feature enhancements), adding support for new games, or
revising existing games to fix bugs and/or add new features, please visit the
official GitHub repository linked above.

--------------------------------------------------------------------------------
TECHNICAL SUPPORT
--------------------------------------------------------------------------------

No technical support is guaranteed to be provided, however, if you believe you 
have identified a bug or encountered an issue that is directly related to this 
plugin, then please raise an issue in the official GitHub repository linked 
above.

--------------------------------------------------------------------------------
DISCLAIMER
--------------------------------------------------------------------------------

This software is provided "as is", without warranty of any kind. This application
and its associated plugin are not officially affiliated with or endorsed by the
MAME development team or any specific arcade hardware manufacturer.

--------------------------------------------------------------------------------

Copyright (c) 2026 by Jacob Simpson (DJ GLiTCH)