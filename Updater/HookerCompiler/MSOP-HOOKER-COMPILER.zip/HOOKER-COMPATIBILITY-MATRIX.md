# Hooker Program Compatibility Matrix

**Policy:** the MSOP Hooker Compiler targets the **MAMEhooker-family INI dialect** — the
subset understood by MAMEhooker, OutputHooker, QMamehook, and any future hooker program that
consumes the same `gamename.ini` format. Hook Of The Reaper (HOTR) is **not** an INI target:
HOTR drives light guns through its own per-gun *default LG* files (`.hor`), and a separate
compiler for those will be organised later. Anything marked "MSOP only" below is an extension
of MSOP Configurator's internal hooker engine and must not be relied on by exported INIs.

Sources (all verified against program source code or official documentation, 2026-07):
MAMEhooker 5.1 distribution (`docs/readme.txt`, `Command Reference.txt`,
`Settings/functions.ini` — the definitive 67-entry function list — plus `TweakFiles.txt`,
`displays/How to Make Display Files.txt`, sample `.mhs` scripts) · OutputHooker v1.6.0 source
(`core/OutputHookerCore.cpp`, `Global.h`) · QMamehook (SeongGino, `qhookermain.cpp`) ·
Hook Of The Reaper v1.3.1 source (`HookerEngine/HookerEngine.cpp`, `Global.h`) ·
MSOP Configurator native player-hardware engine (MainWindow.axaml.cs, Hardware/HookerScript.cs,
Hardware/DisplayFile.cs).

## INI command verbs

| Verb | Meaning | MAMEhooker 5.1 | OutputHooker 1.6 | QMamehook | HOTR 1.3.x (INI path) | MSOP Native |
|---|---|---|---|---|---|---|
| `cmo` | COM port open | Y | Y | Y | Y | **Y¹** |
| `cmc` | COM port close | Y | Y | Y | Y | **Y¹** |
| `css` | COM settings | Y | Y | N | Y | **Y¹** |
| `csl` | COM line ctrl (DTR/RTS) | Y | N | N | Y | N (not exposed by transports) |
| `cmr` | COM read → buffer | Y | Y | N | Y | N (transports are write-oriented) |
| `cmw` | COM write text | Y | Y | Y | Y | **Y** |
| `tsc` / `tsd` | TCP connect/disconnect | N | Y | N | N | **Y¹** |
| `tss` | TCP send | N | Y | N | N | **Y** |
| `udp` | UDP send | N | Y | N | N | **Y** (type 1 ASCII / 2 hex) |
| `hpr` | HTTP POST | N | Y | N | N | **Y** |
| `ghd` | Generic HID write | Y | Y | N | Y | **Y** |
| `nll` | Null command | Y (no-op) | Y (no-op) | N | Y (no-op) | **Y (pause!)³** |
| `wat` | Wait N ms | Y | N | N | N | **Y³** |
| `sbf ibf bmo` | Buffers + buffer math | Y | N | N | N | **Y** |
| `rfs lop lfs kls` | External `.mhs` scripts | Y | N | N | N | **Y** |
| `lds sds sdf` | Display artwork (2nd screen) | Y | N | N | N | **Y** |
| `ply pya` | Play wav (replace / queued) | Y | Y (`ply` only) | N | N | **Y** |
| `dsp dss` | DirectSound per-device wav | Y | N | N | N | **P⁵** |
| `cmd cdw` | Launch app (/and wait) | Y | N | N | N | **Y (opt-in)⁶** |
| `apl apc` | Launch app / close app | N | Y | N | N | **Y (opt-in)⁶** |
| `cpy kll` | Copy / delete file | Y | N | N | N | **Y (opt-in)⁶** |
| `lws lwp lwc lwr lwk` | LEDWiz | Y | Y | N | N | **Y (LED engine off)⁴** |
| `uls uli ulk` | Ultimarc PacDrive/PacLED64 | Y | Y | N | Y | **Y (LED engine off)⁴** |
| `ulf uld` | Ultimarc fade time / step delay | Y | N | N | N | N (MSOP fades host-side) |
| `ulc ulp` | Ultimarc onboard scripts (UHID) | Y | Y (`ulc`) | N | N | N (device-flash management) |
| `iws iwc iwr iwk` | IOWarrior | Y | N | N | N | N (discontinued hardware) |
| `mls mlc mlr mlk` | MaLa hardware | Y | N | N | N | N (discontinued hardware) |
| `lhs lhc lhr lhk` | LEDWiz-hack (IOW40) | Y | N | N | N | N (discontinued hardware) |
| `dff ffa ffb` | Force feedback / rumble | Y (`dff/ffa`) | Y (`ffb/ffa`) | N | N | **P (XInput best-effort)⁷** |
| `ffe fft` | FF effect/tweak files | Y | N | N | N | N (proprietary DirectInput format) |
| `xip / xia` | XInput rumble | Y | N | N | N | **Y (Windows)⁷** |
| `wii` | Wiimote LEDs/rumble | Y | N | N | N | N (needs BT pairing stack) |
| `lpt lpe` | Parallel port | Y | N | N | N | N (kernel port driver) |
| `kbd` | Keyboard LEDs | Y | N | N | N | **Y (Windows, keypress mechanism)** |
| `spk` | Text-to-speech | Y | N | N | N | **Y (OS voice: SAPI / say / spd-say)** |
| `lwa` | LedWiz LWA animation files | Y | N | N | N | N (convert to `.mhs`) |
| `smp` | Multipliers | Y | N | N | N | N (`bmo` covers it) |
| `ref` | Refresh devices | Y | N | N | N | **Y (roster refresh)** |
| `log qut` | MH app management | Y | N | N | N | N (MSOP has its own)⁸ |

Notes:

¹ `cmo`/`css` map to "connect that COM port's player device now" (MSOP owns baud from
Devices → Configuration; a differing baud in the INI is logged, not applied); `cmc`
disconnects it. `tsc`/`tsd` remain roster-managed.

² UDP endpoints belong to MSOP's LED Controller entries, not ad-hoc INI writes.

³ **Pacing:** `nll <ms>` is a no-op in every external hooker; MAMEhooker's real delay verb
`wat` is MAMEhooker-only (and errors OutputHooker's INI validator). Inter-command pacing is
therefore NOT portably expressible in an INI. MSOP honours BOTH `nll <ms>` and `wat <ms>` as
sequential-queue pauses and additionally enforces the per-player Solenoid Delay at runtime.
Exported INIs must only ever contain `nll`.

⁴ LED board verbs execute natively (LEDWiz SBA/PBA output reports, PacDrive 16-bit-mask and
PacLED64 per-port-intensity feature reports — the same source-verified wire formats the LED
engine speaks; LEDWiz unit N = PID 0x00F0+N-1, Ultimarc device N = the Nth 0xD209 unit) —
**but only while Native LED Control is OFF**. When the LED engine runs it owns the boards
(two writers would corrupt the device shadows), so the verbs skip with a note; map the board
on Devices → LED Controllers instead and every game gets effects, priorities, game colours
and hand-over that the INI verbs can't express. `ulc/ulp/uld` (onboard flash scripts) stay
unsupported.

⁵ `dsp` plays the file with the loop flag honoured, on the **default** audio device —
MAMEhooker's per-device routing, volume and balance use DirectSound sessions that have no
cross-platform equivalent. `dss` stop/replay works fully.

⁶ `cmd`/`cdw`/`cpy`/`kll` execute programs and touch the filesystem, so they sit behind the
off-by-default **Allow App & File Commands** toggle (Devices → Configuration). `cdw` waits on
the sequential worker, like MAMEhooker. The `windowstate` argument is accepted and ignored
(window styles are OS-specific).

⁷ Rumble runs through XInput (Windows; graceful no-op elsewhere): `xip`/`xia` natively,
`dff`/`ffa`/`ffb` as a best effort — most pads today are XInput, but MAMEhooker's DirectInput
joystick numbering and its x/y force offsets have no XInput equivalent (strength drives both
motors; durations honoured via per-pad auto-off timers). The two `ffa` dialects are told apart
by argument count (MAMEhooker 6, OutputHooker 5). True DirectInput wheels and `.ffe` files
remain unsupported.

⁸ `log` = MSOP's log exports (Diagnostics → Devices / State Outputs); `qut` would let an INI
exit the app (refused by design); `ref` is unnecessary (the roster refreshes automatically).

## Value tokens & dialect features

| Feature | MAMEhooker | OutputHooker | QMamehook | HOTR (INI) | MSOP Native |
|---|---|---|---|---|---|
| `%s%` current value | Y | Y | Y | Y | Y |
| `%s%` inside `ghd` bytes | ? (undocumented) | **Y — multi-`%s%` splits value into tens/units digits** | n/a | Y | Y (OutputHooker semantics) |
| `%b1%–%b10%` buffers | Y | N | N | N | **Y** |
| `%outputname%` cross-output | Y | N | N | N | **Y** |
| `%rom%` (+`%parent%`/`%driver%`) | Y | N | N | N | **Y (parent/driver ≈ rom)⁹** |
| `%comma%` literal comma | Y | N | N | N | **Y** |
| `_` = space in text variables | Y | N | N | N | **Y (cmw/tss/sbf/flags)** |
| Nested `%b%s%%` resolution | Y | N | N | N | **Y** |
| `%d1% %d0%` digit split | N | N | N | Y (default-LG layer) | N — use `ghd` multi-`%s%` instead |
| `D:<ms>` inline delay | N | N | N | Y (default-LG layer ONLY, not INIs) | N — never emit into INIs |
| `\|` value-indexed sections | Y | Y | Y | Y | Y |
| `,` multi-command | Y | Y | Y | Y | Y |
| `0xNN` + `"text"` byte strings in `cmw` | N (sent as literal text) | N (literal text) | N (literal text) | Y (default-LG layer only) | **Y (MSOP extension)⁵ᵇ** |

Notes:

⁵ᵇ MSOP's native engine detects a `cmw` payload consisting entirely of `0xNN` tokens and
quoted ASCII strings (the Xenas dialect) and encodes it to raw bytes before writing. The
dialect is checked BEFORE the underscore rule, so it is unaffected by it. External hookers
send such payloads as literal text — profiles using this dialect are flagged in their
Description and only fully work with MSOP native (or HOTR via default LG files).

⁹ MSOP doesn't track MAME parent/driver metadata per rom; `%parent%` and `%driver%` resolve
to the rom name (the closest stable identity — the same direction `%rpd%` falls back).

## INI file structure (MAMEhooker semantics MSOP honours)

| Feature | Behaviour in MSOP |
|---|---|
| `[Output]` / `[Outputs]` section | Both accepted (MAMEhooker writes `[Output]`, its readme documents `[Outputs]`). |
| `default.ini` + per-game ini layering | **Yes** — `GamesExportINI/default.ini` supplies every output/General entry the game's ini doesn't define; the game ini wins per key (MAMEhooker's exact rule). |
| `MameStart` / `MameStop` | Fired on game load / engine stop and game change. |
| `MameHookerStart` / `MameHookerStop` | Fired when the Peripheral Commands engine starts/stops (MSOP's equivalent of the hooker app starting/exiting); read from `default.ini`. |
| `StateChange` | Fired for EVERY output change, alongside the output's own script. |
| `OnPause` (legacy `Pause`) | Fired when the relay's `pause` output changes (the plugin broadcasts `pause = 1/0`). MAMEhooker's *implicit* "turn everything off on pause" sweep is NOT reproduced — bind `OnPause` explicitly. |
| `OnRotate` | Fired for outputs whose name starts with `Orientation`. |
| `[KeyStates]` + `RefreshSpeed` | **Not supported** — global key monitoring needs OS input hooks; MSOP reacts to state outputs only. Key-triggered actions belong in input tools (or MAME's own hotkeys). |
| Fire-on-every-change | Like MAMEhooker, a script fires whenever the value CHANGES (including on→off); use `\|` sections for per-state behaviour. Missing sections clamp to the last one instead of crashing (MSOP is more forgiving there). |

## Content folders (drop-in MAMEhooker packs)

MSOP's equivalent of the MAMEhooker program folder is the app-data **`GamesExportINI/`**
folder (enable *Prioritise Hooker INI Files* in Settings to make the files win over the
real-time compile):

```
GamesExportINI/
  default.ini            <- layered under every game ini
  <rom>.ini              <- the game inis (MSOP-compiled or MAMEhooker packs)
  scripts/<name>.mhs     <- rfs / lfs external scripts (BREAK + lop supported, expansion
                            capped at 5000 commands so a loop bomb can't wedge the queue)
  displays/<name>/<name>.dis  <- display artwork (+ its images; default.dis for shared
                                 layout geometry; %rom% and %rpd%->rom->"default" honoured)
  sounds/...             <- any path form works: absolute, or leading '\' = this folder
```

Display windows are borderless, topmost and non-activating (they never steal focus from the
game), positioned in raw desktop pixels exactly like MAMEhooker so negative coordinates reach
a monitor left/above the primary. `sdf` snapshots write PNG bytes regardless of the requested
extension. One display is open at a time; ROM change and engine stop close it.

## MSOP extension verbs (new features for INI authors)

MSOP-only vocabulary — **never emitted into exported INIs** (OutputHooker's validator errors
on unknown verbs; MAMEhooker logs a syntax error). Use them in user-authored INIs consumed by
MSOP's native engine:

| Verb | Syntax | What it does |
|---|---|---|
| `evt` | `evt <output> [value]` | Injects a state output into BOTH engines (lighting + peripherals) as if MAME sent it — chain standard effects (`evt P1_Damage 1` fires the damage flash and the gun's damage command) without hardware-specific commands. Loop-guarded (depth 3). |
| `osd` | `osd <duration_ms> <text>` | Transient on-screen text at the bottom-centre of the primary screen (topmost, never takes focus, auto-hides). Underscores become spaces: `osd 2000 LOW_AMMO!` |
| `hpr` | `hpr <url> [content-type] <body>` | HTTP POST (shared with OutputHooker/QMamehook dialects). |
| `0xNN "text"` byte dialect | inside `cmw` payloads | Raw serial bytes + quoted ASCII (see ⁵ᵇ). |

## Per-consumer notes

- **MAMEhooker 5.1** — the reference dialect. Windows-only. Richest scripting; `ghd` byte
  behaviour with `%s%` is undocumented, so digit displays are marked untested there.
- **OutputHooker 1.6** — closest to a superset for devices; adds the network verbs
  (`tsc/tss/udp/hpr`). Its INI validator shows an error dialog for unknown verbs, so exported
  INIs must never contain `wat`, `%d1%`, or `D:` tokens.
- **QMamehook** — serial-only and whitelisted (OpenFIRE `0xF143`, GUN4IR `0x2341`, Blamcon;
  RS3 needs manual whitelisting on Linux). `cmw` port numbers are player slots (detection
  order), not Windows COM numbers. Only `cmo/cmw/cmc` + `%s%`.
- **HOTR** — reads game INIs but ignores network verbs; guns are driven via its internal
  default-LG layer, which is where `%d` digits, `D:` delays, byte dialects, per-gun pacing
  (AimTrak 250 ms, Alien 40–65 ms, RS3 `Z0` 110/145 ms) and the redacted AimTrak recoil
  command live. HOTR support = the future default-LG compiler, not these INIs.
- **MSOP native engine** — executes the compiled INI (or the same content resolved in real
  time) with the Pass-29 MAMEhooker language layer: special variables (buffers, cross-output,
  rom/comma, underscore rule), `default.ini` layering, `[General]` lifecycle hooks, `.mhs`
  scripts, display artwork, sounds, and opt-in app/file commands. Honours `nll`/`wat` pauses,
  enforces Solenoid Delay recovery gaps, executes `ghd` via HidSharp, and drops stale queued
  commands (TTL) so bursts can't backlog. LED_* commands are consumed by the Lighting engine,
  never sent to guns. Every intentional skip logs a one-time reason referencing this file.
