--
-- MAME STATE OUTPUT DATABASE
-- Compiled from stateoutput\game_json folder
-- Last Modified Date (YYYY.MM.DD): 2026.05.27
-- Project: https://github.com/djGLiTCH/MAME-LUA-SCRIPT-STATE-OUTPUTS
-- License: GNU GENERAL PUBLIC LICENSE GPL-v3.0
-- Copyright (c) 2026 Jacob Simpson (DJ GLiTCH). All Rights Reserved.
--

local database = {
    ["_default"] = {
        ["LUA_VERSION"] = 816,
        ["LUA_DATE"] = 20260527,
        ["LUA_GAME"] = "Default Universal MAME State Output Lua Script Values",
        ["LUA_ROM_ID"] = 0,
        ["OFFSCREEN_RELOAD"] = false,
        ["LIGHTGUN_PATCH"] = false,
        ["SCREEN_FLASH"] = false,
        ["SCREEN_FLASH_MEMORY_ADDRESS"] = false,
        ["SCREEN_FLASH_DISABLE_VALUE"] = false,
        ["SCREEN_FLASH_RESTORE_VALUE"] = false,
        ["CPU_TAG"] = ":maincpu",
        ["MEMORY_SPACE"] = "program",
        ["CPU_TAGS"] = {
            ["SCREEN_FLASH"] = false,
            ["GLOBAL_ATTRACT_STATUS"] = false,
            ["GLOBAL_CREDITS"] = false,
            ["GLOBAL_GAME_STATUS"] = false,
            ["CREDITS"] = false,
            ["STATUS"] = false,
            ["STATUS_ALT"] = false,
            ["AMMO"] = false,
            ["AMMO_ALT"] = false,
            ["AMMO_GRENADE"] = false,
            ["LIFE"] = false,
            ["LIFE_ALT"] = false,
            ["RECOIL"] = false,
            ["RELOAD"] = false,
            ["DAMAGE"] = false,
            ["RUMBLE"] = false,
            ["LAMP_START"] = false,
            ["SHOTS_FIRED"] = false,
            ["SHOTS_FIRED_PRIMARY"] = false,
            ["SHOTS_FIRED_ALT"] = false,
            ["SHOTS_FIRED_GRENADE"] = false,
            ["LIFE_LOST"] = false,
            ["DAMAGE_TAKEN"] = false
        },
        ["MEMORY_SPACES"] = {
            ["SCREEN_FLASH"] = false,
            ["GLOBAL_ATTRACT_STATUS"] = false,
            ["GLOBAL_CREDITS"] = false,
            ["GLOBAL_GAME_STATUS"] = false,
            ["CREDITS"] = false,
            ["STATUS"] = false,
            ["STATUS_ALT"] = false,
            ["AMMO"] = false,
            ["AMMO_ALT"] = false,
            ["AMMO_GRENADE"] = false,
            ["LIFE"] = false,
            ["LIFE_ALT"] = false,
            ["RECOIL"] = false,
            ["RELOAD"] = false,
            ["DAMAGE"] = false,
            ["RUMBLE"] = false,
            ["LAMP_START"] = false,
            ["SHOTS_FIRED"] = false,
            ["SHOTS_FIRED_PRIMARY"] = false,
            ["SHOTS_FIRED_ALT"] = false,
            ["SHOTS_FIRED_GRENADE"] = false,
            ["LIFE_LOST"] = false,
            ["DAMAGE_TAKEN"] = false
        },
        ["STARTUP_DELAY_MS"] = 5000,
        ["STATUS_DEBOUNCE_MS"] = 34,
        ["CREDITS_CLEAR_TIMEOUT_SEC"] = 60,
        ["COINS_PER_CREDIT"] = 1,
        ["MAX_PLAYERS"] = 2,
        ["SIMULTANEOUS_PLAY"] = true,
        ["OUTPUT_SUFFIXES"] = {
            ["GLOBAL_LUA_VERSION"] = "LuaVersion",
            ["GLOBAL_LUA_DATE"] = "LuaDate",
            ["GLOBAL_LUA_ROM_ID"] = "LuaROMid",
            ["GLOBAL_CREDITS"] = "Credits",
            ["GLOBAL_GAME_STATUS"] = "GameStatus",
            ["GLOBAL_ATTRACT_STATUS"] = "AttractStatus",
            ["CREDITS"] = "Credits",
            ["STATUS"] = "Status",
            ["STATUS_ALT"] = "StatusAlt",
            ["AMMO"] = "Ammo",
            ["AMMO_ALT"] = "AmmoAlt",
            ["AMMO_GRENADE"] = "AmmoGrenade",
            ["LIFE"] = "Life",
            ["LIFE_ALT"] = "LifeAlt",
            ["RECOIL"] = "Recoil",
            ["RELOAD"] = "Reload",
            ["DAMAGE"] = "Damage",
            ["RUMBLE"] = "Rumble",
            ["LAMP_START"] = "LampStart",
            ["GLOBAL_CREDITS_INSERTED"] = "GlobalCreditsInserted",
            ["CREDITS_INSERTED"] = "CreditsInserted",
            ["CREDITS_CONSUMED"] = "CreditsConsumed",
            ["SHOTS_FIRED"] = "ShotsFired",
            ["SHOTS_FIRED_PRIMARY"] = "ShotsFiredPrimary",
            ["SHOTS_FIRED_ALT"] = "ShotsFiredAlt",
            ["SHOTS_FIRED_GRENADE"] = "ShotsFiredGrenade",
            ["DAMAGE_TAKEN"] = "DamageTaken",
            ["LIFE_LOST"] = "LifeLost"
        },
        ["DATA_WIDTHS"] = {
            ["SCREEN_FLASH"] = 8,
            ["GLOBAL_ATTRACT_STATUS"] = 8,
            ["GLOBAL_CREDITS"] = 8,
            ["GLOBAL_GAME_STATUS"] = 8,
            ["CREDITS"] = 8,
            ["STATUS"] = 8,
            ["STATUS_ALT"] = 8,
            ["AMMO"] = 8,
            ["AMMO_ALT"] = 8,
            ["AMMO_GRENADE"] = 8,
            ["LIFE"] = 8,
            ["LIFE_ALT"] = 8,
            ["RECOIL"] = 8,
            ["RELOAD"] = 8,
            ["DAMAGE"] = 8,
            ["RUMBLE"] = 8,
            ["LAMP_START"] = 8,
            ["GLOBAL_CREDITS_INSERTED"] = 16,
            ["CREDITS_INSERTED"] = 16,
            ["CREDITS_CONSUMED"] = 16,
            ["SHOTS_FIRED"] = 16,
            ["SHOTS_FIRED_PRIMARY"] = 16,
            ["SHOTS_FIRED_ALT"] = 16,
            ["SHOTS_FIRED_GRENADE"] = 16,
            ["LIFE_LOST"] = 16,
            ["DAMAGE_TAKEN"] = 16
        },
        ["MEMORY_ALIGNMENT"] = false,
        ["PLAYER_MEMORY_OFFSET"] = false,
        ["PLAYER_CREDIT_MEMORY_OFFSET"] = false,
        ["RECOIL_DURATION_MS"] = 40,
        ["RECOIL_ALT_DURATION_MS"] = 40,
        ["RECOIL_GRENADE_DURATION_MS"] = 80,
        ["RELOAD_DURATION_MS"] = 40,
        ["MIN_RECOIL_INTERVAL_MS"] = 100,
        ["RECOIL_HOLD_MS"] = 100,
        ["DAMAGE_DURATION_MS"] = 250,
        ["RUMBLE_DURATION_MS"] = 250,
        ["AMMO_OFFSET"] = false,
        ["AMMO_ALT_OFFSET"] = false,
        ["AMMO_GRENADE_OFFSET"] = false,
        ["AMMO_MAX"] = false,
        ["AMMO_ALT_MAX"] = false,
        ["AMMO_GRENADE_MAX"] = false,
        ["AMMO_THRESHOLD"] = 254,
        ["AMMO_ALT_THRESHOLD"] = 254,
        ["AMMO_GRENADE_THRESHOLD"] = 254,
        ["LIFE_OFFSET"] = false,
        ["LIFE_ALT_OFFSET"] = false,
        ["LIFE_MAX"] = false,
        ["LIFE_ALT_MAX"] = false,
        ["ATTRACT_STATUS"] = false,
        ["CREDITS"] = false,
        ["GAME_STATUS"] = false,
        ["ATTRACT_STATUS_ACTIVE_VALUE"] = false,
        ["GAME_STATUS_ACTIVE_VALUE"] = false,
        ["STATUS_ACTIVE_VALUE"] = false,
        ["STATUS_ALT_ACTIVE_VALUE"] = false,
        ["P1"] = {
            ["CREDITS"] = false,
            ["STATUS"] = false,
            ["STATUS_ACTIVE_VALUE"] = false,
            ["STATUS_ALT"] = false,
            ["STATUS_ALT_ACTIVE_VALUE"] = false,
            ["AMMO"] = false,
            ["AMMO_ALT"] = false,
            ["AMMO_GRENADE"] = false,
            ["LIFE"] = false,
            ["LIFE_ALT"] = false,
            ["RECOIL"] = "auto",
            ["RELOAD"] = "auto",
            ["DAMAGE"] = "auto",
            ["RUMBLE"] = false,
            ["LAMP_START"] = false,
            ["SHOTS_FIRED"] = "auto",
            ["SHOTS_FIRED_PRIMARY"] = "auto",
            ["SHOTS_FIRED_ALT"] = "auto",
            ["SHOTS_FIRED_GRENADE"] = "auto",
            ["DAMAGE_TAKEN"] = "auto",
            ["LIFE_LOST"] = "auto"
        },
        ["P2"] = {
            ["CREDITS"] = "auto",
            ["STATUS"] = "auto",
            ["STATUS_ACTIVE_VALUE"] = "auto",
            ["STATUS_ALT"] = "auto",
            ["STATUS_ALT_ACTIVE_VALUE"] = "auto",
            ["AMMO"] = "auto",
            ["AMMO_ALT"] = "auto",
            ["AMMO_GRENADE"] = "auto",
            ["LIFE"] = "auto",
            ["LIFE_ALT"] = "auto",
            ["RECOIL"] = "auto",
            ["RELOAD"] = "auto",
            ["DAMAGE"] = "auto",
            ["RUMBLE"] = "auto",
            ["LAMP_START"] = "auto",
            ["SHOTS_FIRED"] = "auto",
            ["SHOTS_FIRED_PRIMARY"] = "auto",
            ["SHOTS_FIRED_ALT"] = "auto",
            ["SHOTS_FIRED_GRENADE"] = "auto",
            ["DAMAGE_TAKEN"] = "auto",
            ["LIFE_LOST"] = "auto"
        },
        ["P3"] = {
            ["CREDITS"] = "auto",
            ["STATUS"] = "auto",
            ["STATUS_ACTIVE_VALUE"] = "auto",
            ["STATUS_ALT"] = "auto",
            ["STATUS_ALT_ACTIVE_VALUE"] = "auto",
            ["AMMO"] = "auto",
            ["AMMO_ALT"] = "auto",
            ["AMMO_GRENADE"] = "auto",
            ["LIFE"] = "auto",
            ["LIFE_ALT"] = "auto",
            ["RECOIL"] = "auto",
            ["RELOAD"] = "auto",
            ["DAMAGE"] = "auto",
            ["RUMBLE"] = "auto",
            ["LAMP_START"] = "auto",
            ["SHOTS_FIRED"] = "auto",
            ["SHOTS_FIRED_PRIMARY"] = "auto",
            ["SHOTS_FIRED_ALT"] = "auto",
            ["SHOTS_FIRED_GRENADE"] = "auto",
            ["DAMAGE_TAKEN"] = "auto",
            ["LIFE_LOST"] = "auto"
        },
        ["P4"] = {
            ["CREDITS"] = "auto",
            ["STATUS"] = "auto",
            ["STATUS_ACTIVE_VALUE"] = "auto",
            ["STATUS_ALT"] = "auto",
            ["STATUS_ALT_ACTIVE_VALUE"] = "auto",
            ["AMMO"] = "auto",
            ["AMMO_ALT"] = "auto",
            ["AMMO_GRENADE"] = "auto",
            ["LIFE"] = "auto",
            ["LIFE_ALT"] = "auto",
            ["RECOIL"] = "auto",
            ["RELOAD"] = "auto",
            ["DAMAGE"] = "auto",
            ["RUMBLE"] = "auto",
            ["LAMP_START"] = "auto",
            ["SHOTS_FIRED"] = "auto",
            ["SHOTS_FIRED_PRIMARY"] = "auto",
            ["SHOTS_FIRED_ALT"] = "auto",
            ["SHOTS_FIRED_GRENADE"] = "auto",
            ["DAMAGE_TAKEN"] = "auto",
            ["LIFE_LOST"] = "auto"
        },
        ["AMMO_DIRECTION"] = "decrease",
        ["AMMO_ALT_DIRECTION"] = "decrease",
        ["AMMO_GRENADE_DIRECTION"] = "decrease",
        ["LIFE_DIRECTION"] = "decrease",
        ["LIFE_ALT_DIRECTION"] = "decrease",
        ["SHOTS_FIRED_METHOD"] = "trigger",
        ["SHOTS_FIRED_ALT_METHOD"] = "trigger",
        ["SHOTS_FIRED_GRENADE_METHOD"] = "trigger",
        ["FORCE_FEEDBACK_ENABLER"] = "both",
        ["RECOIL_METHOD"] = "pulse",
        ["RECOIL_PRIORITY"] = "ammo",
        ["RECOIL_MEM_ADD_VALUE"] = false,
        ["ENABLE_CREDIT_COUNT"] = true,
        ["ENABLE_RECOIL_AMMO"] = true,
        ["ENABLE_RECOIL_AMMO_ALT"] = true,
        ["ENABLE_RECOIL_AMMO_GRENADE"] = true,
        ["ENABLE_RELOAD_AMMO"] = true,
        ["ENABLE_RELOAD_AMMO_ALT"] = true,
        ["ENABLE_RELOAD_AMMO_GRENADE"] = true,
        ["ENABLE_SHOT_COUNT"] = true,
        ["ENABLE_DAMAGE_COUNT"] = true,
        ["ENABLE_LIFE_LOST"] = true,
        ["DEMULSHOOTER_COMPATIBILITY"] = true,
        ["ENABLE_OSD"] = false
    },
    ["alien3"] = {
        ["LUA_GAME"] = "Alien3: The Gun",
        ["LUA_ROM_ID"] = 1,
        ["CPU_TAG"] = ":mainpcb:maincpu",
        ["CPU_TAGS"] = {
            ["CREDITS"] = ":mainpcb:soundcpu"
        },
        ["STARTUP_DELAY_MS"] = 2000,
        ["DATA_WIDTHS"] = {
            ["LIFE"] = 16
        },
        ["PLAYER_MEMORY_OFFSET"] = "0x100",
        ["AMMO_MAX"] = 255,
        ["LIFE_MAX"] = 640,
        ["RECOIL_HOLD_MS"] = 400,
        ["RECOIL_HOLD_MS_comment"] = "When ammo = 0, fire rate slows down for primary weapon until reloaded (by releasing the gun trigger)",
        ["P1"] = {
            ["CREDITS"] = "0x0000FF25",
            ["STATUS"] = "0x002005F1",
            ["AMMO"] = "0x00200698",
            ["AMMO_comment"] = "Ammo = Primary Machine Gun",
            ["AMMO_ALT"] = "0x0020069C",
            ["AMMO_ALT_comment"] = "AmmoAlt = Flamethrower",
            ["AMMO_GRENADE"] = "0x00200697",
            ["AMMO_GRENADE_comment"] = "AmmoGrenade = Grenade / Bomb",
            ["LIFE"] = "0x002006A2",
            ["RECOIL"] = "0x00200690",
            ["RECOIL_comment"] = "Recoil = Trigger Press (hold, not pulse)"
        },
        ["P2"] = {
            ["CREDITS"] = "0x0000FF24"
        },
        ["RECOIL_METHOD"] = "hold",
        ["RECOIL_PRIORITY"] = "ammo"
    },
    ["area51"] = {
        ["LUA_GAME"] = "Area 51",
        ["LUA_ROM_ID"] = 2,
        ["OFFSCREEN_RELOAD"] = true,
        ["SCREEN_FLASH"] = true,
        ["SCREEN_FLASH_MEMORY_ADDRESS"] = false,
        ["SCREEN_FLASH_DISABLE_VALUE"] = false,
        ["SCREEN_FLASH_RESTORE_VALUE"] = false,
        ["STARTUP_DELAY_MS"] = 4000,
        ["COINS_PER_CREDIT"] = 2,
        ["PLAYER_MEMORY_OFFSET"] = "0xA8",
        ["CREDITS"] = "0x100003A5",
        ["P1"] = {
            ["STATUS"] = "0x10008733",
            ["AMMO"] = "0x1000876F",
            ["LIFE"] = "0x1000879B"
        }
    },
    ["area51mx"] = {
        ["LUA_GAME"] = "Area 51 / Maximum Force Duo",
        ["LUA_ROM_ID"] = 3,
        ["OFFSCREEN_RELOAD"] = true,
        ["SCREEN_FLASH"] = true,
        ["SCREEN_FLASH_MEMORY_ADDRESS"] = false,
        ["SCREEN_FLASH_DISABLE_VALUE"] = false,
        ["SCREEN_FLASH_RESTORE_VALUE"] = false,
        ["COINS_PER_CREDIT"] = 2,
        ["RECOIL_ALT_DURATION_MS"] = 40,
        ["CREDITS"] = "0x00A0073F",
        ["P1"] = {
            ["STATUS"] = "0x00A19979",
            ["STATUS_comment"] = "P1 STATUS for Area 51",
            ["STATUS_ALT"] = "0x00A09001",
            ["STATUS_ALT_comment"] = "P1 STATUS for Maximum Force",
            ["AMMO"] = "0x00A199B5",
            ["AMMO_comment"] = "P1 AMMO for Area 51",
            ["AMMO_ALT"] = "0x00A19479",
            ["AMMO_ALT_comment"] = "P1 AMMO for Maximum Force",
            ["LIFE"] = "0x00A199E1",
            ["LIFE_comment"] = "P1 LIFE for Area 51",
            ["LIFE_ALT"] = "0x00A19425",
            ["LIFE_ALT_comment"] = "P1 LIFE for Maximum Force"
        },
        ["P2"] = {
            ["STATUS"] = "0x00A19A59",
            ["STATUS_comment"] = "P2 STATUS for Area 51",
            ["STATUS_ALT"] = "0x00A09005",
            ["STATUS_ALT_comment"] = "P2 STATUS for Maximum Force",
            ["AMMO"] = "0x00A19A5D",
            ["AMMO_comment"] = "P2 AMMO for Area 51",
            ["AMMO_ALT"] = "0x00A19505",
            ["AMMO_ALT_comment"] = "P2 AMMO for Maximum Force",
            ["LIFE"] = "0x00A19A89",
            ["LIFE_comment"] = "P2 LIFE for Area 51",
            ["LIFE_ALT"] = "0x00A194B1",
            ["LIFE_ALT_comment"] = "P2 LIFE for Maximum Force"
        }
    },
    ["bbust2"] = {
        ["LUA_GAME"] = "Beast Busters: Second Nightmare",
        ["LUA_ROM_ID"] = 6,
        ["STARTUP_DELAY_MS"] = 8000,
        ["DATA_WIDTHS"] = {
            ["LIFE"] = 16
        },
        ["PLAYER_MEMORY_OFFSET"] = "0x60",
        ["PLAYER_CREDIT_MEMORY_OFFSET"] = "0x2",
        ["RECOIL_HOLD_MS"] = 100,
        ["ATTRACT_STATUS"] = "0x001843CA",
        ["ATTRACT_STATUS_comment"] = "Attract Status for bbust2 could be either 0x001843CA or 0x0018457F (they appear simultaneously under the exact same test conditions)",
        ["GAME_STATUS"] = "0x001844F3",
        ["P1"] = {
            ["CREDITS"] = "0x00184589",
            ["STATUS"] = "auto",
            ["AMMO"] = "0x0019B75F",
            ["LIFE"] = "0x0019B74D",
            ["RECOIL"] = "0x0019B793",
            ["RECOIL_comment"] = "P1 Recoil for bbust2 is 0x0019B793 but noting that 0x001824B4 is P1 gun trigger press"
        },
        ["P2"] = {
            ["CREDITS"] = "0x0018458B"
        },
        ["RECOIL_METHOD"] = "hold",
        ["RECOIL_PRIORITY"] = "ammo"
    },
    ["bel"] = {
        ["LUA_GAME"] = "Behind Enemy Lines",
        ["LUA_ROM_ID"] = 7,
        ["LIGHTGUN_PATCH"] = true,
        ["STARTUP_DELAY_MS"] = 7000,
        ["DATA_WIDTHS"] = {
            ["LAMP_START"] = "output"
        },
        ["RECOIL_HOLD_MS"] = 400,
        ["RECOIL_HOLD_MS_comment"] = "When ammo = 0, burst fire shot speed changes. First burst fire shot > small gap > second burst fire shot > large gap > restart from first burst fire shot.",
        ["CREDITS"] = "0x005A87F0",
        ["GAME_STATUS"] = "0x00506BD2",
        ["P1"] = {
            ["STATUS"] = "auto",
            ["AMMO"] = "0x005B494C",
            ["LIFE"] = "0x005B4997",
            ["RECOIL"] = "0x005A87B0",
            ["RECOIL_comment"] = "Alternative recoil triggers can include: 0x005A87B0 > 0 for trigger press in-game for P1; 0x005B494B > 0 for a shot countdown",
            ["DAMAGE"] = "0x005A8138",
            ["DAMAGE_comment"] = "0x005A8138 > 0 when the red DAMAGE text appears on-screen for both players",
            ["LAMP_START"] = "lamp0"
        },
        ["P2"] = {
            ["AMMO"] = "0x005B49D0",
            ["LIFE"] = "0x005B4A1B",
            ["RECOIL"] = "0x005A87B1",
            ["RECOIL_comment"] = "Alternative recoil triggers can include: 0x005A87B1 > 0 for trigger press in-game for P2; 0x005B49CF > 0 for a shot countdown",
            ["DAMAGE"] = "0x005A8138",
            ["DAMAGE_comment"] = "0x005A8138 > 0 when the red DAMAGE text appears on-screen for both players",
            ["LAMP_START"] = "lamp1"
        },
        ["FORCE_FEEDBACK_ENABLER"] = "gamestatus",
        ["RECOIL_METHOD"] = "hold"
    },
    ["carnevil"] = {
        ["LUA_GAME"] = "CarnEvil",
        ["LUA_ROM_ID"] = 13,
        ["STARTUP_DELAY_MS"] = 23000,
        ["COINS_PER_CREDIT"] = 2,
        ["DATA_WIDTHS"] = {
            ["GLOBAL_CREDITS"] = 32,
            ["STATUS"] = 32,
            ["AMMO"] = 32,
            ["LIFE"] = "float32"
        },
        ["PLAYER_MEMORY_OFFSET"] = "0x120",
        ["CREDITS"] = "0x001DE8D8",
        ["P1"] = {
            ["STATUS"] = "0x001E0F64",
            ["AMMO"] = "0x001E0FFC",
            ["LIFE"] = "0x001E0F84"
        }
    },
    ["cryptklr"] = {
        ["LUA_GAME"] = "Crypt Killer",
        ["LUA_ROM_ID"] = 22,
        ["SCREEN_FLASH"] = true,
        ["SCREEN_FLASH_MEMORY_ADDRESS"] = "0x8001512A",
        ["SCREEN_FLASH_DISABLE_VALUE"] = "0x1400",
        ["SCREEN_FLASH_RESTORE_VALUE"] = "0x0C03",
        ["STARTUP_DELAY_MS"] = 70000,
        ["MAX_PLAYERS"] = 3,
        ["DATA_WIDTHS"] = {
            ["SCREEN_FLASH"] = 16
        },
        ["PLAYER_MEMORY_OFFSET"] = "0x58",
        ["ATTRACT_STATUS"] = "0x001EFDD3",
        ["ATTRACT_STATUS_comment"] = "12 memory addresses identified for cryptklr attract status (unable to determine which is purely dedicated to attract mode, but all show up during same test conditions): 0x001EFDD3; 0x001EFDFB; 0x001EFE13; 0x001EFE23; 0x001EFE3B; 0x001EFE63; 0x001EFE7B; 0x001EFE8B; 0x001EFEA3; 0x001EFECB; 0x001EFEE3; 0x001EFEF3",
        ["CREDITS"] = "0x002189C1",
        ["P1"] = {
            ["STATUS"] = "0x002377C8",
            ["STATUS_comment"] = "P1 Status = 0x002377C8 (1 = Player Active, whether Alive or Dead); P1 Game Status (1 = Alive, 3 = Dead) = 0x002377C9",
            ["AMMO"] = "0x002377D3",
            ["LIFE"] = "0x002377CC"
        }
    },
    ["dragngun"] = {
        ["LUA_GAME"] = "Dragon Gun",
        ["LUA_ROM_ID"] = 26,
        ["STARTUP_DELAY_MS"] = 4000,
        ["MIN_RECOIL_INTERVAL_MS"] = 80,
        ["MIN_RECOIL_INTERVAL_MS_comment"] = "Unknown recoil interval for dragngun (due to missing ammo memory address) but restricted to 80 to prevent light gun solenoid from overheating",
        ["RECOIL_HOLD_MS"] = 80,
        ["RECOIL_HOLD_MS_comment"] = "Unknown recoil interval for dragngun (due to missing ammo memory address) but restricted to 80 to prevent light gun solenoid from overheating",
        ["CREDITS"] = "0x0011F220",
        ["GAME_STATUS"] = "0x0011F1BC",
        ["P1"] = {
            ["STATUS"] = "0x0011F1DC",
            ["STATUS_comment"] = "P1 Status = 0x0011F1DC; P1 Status alternative memory address = 0x00100082",
            ["AMMO"] = false,
            ["AMMO_GRENADE"] = "0x0010008A",
            ["AMMO_GRENADE_comment"] = "AmmoGrenade = Grenade / Bomb",
            ["LIFE"] = "0x00100008",
            ["RECOIL"] = "0x0011F1B6",
            ["RECOIL_comment"] = "Recoil = Trigger Press (hold, not pulse)"
        },
        ["P2"] = {
            ["STATUS"] = "0x0011F1DD",
            ["STATUS_comment"] = "P2 Status = 0x0011F1DD; P2 Status alternative memory address = 0x00100182",
            ["AMMO"] = false,
            ["AMMO_ALT"] = "0x0010018A",
            ["LIFE"] = "0x00100108",
            ["RECOIL"] = "0x0011F1B7"
        },
        ["RECOIL_METHOD"] = "hold",
        ["RECOIL_PRIORITY"] = "ammo"
    },
    ["duckhunt"] = {
        ["LUA_GAME"] = "Duck Hunt",
        ["LUA_ROM_ID"] = 27,
        ["SCREEN_FLASH"] = true,
        ["SCREEN_FLASH_MEMORY_ADDRESS"] = false,
        ["SCREEN_FLASH_DISABLE_VALUE"] = false,
        ["SCREEN_FLASH_RESTORE_VALUE"] = false,
        ["STARTUP_DELAY_MS"] = 1000,
        ["SIMULTANEOUS_PLAY"] = false,
        ["PLAYER_MEMORY_OFFSET"] = 0,
        ["AMMO_MAX"] = 3,
        ["LIFE_OFFSET"] = 1,
        ["LIFE_MAX"] = 5,
        ["CREDITS"] = "0x00000635",
        ["GAME_STATUS"] = "0x000000EF",
        ["P1"] = {
            ["STATUS"] = "0x0000067C",
            ["AMMO"] = "0x000000BA",
            ["LIFE"] = "0x000000C5"
        },
        ["P2"] = {
            ["STATUS"] = "0x00000602"
        }
    },
    ["hotd"] = {
        ["LUA_GAME"] = "The House of the Dead",
        ["LUA_ROM_ID"] = 38,
        ["OFFSCREEN_RELOAD"] = true,
        ["SCREEN_FLASH"] = true,
        ["SCREEN_FLASH_MEMORY_ADDRESS"] = false,
        ["SCREEN_FLASH_DISABLE_VALUE"] = false,
        ["SCREEN_FLASH_RESTORE_VALUE"] = false,
        ["STARTUP_DELAY_MS"] = 14000,
        ["COINS_PER_CREDIT"] = 1,
        ["COINS_PER_CREDIT_comment"] = "2 Credits required to start a game for either player, but only 1 Credit required to continue the game once started",
        ["DATA_WIDTHS"] = {
            ["LAMP_START"] = "output"
        },
        ["ATTRACT_STATUS"] = "0x0051F5E8",
        ["CREDITS"] = "0x0051E868",
        ["CREDITS_comment"] = "Alternatives might include: 0x0051E868, 0x0051E888, 0x0051F4B8, 0X01D0000A, 0X01D0005E",
        ["GAME_STATUS"] = "0x0051F4A0",
        ["GAME_STATUS_comment"] = "Alternatives might include: 0x0051F4A0, 0x0051F4A2; If either = 1 then 1 player is active (can be either P1 or P2), if either = 2 then both 2 players are active",
        ["P1"] = {
            ["STATUS"] = "auto",
            ["AMMO"] = "0x0051F2C1",
            ["LIFE"] = "0x0051F290",
            ["LAMP_START"] = "lamp0"
        },
        ["P2"] = {
            ["AMMO"] = "0x0051F38D",
            ["LIFE"] = "0x0051F35C",
            ["LAMP_START"] = "lamp1"
        }
    },
    ["invasnab"] = {
        ["LUA_GAME"] = "Invasion: The Abductors",
        ["LUA_ROM_ID"] = 40,
        ["OFFSCREEN_RELOAD"] = true,
        ["STARTUP_DELAY_MS"] = 7000,
        ["COINS_PER_CREDIT"] = 2,
        ["DATA_WIDTHS"] = {
            ["GLOBAL_CREDITS"] = 16,
            ["STATUS"] = 16,
            ["AMMO_ALT"] = 16,
            ["LIFE"] = 32
        },
        ["PLAYER_MEMORY_OFFSET"] = "0x36",
        ["AMMO_MAX"] = 9,
        ["CREDITS"] = "0x0000AF08",
        ["P1"] = {
            ["STATUS"] = "0x0000A011",
            ["AMMO"] = "0x0000C07C",
            ["AMMO_comment"] = "P1 Primary Weapon = 0x0000C07C",
            ["AMMO_ALT"] = "0x0000A034",
            ["AMMO_ALT_comment"] = "P1 Rockets = 0x0000A034",
            ["LIFE"] = "0x0000A01D"
        },
        ["P2"] = {
            ["STATUS"] = "0x0000A047",
            ["AMMO"] = "0x0000C07E",
            ["AMMO_comment"] = "P2 Primary Weapon = 0x0000C07E",
            ["AMMO_ALT"] = "0x0000A068",
            ["AMMO_ALT_comment"] = "P2 Rockets = 0x0000A068",
            ["LIFE"] = "0x0000A053"
        },
        ["AMMO_ALT_DIRECTION"] = "increase",
        ["LIFE_DIRECTION"] = "increase"
    },
    ["jdredd"] = {
        ["LUA_GAME"] = "Judge Dredd",
        ["LUA_ROM_ID"] = 41,
        ["OFFSCREEN_RELOAD"] = true,
        ["SCREEN_FLASH"] = true,
        ["SCREEN_FLASH_MEMORY_ADDRESS"] = false,
        ["SCREEN_FLASH_DISABLE_VALUE"] = false,
        ["SCREEN_FLASH_RESTORE_VALUE"] = false,
        ["STARTUP_DELAY_MS"] = 18000,
        ["PLAYER_MEMORY_OFFSET"] = "0x48",
        ["RECOIL_ALT_DURATION_MS"] = 20,
        ["CREDITS"] = "0x003E6CAE",
        ["GAME_STATUS"] = "0x003E6E8A",
        ["P1"] = {
            ["STATUS"] = "auto",
            ["AMMO"] = "0x0010ED5D",
            ["AMMO_comment"] = "P1 Primary Weapon = 0x0010ED5D",
            ["AMMO_ALT"] = "0x0010ED48",
            ["AMMO_ALT_comment"] = "P1 Alt Machine Gun = 0x0010ED48",
            ["AMMO_GRENADE"] = "0x0010ED5F",
            ["AMMO_GRENADE_comment"] = "P1 Grenade = 0x0010ED5F",
            ["LIFE"] = "0x0010ED5C"
        }
    },
    ["jpark"] = {
        ["LUA_GAME"] = "Jurassic Park",
        ["LUA_ROM_ID"] = 42,
        ["LIGHTGUN_PATCH"] = true,
        ["CPU_TAG"] = ":mainpcb:maincpu",
        ["STARTUP_DELAY_MS"] = 1000,
        ["DATA_WIDTHS"] = {
            ["LAMP_START"] = "output"
        },
        ["LIFE_MAX"] = 104,
        ["MIN_RECOIL_INTERVAL_MS"] = 100,
        ["MIN_RECOIL_INTERVAL_MS_comment"] = "Appears to be 66ms for jpark but restricted to 100ms to prevent light gun solenoid from overheating",
        ["RECOIL_HOLD_MS"] = 100,
        ["RECOIL_HOLD_MS_comment"] = "Appears to be 66ms for jpark but restricted to 100ms to prevent light gun solenoid from overheating",
        ["CREDITS"] = "0x0020F1E2",
        ["GAME_STATUS"] = "0x0020F5AC",
        ["P1"] = {
            ["STATUS"] = "0x0020F00A",
            ["STATUS_ACTIVE_VALUE"] = {
                1,
                3
            },
            ["AMMO_comment"] = "P1 Ammo (seems to change between levels / stages) = 0x00201B46",
            ["LIFE"] = "0x00201B40",
            ["RECOIL"] = "0x0020F01A",
            ["RECOIL_comment"] = "P1 Trigger Press (hold, not pulse) = 0x0020F01A",
            ["LAMP_START"] = "Left_lamp"
        },
        ["P2"] = {
            ["STATUS"] = "0x0020F00A",
            ["STATUS_ACTIVE_VALUE"] = {
                2,
                3
            },
            ["AMMO_comment"] = "P2 Ammo (seems to change between levels / stages) = 0x002018C6; Also found at some point that P2 Ammo = 0x00201846 but this does not appear to be the case anymore",
            ["LIFE"] = "0x002018C0",
            ["LIFE_comment"] = "P2 Life = 0x002018C0; Also found at some point that P2 Life = 0x00201840 but this does not appear to be the case anymore",
            ["RECOIL"] = "0x0020F01B",
            ["RECOIL_comment"] = "P2 Trigger Press (hold, not pulse) = 0x0020F01B",
            ["LAMP_START"] = "Right_lamp"
        },
        ["RECOIL_METHOD"] = "hold",
        ["RECOIL_PRIORITY"] = "recoil",
        ["ENABLE_RELOAD_AMMO"] = false
    },
    ["le2"] = {
        ["LUA_GAME"] = "Lethal Enforcers II: Gun Fighters",
        ["LUA_ROM_ID"] = 46,
        ["OFFSCREEN_RELOAD"] = true,
        ["SCREEN_FLASH"] = true,
        ["SCREEN_FLASH_MEMORY_ADDRESS"] = false,
        ["SCREEN_FLASH_DISABLE_VALUE"] = false,
        ["SCREEN_FLASH_RESTORE_VALUE"] = false,
        ["STARTUP_DELAY_MS"] = 14000,
        ["PLAYER_MEMORY_OFFSET"] = "0x40",
        ["CREDITS"] = "0x00C012AD",
        ["GAME_STATUS"] = "0x00C00000",
        ["P1"] = {
            ["STATUS"] = "0x00C012F0",
            ["AMMO"] = "0x00C01316",
            ["LIFE"] = "0x00C012F4"
        }
    },
    ["lethalen"] = {
        ["LUA_GAME"] = "Lethal Enforcers",
        ["LUA_ROM_ID"] = 45,
        ["OFFSCREEN_RELOAD"] = true,
        ["SCREEN_FLASH"] = true,
        ["SCREEN_FLASH_MEMORY_ADDRESS"] = false,
        ["SCREEN_FLASH_DISABLE_VALUE"] = false,
        ["SCREEN_FLASH_RESTORE_VALUE"] = false,
        ["STARTUP_DELAY_MS"] = 7000,
        ["COINS_PER_CREDIT"] = 2,
        ["PLAYER_MEMORY_OFFSET"] = "0x40",
        ["CREDITS"] = "0x00002030",
        ["GAME_STATUS"] = "0x00002000",
        ["P1"] = {
            ["STATUS"] = "0x0000219C",
            ["AMMO"] = "0x00002193",
            ["LIFE"] = "0x00002191"
        },
        ["P2"] = {
            ["STATUS"] = "0x000021DC"
        }
    },
    ["lethalj"] = {
        ["LUA_GAME"] = "Lethal Justice",
        ["LUA_ROM_ID"] = 47,
        ["OFFSCREEN_RELOAD"] = true,
        ["SCREEN_FLASH"] = true,
        ["SCREEN_FLASH_MEMORY_ADDRESS"] = false,
        ["SCREEN_FLASH_DISABLE_VALUE"] = false,
        ["SCREEN_FLASH_RESTORE_VALUE"] = false,
        ["STARTUP_DELAY_MS"] = 8000,
        ["COINS_PER_CREDIT"] = 16,
        ["CREDITS"] = "0x00300220",
        ["GAME_STATUS"] = "0x000900C8",
        ["P1"] = {
            ["STATUS"] = "auto",
            ["AMMO"] = "0x00300710",
            ["LIFE"] = "0x00300870"
        },
        ["P2"] = {
            ["AMMO"] = "0x00300750",
            ["LIFE"] = "0x00300890"
        }
    },
    ["maxforce"] = {
        ["LUA_GAME"] = "Maximum Force",
        ["LUA_ROM_ID"] = 51,
        ["OFFSCREEN_RELOAD"] = true,
        ["SCREEN_FLASH"] = true,
        ["SCREEN_FLASH_MEMORY_ADDRESS"] = false,
        ["SCREEN_FLASH_DISABLE_VALUE"] = false,
        ["SCREEN_FLASH_RESTORE_VALUE"] = false,
        ["STARTUP_DELAY_MS"] = 3000,
        ["COINS_PER_CREDIT"] = 2,
        ["PLAYER_MEMORY_OFFSET"] = "0x8C",
        ["CREDITS"] = "0x100003E5",
        ["GAME_STATUS"] = "0x1001DEC7",
        ["P1"] = {
            ["STATUS"] = "0x1000A543",
            ["AMMO"] = "0x1000AB37",
            ["LIFE"] = "0x1000AAE3"
        },
        ["P2"] = {
            ["STATUS"] = "0x1000A547"
        }
    },
    ["policetr"] = {
        ["LUA_GAME"] = "Police Trainer",
        ["LUA_ROM_ID"] = 64,
        ["SCREEN_FLASH"] = true,
        ["SCREEN_FLASH_MEMORY_ADDRESS"] = false,
        ["SCREEN_FLASH_DISABLE_VALUE"] = false,
        ["SCREEN_FLASH_RESTORE_VALUE"] = false,
        ["STARTUP_DELAY_MS"] = 3000,
        ["DATA_WIDTHS"] = {
            ["CREDITS"] = 16
        },
        ["PLAYER_MEMORY_OFFSET"] = "0xC",
        ["CREDITS"] = "0x00017D66",
        ["GAME_STATUS"] = "0x00019A33",
        ["P1"] = {
            ["STATUS"] = "0x00019A33",
            ["STATUS_ACTIVE_VALUE"] = {
                1,
                3
            },
            ["AMMO"] = "0x00018D97",
            ["LIFE"] = "0x00017D4B"
        },
        ["P2"] = {
            ["STATUS"] = "0x00019A33",
            ["STATUS_ACTIVE_VALUE"] = {
                2,
                3
            },
            ["AMMO"] = "0x00018DA7",
            ["LIFE"] = "0x00017D57"
        }
    },
    ["ptblank"] = {
        ["LUA_GAME"] = "Point Blank",
        ["LUA_ROM_ID"] = 62,
        ["SCREEN_FLASH"] = true,
        ["SCREEN_FLASH_MEMORY_ADDRESS"] = false,
        ["SCREEN_FLASH_DISABLE_VALUE"] = false,
        ["SCREEN_FLASH_RESTORE_VALUE"] = false,
        ["STARTUP_DELAY_MS"] = 2000,
        ["PLAYER_MEMORY_OFFSET"] = "0x02",
        ["CREDITS"] = "0x001C004D",
        ["GAME_STATUS"] = "0x00210081",
        ["P1"] = {
            ["STATUS"] = "0x00210427",
            ["AMMO"] = "0x00210011",
            ["LIFE"] = "0x001C00B7",
            ["DAMAGE"] = "0x001C00B3"
        },
        ["P2"] = {
            ["STATUS"] = "0x002105C5"
        },
        ["AMMO_DIRECTION"] = "increase"
    },
    ["sgunner"] = {
        ["LUA_GAME"] = "Steel Gunner",
        ["LUA_ROM_ID"] = 77,
        ["STARTUP_DELAY_MS"] = 4000,
        ["DATA_WIDTHS"] = {
            ["AMMO"] = 16
        },
        ["PLAYER_MEMORY_OFFSET"] = "0x2",
        ["GAME_STATUS"] = "0x001002E7",
        ["P1"] = {
            ["CREDITS"] = "0x00100121",
            ["STATUS"] = "auto",
            ["AMMO"] = "0x00100324",
            ["AMMO_comment"] = "Primary Machine Gun",
            ["AMMO_GRENADE"] = "0x00100321",
            ["AMMO_GRENADE_comment"] = "Missiles",
            ["LIFE"] = "0x00100125"
        },
        ["AMMO_DIRECTION"] = "increase",
        ["ENABLE_RELOAD_AMMO"] = false
    },
    ["sgunner2"] = {
        ["LUA_GAME"] = "Steel Gunner 2",
        ["LUA_ROM_ID"] = 78,
        ["STARTUP_DELAY_MS"] = 4000,
        ["PLAYER_MEMORY_OFFSET"] = "0x2",
        ["GAME_STATUS"] = "0x00100944",
        ["P1"] = {
            ["CREDITS"] = "0x00108C11",
            ["STATUS"] = "0x00108AED",
            ["AMMO"] = "0x00108D43",
            ["AMMO_comment"] = "Primary Machine Gun",
            ["AMMO_GRENADE"] = "0x00108D3F",
            ["AMMO_GRENADE_comment"] = "Missiles",
            ["LIFE"] = "0x00108C25"
        },
        ["P2"] = {
            ["STATUS"] = "0x00108B79"
        },
        ["AMMO_DIRECTION"] = "increase",
        ["ENABLE_RELOAD_AMMO"] = false
    },
    ["timecris"] = {
        ["LUA_GAME"] = "Time Crisis",
        ["LUA_ROM_ID"] = 81,
        ["SCREEN_FLASH"] = true,
        ["SCREEN_FLASH_MEMORY_ADDRESS"] = false,
        ["SCREEN_FLASH_DISABLE_VALUE"] = false,
        ["SCREEN_FLASH_RESTORE_VALUE"] = false,
        ["STARTUP_DELAY_MS"] = 3000,
        ["COINS_PER_CREDIT"] = 3,
        ["MAX_PLAYERS"] = 1,
        ["SIMULTANEOUS_PLAY"] = false,
        ["CREDITS"] = "0x00E0D2A1",
        ["GAME_STATUS"] = "0x00E01772",
        ["P1"] = {
            ["STATUS"] = "auto",
            ["AMMO"] = "0x00E00793",
            ["LIFE"] = "0x00E00791"
        }
    },
    ["timecrs2"] = {
        ["LUA_GAME"] = "Time Crisis II",
        ["LUA_ROM_ID"] = 82,
        ["SCREEN_FLASH"] = true,
        ["SCREEN_FLASH_MEMORY_ADDRESS"] = false,
        ["SCREEN_FLASH_DISABLE_VALUE"] = false,
        ["SCREEN_FLASH_RESTORE_VALUE"] = false,
        ["STARTUP_DELAY_MS"] = 17000,
        ["COINS_PER_CREDIT"] = 4,
        ["MAX_PLAYERS"] = 1,
        ["SIMULTANEOUS_PLAY"] = false,
        ["CREDITS"] = "0x002CE7B7",
        ["GAME_STATUS"] = "0x002CE8AF",
        ["P1"] = {
            ["STATUS"] = "auto",
            ["AMMO"] = "0x002F43FF",
            ["LIFE"] = "0x002F4401"
        }
    },
    ["vcop"] = {
        ["LUA_GAME"] = "Virtua Cop",
        ["LUA_ROM_ID"] = 87,
        ["OFFSCREEN_RELOAD"] = true,
        ["SCREEN_FLASH"] = true,
        ["SCREEN_FLASH_MEMORY_ADDRESS"] = false,
        ["SCREEN_FLASH_DISABLE_VALUE"] = false,
        ["SCREEN_FLASH_RESTORE_VALUE"] = false,
        ["STARTUP_DELAY_MS"] = 15000,
        ["DATA_WIDTHS"] = {
            ["LAMP_START"] = "output"
        },
        ["PLAYER_MEMORY_OFFSET"] = 4,
        ["CREDITS"] = "0x00559270",
        ["P1"] = {
            ["STATUS"] = "0x0050EE30",
            ["AMMO"] = "0x0050EE38",
            ["LIFE"] = "0x0050EE70",
            ["LAMP_START"] = "lamp0"
        },
        ["P2"] = {
            ["LAMP_START"] = "lamp1"
        }
    },
    ["vcop2"] = {
        ["LUA_GAME"] = "Virtua Cop 2",
        ["LUA_ROM_ID"] = 88,
        ["OFFSCREEN_RELOAD"] = true,
        ["SCREEN_FLASH"] = true,
        ["SCREEN_FLASH_MEMORY_ADDRESS"] = false,
        ["SCREEN_FLASH_DISABLE_VALUE"] = false,
        ["SCREEN_FLASH_RESTORE_VALUE"] = false,
        ["STARTUP_DELAY_MS"] = 13000,
        ["DATA_WIDTHS"] = {
            ["LAMP_START"] = "output"
        },
        ["PLAYER_MEMORY_OFFSET"] = 4,
        ["CREDITS"] = "0x005D05C0",
        ["GAME_STATUS"] = "0x00500035",
        ["P1"] = {
            ["STATUS"] = "0x0050A2E8",
            ["AMMO"] = "0x00507260",
            ["LIFE"] = "0x00502090",
            ["LAMP_START"] = "lamp0"
        },
        ["P2"] = {
            ["LAMP_START"] = "lamp1"
        }
    },
}

return database
