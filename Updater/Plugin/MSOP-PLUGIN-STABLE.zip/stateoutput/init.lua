-- =========================================================================================
-- MAME STATE OUTPUT PROJECT (MSOP)
-- MSOP PLUGIN
-- Plugin Version: 9.1.0
-- Plugin Date: 2026.07.22
-- Project: https://github.com/djGLiTCH/MAME-LUA-SCRIPT-STATE-OUTPUTS
-- License: GNU GENERAL PUBLIC LICENSE GPL-v3.0
-- Copyright (c) 2026 Jacob Simpson (DJ GLiTCH). All Rights Reserved.
-- =========================================================================================
--
-- ARCHITECTURE OVERVIEW:
-- This script operates as a native MAME plugin. Unlike standalone Lua scripts, plugins 
-- are loaded once when MAME starts. They run in the background and must actively "hook" 
-- into MAME's event system (like when a game boots, or when a frame renders) to function.
--
-- This plugin subscribes to the following deliberately different hooks per machine
-- session - do not merge them or change which one does what:
--
--   1. REMOVED IN v9.1.0 - emu.add_machine_devices_started_notifier ->
--      Register_Master_List()
--      MSOP used to register its own synthetic outputs (MSOP_P1_Ammo and the
--      rest) against the root device here, by calling root:register_output()
--      from a patched MAME core. That core patch was proposed upstream as
--      mamedev/mame PR #15639 and was REJECTED on design grounds, not for any
--      fixable coding reason: MAME's maintainers hold that a machine's output
--      table is a STATIC part of its configuration, so nothing outside the
--      driver may add to it, and allowing scripts to would make save states
--      depend on which scripts were loaded. See
--      https://github.com/mamedev/mame/pull/15639 (and PR #15618 before it) for
--      the full reasoning. That capability is therefore gone for good on stock
--      MAME, and every trace of it has been removed here rather than left to rot
--      behind a capability flag.
--
--      Nothing replaces it, because nothing needs to: MSOP's own outputs have
--      been delivered over the relay since v9.0.2 (see the RELAY TRANSPORT LAYER
--      section), which never depended on MAME holding them. What HAS changed is
--      how MAME's own NATIVE outputs are discovered - see Enumerate_Native_Outputs.
--
--   2. emu.add_machine_reset_notifier -> on_start()
--      Fires on every reset of the current machine (including in-game soft resets,
--      not just the initial boot). Loads the ROM's JSON config, resolves memory
--      addresses, and engages the per-frame loop. Must NOT attempt output
--      registration - by the time this fires, the output table is always locked.
--
--   3. emu.add_machine_post_load_notifier -> on_post_load()
--      Save-state alignment only. Whatever outputs ARE part of the save state
--      (the driver's own natives - never MSOP's, see 1 above) snap to their
--      saved values on load; this hook re-seeds the engine's Lua-side delta
--      baselines, counters, and pulse timers to match, so the first frames
--      after a load can't fire phantom recoils/reloads or overwrite freshly
--      restored counters. Never registers outputs, never re-resolves config.
--
-- =========================================================================================

local exports = {
    name = "stateoutput",
    version = "9.1.0",
    description = "MAME State Output Project (MSOP)",
    license = "GNU GPL-v3.0",
    author = "Jacob Simpson (DJ GLiTCH)",

    -- [ CRITICAL MAME CONCEPT: Persistent Subscriptions ]
    -- In MAME's Lua API, event hooks (such as add_machine_reset_notifier) return a 
    -- "subscription object". If the Lua Garbage Collector clears these objects, MAME 
    -- will cease triggering the associated callbacks. By storing them in this global 
    -- `exports.subscriptions` table, we ensure they remain active for the duration 
    -- of the MAME session.

    subscriptions = {} 
}

local stateoutput = exports

-- =========================================================================
-- GENERAL USER SETTINGS
-- =========================================================================
local ENABLE_OSD = false -- Toggles "[MSOP]" On-Screen Display (OSD) messages. Console messages are always captured via -verbose command.

-- =========================================================================
-- CORE PLUGIN ENGINE
-- =========================================================================
function stateoutput.startplugin()
    
    -- -------------------------------------------------------------------------
    -- SAFE MODULE LOADING
    -- pcall (Protected Call) is used to load the database safely. If the 
    -- database.lua file is missing or has a syntax error, pcall prevents 
    -- MAME from crashing and instead gracefully handles the failure.
    -- -------------------------------------------------------------------------
    local success, db = pcall(require, "stateoutput/database")
    if not success then
        success, db = pcall(require, "database") -- Fallback for flat directories
        if not success then db = {} end
    end

    -- native_outputs_by_rom.lua is optional and independent of database.lua: it's
    -- machine-generated by msop_native_outputs_compiler.py scraping a MAME
    -- source checkout for NATIVE outputs (a game driver's own C++-created
    -- outputs, e.g. "lamp0" - never anything MSOP creates itself), and is
    -- allowed to be missing entirely (a user who never ran that compiler, or
    -- a stale/older copy) - native-output forwarding just degrades to
    -- whatever database.lua's own hand-curated ADDITIONAL_OUTPUT_FORWARDS
    -- provides, per-game, if this file isn't there. See on_start()'s
    -- _NativeForwards resolution and Forward_Native_Outputs() below.
    local success_driver, driver_db = pcall(require, "stateoutput/native_outputs_by_rom")
    if not success_driver then
        success_driver, driver_db = pcall(require, "native_outputs_by_rom")
        if not success_driver then driver_db = {} end
    end

    -- native_outputs_by_driver.lua (v9.0.4) is the DRIVER-keyed companion to the ROM-keyed table
    -- above, and is equally optional. MAME declares its output_finder<> fields once per driver
    -- SOURCE FILE and every ROM that file builds shares them, so one entry per driver covers
    -- every ROM in it - clones, parents that are never launchable in their own right, and any
    -- ROM MAME adds to an existing driver later. Pass-through mode consults it when a ROM has
    -- no entry of its own, which is what lets a game MSOP has no profile for still deliver its
    -- lamps/recoil. Missing file = the v9.0.2 behaviour exactly (per-ROM entries only).
    local success_mame_driver, mame_driver_db = pcall(require, "stateoutput/native_outputs_by_driver")
    if not success_mame_driver then
        success_mame_driver, mame_driver_db = pcall(require, "native_outputs_by_driver")
        if not success_mame_driver then mame_driver_db = {} end
    end

    -- ---------------------------------------------------------------------
    -- RELAY MODE (per-INSTANCE, stamped by the MSOP Configurator)
    -- ---------------------------------------------------------------------
    -- Whether THIS MAME install should deliver its state outputs through the
    -- MSOP Configurator's TCP relay (127.0.0.1:8000) instead of relying on
    -- MAME's own output module. The Configurator decides this per instance
    -- from the MAME VERSION and the chosen `-output` mode and stamps it into
    -- THIS PLUGIN'S OWN MANIFEST after every install/update - plugin.json's
    -- "plugin" object gains a `"relay": true/false` member (MAME's loader
    -- ignores members it doesn't know; this manifest already carries MSOP's
    -- dateplugin/datedatabase/channel fields the same way). The pristine zip
    -- ships WITHOUT the member, so a manual install carries no stale verdict:
    --
    --   relay = TRUE  when this build CANNOT self-deliver custom outputs:
    --       * MAME >= 0.289 (Lua can no longer create outputs at all), OR
    --       * MAME <= 0.288 with -output none / console (outputs are created
    --         but MAME never broadcasts them to hookers).
    --   relay = FALSE when MAME broadcasts them itself and the relay must
    --       stay off the port:
    --       * MAME <= 0.288 with -output network (MAME's own server owns 8000
    --         - the plugin must NOT dial it, or it becomes a stray client), or
    --       * -output windows (MAME's Windows-message broadcast).
    --
    -- The stamp is only a FALLBACK. _UseRelay is AUTHORITATIVELY derived at
    -- runtime from MAME itself (version + -output mode) the first time
    -- on_start runs - see resolve_relay_mode() below - so the plugin is
    -- correct even on a manual install that never got stamped, or if the user
    -- hand-edited mame.ini's -output after install. The stamp is consulted
    -- INSIDE resolve_relay_mode, and only when that runtime detection is
    -- unavailable (an old build not exposing the options API). Nothing
    -- touches the relay before on_start, so no load-time read is needed at
    -- all.
    --
    -- Default when the stamp is absent AND runtime detection is unavailable:
    -- FALSE (never dial). Old MAME then works natively out of the box, and a
    -- >= 0.289 build is caught either by resolve_relay_mode()'s version gate
    -- or, failing that, the empirical safety net in Probe_Legacy_Set_Value
    -- (which flips this true the moment it confirms output creation is
    -- impossible) so 0.289 can't silently go dark.
    local _UseRelay = false
    local _RelayModeResolved = false   -- guards the one-time runtime resolution

    -- The currently active game's configuration dictionary
    local CFG = nil

    -- This ROM's resolved native-output forward list (see on_start): the
    -- union of database.lua's hand-curated ADDITIONAL_OUTPUT_FORWARDS and
    -- native_outputs_by_rom.lua's auto-scraped entry for this ROM, deduped.
    -- Resolved once per ROM load, not every frame - see Forward_Native_Outputs.
    local _NativeForwards = {}

    -- v9.0.4: pass-through proxies must NOT cache a negative result. A driver's outputs are
    -- created when its output_finder<> fields resolve at device start, which is normally before
    -- on_start runs - but "normally" is not "always" (a device started late, or an output only
    -- created on first write). Get_Output_Proxy caches `false` permanently, so one early miss
    -- would silently kill that name for the whole session. While this is true, misses are left
    -- uncached and simply retried on a later frame.
    local _RetryMissingProxies = false

    -- v9.1.0: _RegisterOutputSupported IS GONE - do not reintroduce it.
    -- It tracked whether this build had root:register_output(), the Lua-side
    -- output-CREATION API from mamedev/mame PR #15639. That PR was rejected
    -- upstream on design grounds (outputs are a static part of a machine
    -- configuration; letting scripts create them would make save states depend on
    -- which scripts were loaded), so no MAME build will ever ship it. The flag
    -- could therefore only ever read false, and every branch that consulted it has
    -- been simplified accordingly - see resolve_relay_mode's capability gate and
    -- Probe_Legacy_Set_Value's safety net.
    --   https://github.com/mamedev/mame/pull/15639  (creation - rejected)
    --   https://github.com/mamedev/mame/pull/15618  (the attempt before it)

    -- v9.1.0: can this build ENUMERATE a device's outputs (the device.outputs
    -- property)? This is read-only introspection - it lists the outputs a machine
    -- has already created and cannot bring one into existence, which is exactly why
    -- it is a proposal upstream can accept where #15639 was not. Probed once per
    -- session, lazily, by Enumerate_Native_Outputs; nil means "not yet asked".
    -- When absent, native-output discovery falls back to the scraped databases
    -- exactly as v9.0.4 did, so this plugin still runs unchanged on stock MAME.
    local _EnumerateOutputsSupported = nil

    -- Whether the deprecated output.set_value() can still AUTO-CREATE an output (true on
    -- <= 0.288, restricted on 0.289+ stock). This is the version-dependent capability that
    -- actually decides whether MAME can hold - and therefore broadcast - our outputs.
    -- Probe_Legacy_Set_Value (defined much further down, next to the setter it belongs to)
    -- fills these in; they live up here because resolve_relay_mode reads them, and a local
    -- declared later in the file is not in scope for a function compiled earlier.
    local _LegacyCreateProbed = false
    local _LegacyCreateWorks = true

    -- v9.0.4: which TCP port the relay dials. 8000 is the protocol's own port and stays the
    -- default, so a manual install behaves exactly as before. MESH moves it (per install, via
    -- plugin.json's "relayport") when it wants MAME's -output network server to own 8000
    -- instead - see Resolve_Relay_Port. MAME's port is hard-coded and its protocol is
    -- broadcast-only, so moving OURS is the only way the two can run side by side.
    local _RelayPort = 8000
    -- True only when plugin.json pinned the port explicitly. A stamp is authoritative;
    -- without one the port is derived from MAME's -output mode (see Resolve_Relay_Port).
    local _RelayPortStamped = false

    -- Plugin identity published as the MSOP_LuaVersion / MSOP_LuaDate outputs.
    -- KEEP IN SYNC with the header + exports.version above (910 == v9.1.0).
    -- These deliberately do NOT come from the database: CFG.LUA_VERSION /
    -- CFG.LUA_DATE describe the DATABASE release, not this script.
    local PLUGIN_VERSION_NUM = 910
    local PLUGIN_DATE_NUM    = 20260722
    
    -- -------------------------------------------------------------------------
    -- ENGINE STATE VARIABLES
    -- These variables persist across all 60 frames of a single second, tracking 
    -- what happened in the past to calculate triggers in the present.
    -- -------------------------------------------------------------------------
    local _HasCoinedUp = false
    local _IsShuttingDown = false
    local _GameActiveTick
    local _GameInactiveTick
    local _LastGlobalCredits = 0
    local _GlobalCreditsInserted = 0
    local _PendingGlobalCreditDrops = 0
    local _RomIdNum = 0 -- numeric ROM identity for MSOP_LuaROMid (see on_start)
    
    -- Hardware Caching Arrays (Performance Optimization)
    -- Instead of searching MAME's entire device tree 60 times a second, we 
    -- find the memory addresses ONCE at boot and store direct pointers here.
    local _MemConfig = {}
    local _MemHandles = {}
    local _HardwareBound = false
    
    local _PlayerCFG = {}
    local _OutputNames = {}
    local _GlobalOutputs = {}

    -- True only when this game's primary ammo is a real depleting clip, which is the only case where
    -- the derived P*_Clip output is meaningful. Resolved once per ROM load (Resolve_Addresses_And_Strings).
    local _ClipEnabled = false
    
    -- Hardware Timers (FFB active duration tracking)
    local _RecoilDuration, _RecoilAltDuration, _RecoilGrenadeDuration, _MinRecoilInterval
    local _RecoilHoldInterval, _ReloadDuration, _DamageDuration, _RumbleDuration
    local _StartupTime, _ZeroTime
    -- Per-ROM attotime CONSTANTS, resolved once in on_start (like the durations above).
    -- Previously these were rebuilt with emu.attotime.from_* on EVERY frame inside
    -- Frame_Logic (the debounce compare runs once globally + once per player, ~5 fresh
    -- userdata objects a frame = ~300/sec into the GC), which is exactly the hot-path
    -- allocation the closure-hoisting elsewhere in this engine set out to eliminate.
    local _StatusDebounce, _CreditsClearTimeout
    
    local _Player = {}
    local _GlobalLastOutputs = {}
    local _WarmupFlushed = false

    -- =========================================================================
    -- MSOP RELAY TRANSPORT LAYER
    -- =========================================================================
    -- Ships every MSOP_* value change (plus native MAME lifecycle events) to
    -- the MSOP Configurator's relay service over a plain TCP socket, so
    -- hooker software (MAMEhooker, QMamehook, HOTR) can consume them without
    -- any MAME core patch. This exists because stock MAME 0.289+ removes the
    -- last Lua-side path for creating a new output (register_output is gone;
    -- see Set_Output_Safe above) - the relay is the only delivery mechanism
    -- that still works once that door closes, not an optional add-on.
    --
    -- Three stages, in call order, for a per-output value (Set_Output_Safe
    -- is this pipeline's only caller):
    --   1. msop_out()               - per-output change filter -> payload_buffer
    --   2. (Frame_Logic runs, calling msop_out for whatever it touched)
    --   3. flush_payload_to_relay() - one write() of the whole frame's diff
    -- broadcast_native_event() is a separate, parallel path used only for
    -- the three lifecycle pings (mame_start/mame_stop/pause) - see its own
    -- comment for why those can't go through the buffered path above.
    --
    -- msop_out() is a no-op whenever not connected - there's no flush to ever
    -- receive whatever it would buffer, and payload_buffer would otherwise
    -- grow without bound for as long as the relay stays down. Whatever
    -- changed during a disconnect is never replayed frame-by-frame; instead
    -- Resync_Relay_State() (defined right after msop_out) pushes every
    -- currently-tracked output's real current value the moment a (re)connect
    -- succeeds, so a hooker that connects (or reconnects) mid-session isn't
    -- left with stale/blank state for anything that simply isn't changing
    -- right now.
    -- =========================================================================
    local sock = nil
    local connected = false
    local first_frame_seeded = false

    -- RECONNECT BACK-OFF (v9.0.4) ------------------------------------------------------
    -- A FAILED dial blocks the emulation thread for however long the OS takes to refuse
    -- the connection. On a machine that answers with RST that is under a millisecond and
    -- none of this matters; on one where something local drops loopback SYNs instead
    -- (firewall/security software - measured at a consistent ~2.04s, on every port and
    -- every loopback address) connect() waits out the SYN retransmit first. emu.file's
    -- open is a plain blocking connect() with no timeout knob and MAME is not ours to
    -- change, so the stall per attempt is immovable - only how OFTEN we attempt is ours.
    --
    -- This used to be a frame counter ("> 60"), which is not a wall-clock cadence at all:
    -- one dial per second of EMULATED time, and far more often than that under
    -- -nothrottle. Against a ~2s stall that is unwinnable, and it pinned MAME at ~45% of
    -- realtime for as long as nothing was listening.
    --
    -- Note a SUCCESSFUL connect is effectively free - only failures cost - which is what
    -- makes it worth staying eager in the case where success is likely.
    local RETRY_WARM_FIRST = 2.0   -- first gap after losing a connection we HAD
    local RETRY_COLD_FIRST = 5.0   -- first gap when nothing has ever answered
    local RETRY_MAX        = 15.0  -- hard cap; worst case one stall per 15s
    local next_retry_at = 0        -- monotonic deadline; 0 = free to dial right now
    local retry_backoff = 0        -- current gap, doubled on each consecutive failure
    local ever_connected = false   -- warm vs cold: has a relay EVER answered this session?

    -- Monotonic wall-clock seconds. emu.osd_ticks is MAME's own cross-platform monotonic
    -- source (QueryPerformanceCounter on Windows, clock_gettime elsewhere), so this reads
    -- the same on all three platforms. Deliberately NOT os.clock(), which returns wall
    -- time on Windows but consumed CPU time on Linux/macOS - and MAME being multithreaded
    -- and CPU-bound, the POSIX reading would run ahead of realtime and shrink every gap
    -- below. os.time() is the fallback if the binding is ever missing: 1-second
    -- granularity, which is coarse but perfectly adequate for gaps measured in seconds.
    local _TickRate = 0
    local function monotonic_seconds()
        if _TickRate == 0 then
            local ok, rate = pcall(emu.osd_ticks_per_second)
            _TickRate = (ok and type(rate) == "number" and rate > 0) and rate or -1
        end
        if _TickRate > 0 then
            local ok, ticks = pcall(emu.osd_ticks)
            if ok and type(ticks) == "number" then return ticks / _TickRate end
            _TickRate = -1 -- binding present but unusable; fall through for good
        end
        return os.time()
    end

    -- Arms the next dial for `gap` seconds from now. Called on every failed connect and
    -- on every genuine disconnect; cleared by a successful connect and at each ROM start.
    local function arm_relay_retry(gap)
        retry_backoff = gap
        next_retry_at = monotonic_seconds() + gap
    end

    -- True when the back-off says we may dial again. Every path that opens the socket
    -- goes through this, so no single one of them can reintroduce a per-frame stall.
    local function relay_retry_due()
        return monotonic_seconds() >= next_retry_at
    end

    local last_state = {}
    -- Array of pending "name = value\r\n" lines, joined into ONE string at flush time
    -- (table.concat). A plain string accumulator here would re-copy the whole buffer on
    -- every append (Lua strings are immutable) - quadratic exactly when it matters most,
    -- the full-vocabulary burst Resync_Relay_State() builds on every (re)connect.
    local payload_buffer = {}
    local changes_detected = false

    -- Forward-declared: defined right after msop_out (needs it in scope),
    -- called from connect_socket() below on every successful (re)connect.
    local Resync_Relay_State

    -- Opens (or re-opens) the relay connection. emu.file's "socket.<host>:<port>"
    -- URI is a stock MAME Lua idiom for a plain TCP client, not something
    -- specific to this relay. last_state is wiped on every successful
    -- (re)connect: the Configurator's relay service has no memory of frames
    -- sent before a disconnect, so the next flush must re-send every current
    -- value as if it were new, or the relay/hookers would silently miss
    -- whatever changed while the socket was down. Wiping last_state alone
    -- only catches values that happen to change again after reconnecting -
    -- Resync_Relay_State() is what actually forces a resend of everything
    -- else (see its own comment for why that's necessary).
    local function connect_socket()
        -- Relay disabled for this install (old MAME delivering natively): never dial
        -- 8000. On <= 0.288 + network that port is MAME's OWN output server, and
        -- connecting to it would make this plugin a stray client of MAME itself.
        if not _UseRelay then return end
        sock = emu.file("w")
        local err = sock:open("socket.127.0.0.1:" .. _RelayPort)

        if not err then
            connected = true
            -- Back-off resets on success, and `ever_connected` latches for the rest of
            -- the session: from here on a drop is a WARM case (something was there a
            -- moment ago, so retrying promptly is worth the risk of one stall).
            retry_backoff = 0
            next_retry_at = 0
            ever_connected = true
            print("[MSOP] Connected to Relay on port " .. _RelayPort)
            last_state = {}
            -- Only a genuine no-op before any ROM has loaded/warmed up this
            -- session (nothing to resync yet - the normal warmup flush
            -- covers that case on its own). When it does resync, mark this
            -- frame as already-seeded so flush_payload_to_relay's own
            -- absorb-first-frame guard (below) doesn't discard the payload
            -- Resync_Relay_State just built.
            if Resync_Relay_State() then
                first_frame_seeded = true
            end
        else
            if sock then sock:close() end
            sock = nil
            connected = false
            -- Failed dial - and on an affected machine we have just cost the player ~2s
            -- of frozen emulation to learn it. Double the gap (capped), or open at the
            -- warm/cold gap if this is the first failure of a run.
            if retry_backoff > 0 then
                arm_relay_retry(math.min(retry_backoff * 2, RETRY_MAX))
            elseif ever_connected then
                arm_relay_retry(RETRY_WARM_FIRST)
            else
                arm_relay_retry(RETRY_COLD_FIRST)
            end
        end
    end

    -- Shared by both write paths (this one and flush_payload_to_relay
    -- below): tears down the connection after ANY failed or zero-byte
    -- write, since a half-closed TCP socket doesn't reliably surface as an
    -- error until the next syscall - treating any write failure as "the
    -- connection is gone" is simpler and safer than trying to distinguish
    -- a transient failure from a dead peer. Leaving connected=true after a
    -- failed write (as broadcast_native_event used to) is worse than just
    -- losing that one message: connect_socket() is only ever attempted
    -- while connected is false, so a stale true would silently block every
    -- later reconnect attempt too - including, worst case, the next ROM's
    -- own mame_start after a mid-process ROM switch.
    local function teardown_connection()
        print("[MSOP] Connection dropped by Relay")
        connected = false
        first_frame_seeded = false
        -- A genuine disconnect is the WARM case the back-off exists to serve well: the
        -- relay was up moments ago (MESH restarting, most likely), so a prompt retry is
        -- very likely to succeed - and succeeding costs nothing. Start the ladder at
        -- RETRY_WARM_FIRST rather than letting the previous run's gap carry over.
        arm_relay_retry(RETRY_WARM_FIRST)
        if sock then sock:close() end
        sock = nil
        -- Drop any unsent frame diff with the connection. It could only ever be sent
        -- AFTER a reconnect, and connect_socket()'s Resync_Relay_State() already re-sends
        -- every tracked output at its real current value then - replaying a stale
        -- pre-disconnect diff in front of that would be redundant lines at best.
        payload_buffer = {}
        changes_detected = false
    end

    -- Lifecycle pings (mame_start/mame_stop/pause) bypass payload_buffer
    -- entirely and write immediately. They're one-shot events with no "last
    -- value" to diff against, and they can't wait for the next
    -- flush_payload_to_relay() call - that only runs from Compute_Outputs,
    -- which may not fire again for a while (or ever, right after mame_stop).
    -- Also opportunistically opens the connection if it isn't up yet, so a
    -- mame_start sent before the engine's first frame still gets through -
    -- subject to the same reconnect back-off as the frame path, since a
    -- failed dial is equally expensive whichever path made it.
    -- A failed write here tears the connection down the same way a failed
    -- flush does (see teardown_connection) - previously this discarded the
    -- pcall's result entirely, so a dead write left connected=true pointing
    -- at a closed socket until something else eventually noticed.
    local function broadcast_native_event(event_string)
        if not _UseRelay then return end -- native-delivery install: MAME emits lifecycle itself
        -- Opportunistic open, but through the same back-off gate as the frame path: these
        -- fire on pause/unpause too, which a player can produce at will, and each failed
        -- dial stalls the emulation thread just as expensively from here.
        if not connected and relay_retry_due() then
            connect_socket()
        end

        if connected and sock then
            -- pcall with explicit args (sock.write is what `sock:write(...)` sugar resolves
            -- to) - no throwaway closure allocated per event, unlike pcall(function() ... end).
            local success, bytes_written = pcall(sock.write, sock, event_string)
            if not success or bytes_written == 0 then
                teardown_connection()
            end
        end
    end

    -- The relay's only per-output entry point (called exclusively from
    -- Set_Output_Safe). This is the single de-dup point for the whole relay
    -- pipeline: only a genuine change gets appended to payload_buffer, which
    -- is what keeps a busy frame's relay traffic to "what actually moved"
    -- instead of the full output vocabulary every 1/60s. last_state here is
    -- independent of MAME's own output table - Set_Output_Safe separately
    -- writes the live proxy, and on_post_load's adopt() reads that proxy
    -- directly rather than this table, so the two can never disagree in a
    -- way that matters.
    --
    -- Skipped entirely while disconnected: there's no flush that will ever
    -- read payload_buffer in that state (flush_payload_to_relay's own
    -- disconnected branch returns before touching it), so buffering changes
    -- no one can receive would just grow payload_buffer without bound for as
    -- long as the relay stays down.
    local function msop_out(out_name, val)
        if not _UseRelay or not connected then return end
        if val ~= last_state[out_name] then
            payload_buffer[#payload_buffer + 1] = string.format("%s = %d\r\n", out_name, val)
            last_state[out_name] = val
            changes_detected = true
        end
    end

    -- -------------------------------------------------------------------------
    -- Resync_Relay_State()
    -- Called once from connect_socket() right after a successful (re)connect.
    -- Wiping last_state there isn't enough by itself to make the relay's next
    -- flush include every current value: Set_Output / Set_Global_Output only
    -- ever reach msop_out when a value differs from their OWN LastOutputs /
    -- _GlobalLastOutputs caches, and those are untouched by a socket
    -- reconnect (only on_start and on_post_load clear them). Left alone,
    -- anything holding steady at the moment of reconnect - the current ammo
    -- count, an active STATUS flag, a lit lamp - would never reach msop_out
    -- again until it next genuinely changes, leaving a freshly (re)connected
    -- hooker with stale/blank state for it until then.
    --
    -- This replays every currently-tracked name at its real current value
    -- (never zero) straight through msop_out; last_state was just wiped by
    -- the caller, so each one is correctly treated as new and lands in the
    -- next flush. MAME's own output table already holds the right value from
    -- before the disconnect, so only the relay needs the nudge - no need to
    -- touch Set_Output_Safe or re-write the native proxy.
    --
    -- Returns false (and does nothing) before any ROM has loaded/warmed up
    -- this session - there's nothing to resync yet, and the normal warmup
    -- flush (Register_Outputs_Safe) already covers that case on its own.
    -- Returns true when it actually resynced something, so connect_socket()
    -- knows to pre-seed first_frame_seeded (see its own comment).
    -- -------------------------------------------------------------------------
    Resync_Relay_State = function()
        if not CFG or not _WarmupFlushed then return false end

        for key, name in pairs(_GlobalOutputs) do
            msop_out(name, _GlobalLastOutputs[key] or 0)
        end

        for i = 1, CFG.MAX_PLAYERS do
            local p = _Player[i]
            local names = _OutputNames[i]
            if p and names then
                for key, name in pairs(names) do
                    msop_out(name, p.LastOutputs[key] or 0)
                end
            end
        end

        return true
    end

    -- Sends one frame's accumulated diff as a single write(), called at the
    -- very end of Compute_Outputs. Three things worth knowing:
    --   - Reconnect attempts are paced by the back-off (see arm_relay_retry),
    --     not by this function's call rate, so a genuinely dead relay costs
    --     one blocking connect per gap - 15s at the cap - instead of turning
    --     every frame into one.
    --   - first_frame_seeded normally guards against a burst on the very
    --     first connect of a session: last_state was just wiped by
    --     connect_socket(), so without this, every already-nonzero output
    --     from Frame_Logic's first pass would look like a fresh change and
    --     flood the relay the moment the socket opens. In practice this
    --     branch is only actually reached before any ROM has loaded/warmed
    --     up - connect_socket() pre-seeds first_frame_seeded whenever
    --     Resync_Relay_State() has real state to send, so a mid-session
    --     reconnect's resync payload goes out on the very next flush instead
    --     of being silently discarded here.
    --   - A failed or zero-byte write tears down the whole connection via
    --     teardown_connection() (rather than just skipping this frame's
    --     payload), because a half-closed TCP socket doesn't reliably
    --     surface as an error until the next syscall - treating any write
    --     failure as "the connection is gone" and forcing a full reconnect
    --     is simpler and safer than trying to distinguish a transient
    --     failure from a dead peer.
    local function flush_payload_to_relay()
        if not _UseRelay then return end -- native-delivery install: nothing to flush over TCP
        if not connected then
            if relay_retry_due() then connect_socket() end
            return
        end

        if changes_detected then
            if not first_frame_seeded then
                first_frame_seeded = true
                payload_buffer = {}
                changes_detected = false
                -- v9.1.0: msop_out already recorded every value in this discarded
                -- payload as "sent". Without wiping last_state, anything whose FIRST
                -- appearance landed on the seed frame would be marked delivered while
                -- its line was thrown away here, and would never be sent again until
                -- it genuinely changed - or never at all if it holds steady all
                -- session. That silently swallowed native outputs in particular: they
                -- are forwarded from the very first frame, long before warmup, so the
                -- whole native set landed on exactly this payload. Clearing the table
                -- costs one re-announcement on the next flush and makes the discard
                -- what it was always meant to be - a deferral, not a data loss.
                last_state = {}
                return
            end

            -- One join, one write, no per-flush closure (see broadcast_native_event).
            local payload = table.concat(payload_buffer)
            local success, bytes_written = pcall(sock.write, sock, payload)

            if not success or bytes_written == 0 then
                teardown_connection()
            end

            payload_buffer = {}
            changes_detected = false
        end
    end

    -- -------------------------------------------------------------------------
    -- LOGGING HELPERS
    -- -------------------------------------------------------------------------
    local function dbg_print(msg)
        -- Always prints to stdout (captured using MAME's -verbose log)
        print("[MSOP] " .. tostring(msg))
    end
    
    local function dbg_osd(msg)
        -- On-Screen Display (OSD) remains restricted to the ENABLE_OSD flag or your Config flag
        local use_osd = ENABLE_OSD or (CFG and CFG.ENABLE_OSD)
        if use_osd and manager and manager.machine then
            manager.machine:popmessage("[MSOP] " .. tostring(msg))
        end
    end

    -- -------------------------------------------------------------------------
    -- Resolve_Relay_Port()
    -- Reads plugin.json's optional "relayport" member (written per install by MESH,
    -- exactly like the "relay" flag) and adopts it for this session. Absent/invalid
    -- leaves the stock 8000, so a MANUAL install is unaffected and the shipped zip
    -- carries no port stamp at all. Walks pluginspath the same way the relay stamp
    -- lookup does - entries may be ';'-separated and relative, as MAME resolves them.
    -- Called once, before the first connect attempt.
    -- -------------------------------------------------------------------------
    local function Resolve_Relay_Port()
        local ok_pp, plugin_paths = pcall(function()
            return manager.machine.options.entries["pluginspath"]:value()
        end)
        if not ok_pp or type(plugin_paths) ~= "string" then return end
        for raw_dir in plugin_paths:gmatch("[^;]+") do
            local dir = raw_dir
            local ok_sub, expanded = pcall(function() return emu.subst_env(raw_dir) end)
            if ok_sub and type(expanded) == "string" and #expanded > 0 then dir = expanded end
            local f = io.open(dir .. "/stateoutput/plugin.json", "r")
            if f then
                local text = f:read("*a") or ""
                f:close()
                local p = tonumber(text:match('"relayport"%s*:%s*(%d+)'))
                if p and p > 0 and p < 65536 then
                    _RelayPort = p
                    _RelayPortStamped = true
                    dbg_print("Relay port: " .. p .. " (plugin.json relayport stamp)")
                end
                return -- manifest found; stamped or not, stop probing
            end
        end
    end

    -- Pass 38: DERIVE the relay decision from MAME itself, at runtime, so the plugin no
    -- longer depends on the Configurator having stamped a correct relay flag. Runs
    -- ONCE, from on_start (machine fully up, before any relay use). Mirrors exactly what
    -- the Configurator computes for an instance's "needs relay":
    --   * emu.app_version() >= 0.289  -> Lua can't create outputs at all -> relay REQUIRED.
    --   * -output none / console      -> outputs created but MAME never broadcasts them ->
    --                                    relay REQUIRED.
    --   * -output network / windows   -> MAME self-delivers -> relay OFF (the plugin must
    --                                    stay off port 8000 or it becomes a stray client).
    -- Both facts are read straight from MAME (emu.app_version + the resolved -output
    -- option, verified against luaengine.cpp: core_options.entries[name]:value()). It is
    -- authoritative whenever it can read either fact; when it can't (option not exposed on
    -- a very old build, or an unresolved "auto" mode) it leaves the flag-file default in
    -- place. The empirical safety net in Probe_Legacy_Set_Value still has the final say and
    -- can only ever upgrade FALSE -> TRUE (never the reverse), so a mis-detected 0.289 that
    -- slips through here is still caught the instant a real output-create attempt fails.
    local function resolve_relay_mode()
        if _RelayModeResolved then return end
        _RelayModeResolved = true

        -- The port is independent of the mode decision below: whether or not the relay is
        -- used, knowing where it lives costs nothing and must be settled before any dial.
        pcall(Resolve_Relay_Port)

        -- Read the resolved -output mode once; both the port derivation immediately below and
        -- the delivery gate further down need it.
        local out_mode
        do
            local ok_out, m = pcall(function()
                return manager.machine.options.entries["output"]:value()
            end)
            if ok_out and type(m) == "string" then out_mode = m:lower() end
        end

        -- DERIVED PORT (v9.0.4). MAME's own -output network server binds a hard-coded 8000, so
        -- when it is running we must not be there: dialling 8000 in that state makes this plugin
        -- a stray client of MAME, whose protocol discards everything but "mame_message". Step
        -- aside to 8001 and let MAME have its port.
        --
        -- Every other mode leaves 8000 free, and 8000 is the port every hooker program looks
        -- for, so we take it - that way whatever is listening on 8000 is always the richest
        -- stream available. NOTE that -output windows is NOT network: it delivers over Win32
        -- registered window messages and binds no socket at all, so 8000 stays ours.
        --
        -- An explicit stamp always wins (MESH pinning a port, or a hand-edited manifest).
        if not _RelayPortStamped and out_mode == "network" then
            _RelayPort = 8001
            dbg_print("Relay port: 8001 (derived - MAME's own -output network server owns 8000)")
        end

        -- SPLIT-PORT. Being on a port other than 8000 - stamped by MESH, or derived above
        -- because MAME's own network server owns 8000 - means the two are running side by
        -- side. That outranks BOTH gates below, in particular the -output network branch,
        -- which would otherwise switch the relay off on the assumption that MAME
        -- self-delivers. On 0.289+ it cannot: MAME is unable to create (and therefore
        -- broadcast) MSOP's outputs at all, which is exactly why we are on our own port.
        if _RelayPort ~= 8000 then
            _UseRelay = true
            dbg_print("Relay mode: ENABLED (split-port - MSOP on " .. _RelayPort
                      .. ", MAME's own output server free to use 8000)")
            return
        end

        -- CAPABILITY GATE (v9.0.4; simplified in v9.1.0). Ground truth, and it outranks both
        -- inferences below. Ask this build whether it can hold a custom output at all. As of
        -- v9.1.0 there is exactly ONE route left to ask about - the deprecated
        -- output.set_value(), probed for real by Probe_Legacy_Set_Value. The second route this
        -- gate used to consider, register_output, was PR 15639's and exists nowhere; see the
        -- note where _RegisterOutputSupported used to be declared. If set_value can't create,
        -- MAME cannot store our outputs, so it cannot broadcast them in ANY -output mode, and
        -- the relay is the only delivery path there is.
        --
        -- This is what closes the -output windows hole: the mode gate below reads "windows" as
        -- "MAME self-delivers and the relay must stay off", which is correct for a real
        -- <= 0.288 and wrong for a 0.289-code build that merely REPORTS 0.288 (custom builds,
        -- and MAME's own pre-release window). Asking the binary removes the guesswork, and the
        -- same rule covers network, console, none and anything added later.
        --
        -- Dropping register_output from this condition does NOT widen it: that flag was false
        -- on every stock build anyway, so `not _RegisterOutputSupported` was already true
        -- everywhere this gate could fire. The probe was, and remains, the deciding term.
        --
        -- Only ever forces the relay ON, never off.
        if _LegacyCreateProbed and not _LegacyCreateWorks then
            _UseRelay = true
            dbg_print("Relay mode: ENABLED (this build cannot create custom outputs - "
                      .. "MAME has nothing of ours to broadcast in any -output mode)")
            return
        end

        -- Version gate: >= 0.289 forces the relay regardless of -output mode.
        local ok_ver, ver = pcall(function() return emu.app_version() end)
        if ok_ver and type(ver) == "string" then
            local maj, min = ver:match("(%d+)%.(%d+)")
            if maj then
                if tonumber(maj) > 0 or tonumber(min) >= 289 then
                    _UseRelay = true
                    dbg_print("Relay mode: ENABLED (MAME " .. ver .. " >= 0.289 - no native output creation)")
                    return
                end
            end
        end

        -- Output-mode gate for <= 0.288.
        local ok_out, mode = pcall(function()
            return manager.machine.options.entries["output"]:value()
        end)
        if ok_out and type(mode) == "string" then
            mode = mode:lower()
            if mode == "none" or mode == "console" then
                _UseRelay = true
                dbg_print("Relay mode: ENABLED (-output " .. mode .. " - created but not broadcast)")
                return
            elseif mode == "network" or mode == "windows" then
                _UseRelay = false
                dbg_print("Relay mode: disabled (-output " .. mode .. " - MAME self-delivers)")
                return
            end
        end

        -- Indeterminate (option not exposed on this build, or an unresolved "auto"):
        -- fall back to the per-install stamp the Configurator wrote into this plugin's
        -- own manifest - plugin.json's `"relay": true/false` member. Located through
        -- the SAME options table the output gate above just used (pluginspath can be a
        -- ';'-separated list, entries may be relative to MAME's working directory -
        -- exactly how MAME itself resolves them). Everything pcall-guarded: a missing
        -- file/member simply keeps the safe default (false) and the Probe_Legacy
        -- safety net still covers a dark 0.289.
        local ok_pp, plugin_paths = pcall(function()
            return manager.machine.options.entries["pluginspath"]:value()
        end)
        if ok_pp and type(plugin_paths) == "string" then
            for raw_dir in plugin_paths:gmatch("[^;]+") do
                -- Loop variables are <const> in Lua 5.5 - expand into a fresh local.
                local dir = raw_dir
                local ok_sub, expanded = pcall(function() return emu.subst_env(raw_dir) end)
                if ok_sub and type(expanded) == "string" and #expanded > 0 then dir = expanded end
                local f = io.open(dir .. "/stateoutput/plugin.json", "r")
                if f then
                    local text = f:read("*a") or ""
                    f:close()
                    local flag = text:match('"relay"%s*:%s*(%a+)')
                    if flag == "true" then
                        _UseRelay = true
                        dbg_print("Relay mode: ENABLED (plugin.json relay stamp - runtime auto-detect unavailable)")
                        return
                    elseif flag == "false" then
                        _UseRelay = false
                        dbg_print("Relay mode: disabled (plugin.json relay stamp - runtime auto-detect unavailable)")
                        return
                    end
                    break -- manifest found but unstamped (manual install) - stop probing
                end
            end
        end
        dbg_print("Relay mode: " .. (_UseRelay and "ENABLED" or "disabled") ..
                  " (default - runtime auto-detect unavailable and no plugin.json relay stamp)")
    end

    -- -------------------------------------------------------------------------
    -- fnv1a_31(s)
    -- Deterministic 31-bit FNV-1a hash of a string. Used to derive a stable,
    -- positive s32 ROM id for the MSOP_LuaROMid output when the database
    -- entry doesn't supply an explicit LUA_ROM_ID. Stable across plugin and
    -- database updates because it depends only on the ROM's short name.
    -- -------------------------------------------------------------------------
    local function fnv1a_31(s)
        local h = 2166136261
        for idx = 1, #s do
            h = h ~ string.byte(s, idx)
            h = (h * 16777619) & 0xFFFFFFFF
        end
        return h & 0x7FFFFFFF
    end

    -- -------------------------------------------------------------------------
    -- deep_merge(default_cfg, game_cfg)
    -- Layers a specific ROM's values over the '_default' template.
    -- Ensures that `CFG` always contains every required key, preventing
	-- "nil value" crashes during the frame loop if a ROM JSON was sparse.
    -- -------------------------------------------------------------------------
    local function deep_merge(default_cfg, game_cfg)
        local result = {}
        for k, v in pairs(default_cfg) do
            if type(v) == "table" then result[k] = deep_merge(v, {}) else result[k] = v end
        end
        for k, v in pairs(game_cfg) do
            if type(v) == "table" and type(result[k]) == "table" then result[k] = deep_merge(result[k], v)
            else result[k] = v end
        end
        return result
    end

    -- -------------------------------------------------------------------------
    -- normalize_variables(config)
    -- Translates legacy variable names to modern internal names.
    -- -------------------------------------------------------------------------
    local function normalize_variables(config)
        for i = 1, config.MAX_PLAYERS do
            local p_cfg = config["P"..i]
            if p_cfg then
                if p_cfg.LAMP_START ~= nil and p_cfg.LAMPSTART == nil then p_cfg.LAMPSTART = p_cfg.LAMP_START end
            end
        end
        if config.DATA_WIDTHS then
            if config.DATA_WIDTHS.LAMP_START ~= nil and config.DATA_WIDTHS.LAMPSTART == nil then config.DATA_WIDTHS.LAMPSTART = config.DATA_WIDTHS.LAMP_START end
        end
        if config.OUTPUT_SUFFIXES then
            if config.OUTPUT_SUFFIXES.LAMP_START ~= nil and config.OUTPUT_SUFFIXES.LAMPSTART == nil then config.OUTPUT_SUFFIXES.LAMPSTART = config.OUTPUT_SUFFIXES.LAMP_START end
        end
        if config.CPU_TAGS then
            if config.CPU_TAGS.LAMP_START ~= nil and config.CPU_TAGS.LAMPSTART == nil then config.CPU_TAGS.LAMPSTART = config.CPU_TAGS.LAMP_START end
        end
        if config.MEMORY_SPACES then
            if config.MEMORY_SPACES.LAMP_START ~= nil and config.MEMORY_SPACES.LAMPSTART == nil then config.MEMORY_SPACES.LAMPSTART = config.MEMORY_SPACES.LAMP_START end
        end
        return config
    end

    -- -------------------------------------------------------------------------
    -- convert_hex_strings_to_numbers(t)
    -- Recursively converts JSON hex strings ("0x00FF") to integers.
    -- JSON files cannot store hexadecimal numbers. They must be saved 
    -- as strings. But MAME's memory reader requires raw numbers. This 
    -- function fixes that translation limitation automatically at boot.
    -- -------------------------------------------------------------------------
    local function convert_hex_strings_to_numbers(t)
        for k, v in pairs(t) do
            if type(v) == "table" then convert_hex_strings_to_numbers(v)
            elseif type(v) == "string" and string.match(v, "^0x%x+$") then
                local num = tonumber(v)
                if num then t[k] = num end
            end
        end
    end

    -- -------------------------------------------------------------------------
    -- Resolve_Addresses_And_Strings()
    -- Pre-calculates heavy string/math operations before the game starts.
    -- String manipulation (e.g., string.lower) is very CPU intensive in Lua. 
    -- By doing it once here, we save thousands of CPU cycles per second.
    -- It also automatically generates P2/P3/P4 memory addresses based on 
    -- P1's offset math.
    -- -------------------------------------------------------------------------
    local function Resolve_Addresses_And_Strings()
        -- Normalize logical evaluation strings
        CFG.AMMO_DIRECTION             = string.lower(tostring(CFG.AMMO_DIRECTION or ""))
        CFG.AMMO_ALT_DIRECTION         = string.lower(tostring(CFG.AMMO_ALT_DIRECTION or ""))
        CFG.AMMO_GRENADE_DIRECTION     = string.lower(tostring(CFG.AMMO_GRENADE_DIRECTION or ""))

        -- P*_Clip (v9.0.1) is a DERIVED "do I still have ammo" flag: 1 while ammo > 0, 0 the moment it
        -- hits 0 (i.e. a reload is needed). It is only published for a genuinely DEPLETING clip, because
        -- that is the only reading where 0 unambiguously means empty:
        --   * "decrease" -> a real clip counting down to 0. Emitted.
        --   * increase   -> the address is a shots-FIRED counter, so 0 means a FULL clip and the flag
        --                   would be exactly inverted. Never emitted.
        --   * "change"   -> direction is unknown, so it carries the same inversion risk. Never emitted.
        -- Games whose ammo climbs (or can swap gun types mid-game, changing an unknown maximum) simply
        -- do not expose P*_Clip at all, rather than publish a reload signal that could be wrong.
        _ClipEnabled = (CFG.AMMO_DIRECTION == "decrease")
        CFG.LIFE_DIRECTION             = string.lower(tostring(CFG.LIFE_DIRECTION or ""))
        CFG.LIFE_ALT_DIRECTION         = string.lower(tostring(CFG.LIFE_ALT_DIRECTION or ""))
        CFG.SHOTS_FIRED_METHOD         = string.lower(tostring(CFG.SHOTS_FIRED_METHOD or "trigger"))
        CFG.SHOTS_FIRED_ALT_METHOD     = string.lower(tostring(CFG.SHOTS_FIRED_ALT_METHOD or "trigger"))
        CFG.SHOTS_FIRED_GRENADE_METHOD = string.lower(tostring(CFG.SHOTS_FIRED_GRENADE_METHOD or "trigger"))
        CFG.FORCE_FEEDBACK_ENABLER     = string.lower(tostring(CFG.FORCE_FEEDBACK_ENABLER or "both"))
        CFG.RECOIL_METHOD              = string.lower(tostring(CFG.RECOIL_METHOD or "pulse"))
        CFG.RECOIL_PRIORITY            = string.lower(tostring(CFG.RECOIL_PRIORITY or "ammo"))

        if CFG.DATA_WIDTHS then
            for k, v in pairs(CFG.DATA_WIDTHS) do
                if type(v) == "string" then CFG.DATA_WIDTHS[k] = string.lower(v) end
            end
        end

        local data_types = {
            "SCREEN_FLASH", "GLOBAL_ATTRACT_STATUS", "GLOBAL_CREDITS", "GLOBAL_GAME_STATUS",
            "CREDITS", "STATUS", "STATUS_ALT", "AMMO", "AMMO_ALT", "AMMO_GRENADE", "LIFE", "LIFE_ALT",
            "RECOIL", "RELOAD", "DAMAGE", "RUMBLE", "LAMPSTART",
            "SHOTS_FIRED_PRIMARY", "SHOTS_FIRED_ALT", "SHOTS_FIRED_GRENADE", "LIFE_LOST", "DAMAGE_TAKEN"
        }

        local function Resolve_Mem_Path(val, global_val)
            if val == nil or val == false or val == "" or string.lower(tostring(val)) == "auto" then return global_val end
            return tostring(val)
        end

        -- -------------------------------------------------------------------------
        -- MAP CPU TAGS AND MEMORY SPACES
        -- By default, MSOP targets the ":maincpu" and its "program" address space.
        --
        -- ADVANCED FEATURE: The "region" Memory Space
        -- If a specific variable's MEMORY_SPACE is set to "region" in the game's JSON,
        -- the plugin will bypass the CPU's logical address map and interface directly 
        -- with MAME's raw physical memory regions (manager.machine.memory.regions).
        -- 
        -- WHEN TO USE "region": 
        -- Use this exclusively when you need to write/patch instructions into Read-Only 
        -- Memory (ROM), such as applying a 'Screen Flash Disable' patch. MAME natively 
        -- blocks write attempts to ROM if routed through standard CPU spaces ("program").
        -- -------------------------------------------------------------------------
        for _, key in ipairs(data_types) do
            local t = Resolve_Mem_Path(CFG.CPU_TAGS and CFG.CPU_TAGS[key], CFG.CPU_TAG or ":maincpu")
            local s = Resolve_Mem_Path(CFG.MEMORY_SPACES and CFG.MEMORY_SPACES[key], CFG.MEMORY_SPACE or "program")
            _MemConfig[key] = { tag = t, space = s }
        end

        -- P*_Clip is DERIVED rather than read from a memory address, so databases predating v9.0.1
        -- carry no OUTPUT_SUFFIXES entry for it. Default one in here - after the game/_default merge
        -- but before the names are pre-compiled - so the output exists without needing a database
        -- rebuild. A game that defines its own CLIP suffix still wins.
        CFG.OUTPUT_SUFFIXES = CFG.OUTPUT_SUFFIXES or {}
        if CFG.OUTPUT_SUFFIXES.CLIP == nil then CFG.OUTPUT_SUFFIXES.CLIP = "Clip" end

        -- Pre-compile the MAME output broadcast strings (e.g. "MSOP_P1_Ammo")
        for i = 1, CFG.MAX_PLAYERS do
            _OutputNames[i] = {}
            for key, suffix in pairs(CFG.OUTPUT_SUFFIXES) do
                if not string.match(key, "^GLOBAL_") then
                    local target_p = i
                    if not CFG.SIMULTANEOUS_PLAY and (key == "RECOIL" or key == "RELOAD" or key == "DAMAGE" or key == "RUMBLE" or key == "LAMPSTART") then target_p = 1 end
                    
                    -- CRITICAL UPDATE: Add MSOP_ prefix
                    _OutputNames[i][key] = "MSOP_P" .. target_p .. "_" .. tostring(suffix)
                end
            end
            local target_p_ctm = (not CFG.SIMULTANEOUS_PLAY) and 1 or i
            
            -- DemulShooter-compat aliases are emitted WITHOUT the MSOP_ prefix, so DemulShooter reads
            -- them under its own expected output names (P<n>_CtmRecoil / P<n>_Damaged / P<n>_CtmLmpStart).
            _OutputNames[i]["CtmRecoil"]   = "P" .. target_p_ctm .. "_CtmRecoil"
            _OutputNames[i]["Damaged"]     = "P" .. target_p_ctm .. "_Damaged"
            _OutputNames[i]["CtmLmpStart"] = "P" .. target_p_ctm .. "_CtmLmpStart"
        end
        
        for key, suffix in pairs(CFG.OUTPUT_SUFFIXES) do
            -- Add MSOP_ prefix to global outputs
            if string.match(key, "^GLOBAL_") then _GlobalOutputs[key] = "MSOP_" .. tostring(suffix) end
        end

        -- Process "auto" variables
        local all_players = { CFG.P1, CFG.P2, CFG.P3, CFG.P4 }
        for _, p_cfg in ipairs(all_players) do
            for k, val in pairs(p_cfg) do
                if type(val) == "string" and string.lower(val) == "auto" then p_cfg[k] = "auto" end
            end
        end

        -- Ensure hardware "auto" states gracefully disable if they have no underlying Ammo/Life data to track
        local p1_hardware = { "RECOIL", "RELOAD", "DAMAGE", "RUMBLE", "LAMPSTART", "STATUS", "STATUS_ALT" }
        for _, key in ipairs(p1_hardware) do
            if CFG.P1[key] == "auto" then
                if key == "STATUS" or key == "STATUS_ALT" then -- leave as auto
                elseif key == "RECOIL" and (CFG.P1.AMMO or CFG.P1.AMMO_ALT or CFG.P1.AMMO_GRENADE) then
                elseif key == "RELOAD" and (CFG.P1.AMMO or CFG.P1.AMMO_ALT or CFG.P1.AMMO_GRENADE) then
                elseif key == "DAMAGE" and (CFG.P1.LIFE or CFG.P1.LIFE_ALT) then
                elseif key == "LAMPSTART" then
                else CFG.P1[key] = false end
            end
        end

        -- Execute math to generate P2/P3/P4 hex strings based on the multiplier offset
        local standard_offset = tonumber(CFG.PLAYER_MEMORY_OFFSET) or 0
        local credit_offset = tonumber(CFG.PLAYER_CREDIT_MEMORY_OFFSET) or standard_offset
        local player_tables = { CFG.P2, CFG.P3, CFG.P4 }

        for i, p_cfg in ipairs(player_tables) do
            local multiplier = i 
            for key, val in pairs(p_cfg) do
                if val == "auto" then
                    local p1_val = CFG.P1[key]
                    local offset_to_use = (key == "CREDITS") and credit_offset or standard_offset
                    if type(p1_val) == "number" then
                        p_cfg[key] = p1_val + (offset_to_use * multiplier)
                    elseif type(p1_val) == "string" and string.match(p1_val, "^0x") then
                        local p1_num = tonumber(p1_val)
                        if p1_num then p_cfg[key] = string.format("0x%08X", p1_num + (offset_to_use * multiplier)) end
                    elseif p1_val == "auto" then p_cfg[key] = "auto"
                    else p_cfg[key] = false end
                end
            end
        end
        _PlayerCFG = { CFG.P1, CFG.P2, CFG.P3, CFG.P4 }
    end

    local function Is_Warmup_Complete() return manager.machine.time > _StartupTime end

    -- -------------------------------------------------------------------------
    -- Value_Is_Active(val, active_spec)
    -- Tests a polled memory value against a configured "active" specification.
    -- active_spec may be: a table of acceptable values, a single number, or
    -- nil/false (meaning "any positive value counts as active").
    --
    -- PERFORMANCE NOTE: this replaces four near-identical inline checks that
    -- were previously written as immediately-invoked anonymous functions
    -- (e.g. `(function() for _,v in ipairs(t) do ... end end)()`). Each of
    -- those allocated a brand new closure every time it ran - up to several
    -- times per player, per frame, 60 times a second. Defining the check
    -- once here means zero closure allocation in the hot path.
    -- -------------------------------------------------------------------------
    local function Value_Is_Active(val, active_spec)
        if type(active_spec) == "table" then
            for _, v in ipairs(active_spec) do
                if val == v then return true end
            end
            return false
        elseif type(active_spec) == "number" then
            return val == active_spec
        else
            -- nil/false mean "any positive value counts as active"; any other
            -- spec type (e.g. an unresolved "auto" string surviving config
            -- resolution) is treated as never-active - this exactly matches
            -- the original inline logic, which only fell through to val > 0
            -- when the spec was falsy
            return (not active_spec) and (val > 0)
        end
    end

    -- -------------------------------------------------------------------------
    -- OUTPUT PROXY CACHE & SAFE SETTER
    -- Transparently handles modern fast-proxies (MAME 0.289+) and
    -- legacy set_value fallbacks (MAME 0.288-) without crashing.
    -- -------------------------------------------------------------------------
    local _ProxyCache = {}

    -- (v9.1.0 removed the _RegisterOutputSupported flag that used to be described
    -- here; PR 15639's register_output does not exist on any build. The set_value
    -- probe below is now the only capability question worth asking.)

    -- Whether the deprecated output.set_value() can still auto-create a
    -- brand new output on first use (true on MAME 0.288 and earlier) or has
    -- been restricted to only ever resolve EXISTING outputs (0.289+ stock,
    -- where it's a guaranteed no-op for every synthetic MSOP_ name, since
    -- none of them exist without PR 15639's register_output). There's no
    -- direct way to ask the Lua API which behaviour applies, and guessing
    -- from a version number wouldn't reliably cover every custom/patched
    -- build - so Probe_Legacy_Set_Value (below) tests it empirically, once,
    -- and remembers the answer for the rest of the session.

    -- The one-time test itself, using a disposable name that's never part
    -- of any real vocabulary and a value no real output write would ever
    -- coincidentally produce - probing with whatever the first real call
    -- happens to pass isn't reliable, since 0 (very often the first value
    -- ever written, e.g. from Register_Outputs_Safe's warmup zero-flush)
    -- is indistinguishable from get_value's own default for a name that
    -- was never created. Verified against get_value - the SAME legacy API
    -- family set_value belongs to, not device:output()'s newer per-device
    -- proxy lookup, which is a different binding onto (as far as this Lua
    -- engine exposes it) a namespace that doesn't necessarily reflect what
    -- set_value just wrote. Cross-checking against the wrong API here
    -- previously produced a false "doesn't work" reading on real MAME
    -- 0.287/0.288, where set_value is exactly the mechanism
    -- init_v8.2.5.lua relied on entirely and genuinely does still create
    -- new outputs - silently breaking native output delivery there for the
    -- rest of the session.
    local function Probe_Legacy_Set_Value(out_handle)
        if _LegacyCreateProbed then return end
        if not out_handle or not out_handle.set_value or not out_handle.get_value then return end

        _LegacyCreateProbed = true
        local PROBE_NAME = "MSOP_LegacyCreateProbe"
        local PROBE_VALUE = 123456789

        -- COMPATIBILITY TEST (harmless) - announced so the console reads as intentional.
        -- The very next line deliberately asks MAME to create a throwaway output through the
        -- deprecated output.set_value(), purely to discover whether THIS build still lets a
        -- plugin create state outputs at all. On MAME 0.289 and newer that capability was
        -- removed, so MAME prints its OWN "unknown output"/creation error on the line right
        -- after this one. That error is EXPECTED, is not a fault in MSOP or the game, and can
        -- be safely ignored - MSOP reads the result either way and, when creation is
        -- unavailable, switches to relay delivery automatically.
        dbg_print("COMPATIBILITY TEST: probing whether this MAME build can create state outputs "
                  .. "(via the deprecated output.set_value). If a MAME error/warning appears on "
                  .. "the NEXT line, that is EXPECTED on MAME 0.289+ (output creation was removed) "
                  .. "- it is harmless and MSOP falls back to the relay automatically.")

        pcall(function() out_handle:set_value(PROBE_NAME, PROBE_VALUE) end)
        local ok, got = pcall(function() return out_handle:get_value(PROBE_NAME) end)
        _LegacyCreateWorks = ok and got == PROBE_VALUE

        if _LegacyCreateWorks then
            dbg_print("COMPATIBILITY TEST passed: this MAME build CAN create state outputs "
                      .. "(MAME 0.288 or earlier behaviour) - no error above was expected.")
        end

        if not _LegacyCreateWorks then
            dbg_print("COMPATIBILITY TEST result: this MAME build CANNOT create state outputs (expected on MAME 0.289+ - any output error above was the test, not a fault). No further attempts will be made this session; the relay is delivering everything.")
            -- SAFETY NET: set_value is the last route by which MAME itself could hold one
            -- of our outputs (v9.1.0: register_output, the other one, is gone for good -
            -- PR 15639 was rejected). With it confirmed dead, custom outputs are
            -- structurally impossible in MAME, so the relay is the ONLY delivery path.
            -- Force it on even if the plugin.json relay stamp was never written (e.g. a
            -- 0.289 dev build the Configurator hadn't been told about), so 0.289+ can never
            -- silently go dark. Reached only when the probe has just failed, so this still
            -- cannot turn the relay on for an old build that self-delivers.
            if not _UseRelay then
                _UseRelay = true
                dbg_print("Relay auto-enabled (native output creation is impossible on this build).")
                -- on_start's mame_start ping was suppressed while _UseRelay was false, so
                -- resend it now that the relay is live, or a hooker connecting fresh would
                -- never learn which game to load its profile for.
                local rok, rname = pcall(function() return manager.machine.system.name end)
                if rok and rname then broadcast_native_event("mame_start = " .. rname .. "\r\n") end
            end
        end
    end

    -- Calls the deprecated set_value fallback, but only for as long as it's
    -- worth calling. Resolving the probe from here (rather than waiting for
    -- some later, guaranteed-non-zero call) means even the very first real
    -- write this session - typically Register_Outputs_Safe's own warmup
    -- zero-flush - already knows whether to bother, instead of a whole
    -- batch of zero-value writes going out unconditionally before a
    -- naturally-occurring non-zero value ever arrives to settle the
    -- question.
    local function Try_Legacy_Set_Value(out_handle, name, value)
        if not out_handle or not out_handle.set_value then return end
        Probe_Legacy_Set_Value(out_handle) -- no-op after the first call
        if not _LegacyCreateWorks then return end

        out_handle:set_value(name, value)
    end

    local function Get_Output_Proxy(name, out_handle)
        if _ProxyCache[name] ~= nil then return _ProxyCache[name] end

        local proxy = false

        if manager and manager.machine and manager.machine.devices then
            local root_dev = manager.machine.devices[":"]
            if root_dev and root_dev.output then
                local s2, p = pcall(function() return root_dev:output(name) end)

                -- Validate that the proxy actually connects to hardware
                if s2 and p and p:exists() then
                    proxy = p
                else
                    proxy = false
                end
            end
        end

        if not proxy then
            Try_Legacy_Set_Value(out_handle, name, 0)
            -- Pass-through (v9.0.4): a name that isn't there YET may appear once its device
            -- finishes starting, so don't poison the cache with a permanent false.
            if _RetryMissingProxies then return false end
        end

        _ProxyCache[name] = proxy
        return proxy
    end

    local function Set_Output_Safe(out_handle, name, value)
        -- Outputs are integers everywhere downstream: MAME's output system stores s32,
        -- and the relay wire format is "%d" (matching network.cpp's own integer-only
        -- protocol). A fractional value CAN legitimately arrive here - Read_Data_Safe's
        -- float32/float32be widths (Model 2/3 games) return raw floats - and Lua 5.4+
        -- string.format("%d", 2.5) throws "number has no integer representation", which
        -- would surface as a FRAME ERROR every frame for such a game. Round once at this
        -- single choke point (covers both the relay and the native write below); for the
        -- integer values every other path produces, floor(v + 0.5) is the same integer.
        value = math.floor(value + 0.5)

        -- Always broadcast to the Relay - this is the only delivery path on
        -- 0.289+ stock MAME, where Lua can no longer create new outputs at all
        -- (register_output is gone; both output_proxy and the deprecated
        -- output.set_value() only ever resolve EXISTING outputs).
        msop_out(name, value)

        -- Also write MAME's own output table wherever that's still possible -
        -- which since v9.1.0 means only genuinely old stock builds, where the
        -- deprecated set_value can still auto-create (see Try_Legacy_Set_Value
        -- for how that stops being attempted once it's confirmed futile).
        -- Restores save-state persistence and on_post_load's adopt() recovery
        -- wherever creation did succeed.
        local proxy = Get_Output_Proxy(name, out_handle)
        if proxy then
            proxy:set(value)
        else
            Try_Legacy_Set_Value(out_handle, name, value)
        end
    end

    -- -------------------------------------------------------------------------
    -- Read_Data_Safe(mem_handle, source, width)
    -- Universal memory polling adapter
    --    8, 16, 32    -> Reads standard Unsigned Integers
    --    "float32"    -> Reads 32-bit Little Endian Floats (Modern 3D games)
    --    "float32be"  -> Reads 32-bit Big Endian Floats (Sega Model 2/3)
    --    "output"     -> Reads an existing MAME software output instead of RAM
    -- -------------------------------------------------------------------------
    local function Read_Data_Safe(mem_handle, source, width)
        if not source then return 0 end
        
        if type(width) == "string" then
            if width == "output" then
                -- Reuse Get_Output_Proxy to get the memory-mapped pointer
                local proxy = Get_Output_Proxy(source, nil)
                
                if proxy then
                    -- Modern 0.289+ Fast Path: read directly from the proxy object
                    return proxy:get()
                elseif manager.machine.output and manager.machine.output.get_value then
                    -- Legacy 0.288- Fallback: string lookup
                    local native_val = manager.machine.output:get_value(source)
                    return type(native_val) == "number" and native_val or (native_val and 1 or 0)
                end
                return 0
                
            elseif width == "float32" and mem_handle then
                local val = mem_handle:read_u32(source)
                return string.unpack("f", string.pack("I4", val))
                
            elseif width == "float32be" and mem_handle then
                local val = mem_handle:read_u32(source)
                val = ((val & 0xFF) << 24) | ((val & 0xFF00) << 8) | ((val & 0xFF0000) >> 8) | ((val & 0xFF000000) >> 24)
                return string.unpack("f", string.pack("I4", val))
            end
            return 0
        end

        if not mem_handle then return 0 end
        if width == 16 then return mem_handle:read_u16(source) end
        if width == 32 then return mem_handle:read_u32(source) end
        if width == 64 then return mem_handle:read_u64(source) end
        return mem_handle:read_u8(source)
    end
    
    -- -------------------------------------------------------------------------
    -- Write_Data_Safe(mem_handle, source, width, value)
    -- Active memory patching adapter. Injects values into RAM.
    -- Used primarily to disable visual hazards (like white flashes)
    -- by hard-locking memory addresses to a specific value.
    -- -------------------------------------------------------------------------
    local function Write_Data_Safe(mem_handle, source, width, value)
        if not source or not mem_handle or not value then return end
        if type(width) == "string" then return end -- Outputs/Floats not supported for memory patching
        if width == 16 then mem_handle:write_u16(source, value)
        elseif width == 32 then mem_handle:write_u32(source, value)
        elseif width == 64 then mem_handle:write_u64(source, value)
        else mem_handle:write_u8(source, value) end
    end

    -- -------------------------------------------------------------------------
    -- Register_Outputs_Safe(out_handle)
    -- Flushes outputs to zero at boot and synchronizes local caches.
    -- Prevents external hardware (like DemulShooter or lighting apps) 
    -- from sticking 'ON' if a previous game crashed or ended abruptly.
    -- Forces a true 0-state broadcast over the MAME TCP socket and 
    -- aligns the local Lua spam-filter to guarantee accurate tracking.
    -- -------------------------------------------------------------------------
    local function Register_Outputs_Safe(out_handle)
        if not out_handle then return end

        local function Sync_Global(key, value)
            if _GlobalOutputs[key] then
                Set_Output_Safe(out_handle, _GlobalOutputs[key], value)
                _GlobalLastOutputs[key] = value
            end
        end
        
        Sync_Global("GLOBAL_GAME_STATUS", 0)
        Sync_Global("GLOBAL_ATTRACT_STATUS", 0)
        -- Plugin identity comes from THIS script's constants, not the
        -- database: CFG.LUA_VERSION/LUA_DATE describe the database release
        -- (8.3.3 published them as MSOP_LuaVersion/LuaDate, so a 2026.07.01
        -- database reported 831/20260701 no matter which plugin was running).
        Sync_Global("GLOBAL_LUA_VERSION", PLUGIN_VERSION_NUM)
        Sync_Global("GLOBAL_LUA_DATE", PLUGIN_DATE_NUM)
        Sync_Global("GLOBAL_LUA_ROM_ID", _RomIdNum)
        
        if CFG.CREDITS then 
            Sync_Global("GLOBAL_CREDITS", 0)
            Sync_Global("GLOBAL_CREDITS_INSERTED", 0)
        end
        
        for i = 1, CFG.MAX_PLAYERS do
            local p_cfg = _PlayerCFG[i] 
            
            local function Sync_Output(cfg_key, out_key)
                if p_cfg[cfg_key] and _OutputNames[i][out_key] then
                    Set_Output_Safe(out_handle, _OutputNames[i][out_key], 0)
                    _Player[i].LastOutputs[out_key] = 0
                end
            end
            
            local function Sync_Force(out_key)
                if _OutputNames[i][out_key] then
                    Set_Output_Safe(out_handle, _OutputNames[i][out_key], 0)
                    _Player[i].LastOutputs[out_key] = 0
                end
            end
            
            Sync_Output("STATUS", "STATUS")
            Sync_Output("STATUS_ALT", "STATUS_ALT")
            
            if p_cfg.CREDITS then 
                Sync_Output("CREDITS", "CREDITS")
                Sync_Output("CREDITS", "CREDITS_INSERTED")
                Sync_Output("CREDITS", "CREDITS_CONSUMED")
            end
            
            local keys = {"AMMO", "AMMO_ALT", "AMMO_GRENADE", "LIFE", "LIFE_ALT", "DAMAGE", "RECOIL", "RELOAD", "RUMBLE", "LAMPSTART"}
            for _, k in ipairs(keys) do
                Sync_Output(k, k)
            end

            -- P*_Clip has no memory address of its own (it is derived from AMMO), so its reset is
            -- gated on AMMO being configured rather than on a "CLIP" config key that never exists.
            if _ClipEnabled then Sync_Output("AMMO", "CLIP") end
            
            -- Move DemulShooter overrides outside the loop to guarantee MAME registers them
            if CFG.DEMULSHOOTER_COMPATIBILITY then 
                Sync_Force("CtmRecoil")
                Sync_Force("Damaged")
            end
            
            if CFG.ENABLE_DAMAGE_COUNT and p_cfg.DAMAGE_TAKEN then Sync_Output("DAMAGE_TAKEN", "DAMAGE_TAKEN") end
            if CFG.ENABLE_SHOT_COUNT then 
                Sync_Force("SHOTS_FIRED")
                if p_cfg.SHOTS_FIRED_PRIMARY then Sync_Output("SHOTS_FIRED_PRIMARY", "SHOTS_FIRED_PRIMARY") end
                if p_cfg.SHOTS_FIRED_ALT then Sync_Output("SHOTS_FIRED_ALT", "SHOTS_FIRED_ALT") end
                if p_cfg.SHOTS_FIRED_GRENADE then Sync_Output("SHOTS_FIRED_GRENADE", "SHOTS_FIRED_GRENADE") end
            end
            if CFG.ENABLE_LIFE_LOST and p_cfg.LIFE_LOST then Sync_Output("LIFE_LOST", "LIFE_LOST") end
        end
    end

    -- -------------------------------------------------------------------------
    -- OUTPUT SPAM WRAPPERS:
    -- Only sends a command to MAME's output system if the value has actually
    -- changed. This drastically reduces TCP server load.
    --
    -- PERFORMANCE NOTE: these are defined once, here, at plugin-load scope -
    -- not inside Frame_Logic. They used to be declared with `local function`
    -- INSIDE Frame_Logic, which meant Lua allocated two brand new closures
    -- every single frame (60/sec) purely to hold onto `out`. That's exactly
    -- the kind of per-frame GC churn the Compute_Outputs/pcall restructuring
    -- below was written to avoid - it just crept back in one level down.
    -- `out` is now passed in explicitly instead of captured.
    -- -------------------------------------------------------------------------
    local function Set_Output(out, p_idx, key, value)
        local p = _Player[p_idx]
        if p.LastOutputs[key] ~= value and _OutputNames[p_idx][key] then
            Set_Output_Safe(out, _OutputNames[p_idx][key], value)
            p.LastOutputs[key] = value
        end
    end

    local function Set_Global_Output(out, key, value)
        -- Guard the name like Set_Output does: a game that overrides OUTPUT_SUFFIXES and
        -- omits a GLOBAL_ key would otherwise pass nil to Set_Output_Safe -> a per-frame
        -- error (caught by the Compute_Outputs pcall, but noisy). The real _default carries
        -- every global, so this only matters for hand-trimmed per-game suffix overrides.
        if _GlobalLastOutputs[key] ~= value and _GlobalOutputs[key] then
            Set_Output_Safe(out, _GlobalOutputs[key], value)
            _GlobalLastOutputs[key] = value
        end
    end

    -- -------------------------------------------------------------------------
    -- Seed_Frame_Baselines()
    -- Primes every Last* delta baseline from LIVE values the moment warmup
    -- completes, and again after a save state loads. Without this, every
    -- baseline starts at 0, so pre-existing values are booked as fresh
    -- deltas on the first tracked frame - on vcop2, 2 leftover NVRAM
    -- credits became "MSOP_GlobalCreditsInserted = 2" before a single coin
    -- was dropped. Reads mirror Frame_Logic's math exactly (divisor,
    -- offsets, MAX clamps) so frame 1 of tracking sees zero false movement.
    -- -------------------------------------------------------------------------
    local function Seed_Frame_Baselines()
        if not CFG then return end
        local divisor = CFG.COINS_PER_CREDIT or 1
        if divisor < 1 then divisor = 1 end

        if CFG.CREDITS and type(CFG.CREDITS) == "number" then
            local raw = Read_Data_Safe(_MemHandles["GLOBAL_CREDITS"], CFG.CREDITS, CFG.DATA_WIDTHS.GLOBAL_CREDITS)
            _LastGlobalCredits = math.floor(raw / divisor)
            if _LastGlobalCredits > 0 then _HasCoinedUp = true end
        end

        for i = 1, CFG.MAX_PLAYERS do
            local cfg = _PlayerCFG[i]
            local p = _Player[i]
            if cfg then
                if cfg.CREDITS and type(cfg.CREDITS) == "number" then
                    local raw = Read_Data_Safe(_MemHandles["CREDITS"], cfg.CREDITS, CFG.DATA_WIDTHS.CREDITS)
                    p.LastCredits = math.floor(raw / divisor)
                end
                if cfg.AMMO then
                    local v = Read_Data_Safe(_MemHandles["AMMO"], cfg.AMMO, CFG.DATA_WIDTHS.AMMO) + (CFG.AMMO_OFFSET or 0)
                    if CFG.AMMO_MAX and v > CFG.AMMO_MAX then v = 0 end
                    p.LastAmmo = v
                end
                if cfg.AMMO_ALT then
                    local v = Read_Data_Safe(_MemHandles["AMMO_ALT"], cfg.AMMO_ALT, CFG.DATA_WIDTHS.AMMO_ALT) + (CFG.AMMO_ALT_OFFSET or 0)
                    if CFG.AMMO_ALT_MAX and v > CFG.AMMO_ALT_MAX then v = 0 end
                    p.LastAmmoAlt = v
                end
                if cfg.AMMO_GRENADE then
                    local v = Read_Data_Safe(_MemHandles["AMMO_GRENADE"], cfg.AMMO_GRENADE, CFG.DATA_WIDTHS.AMMO_GRENADE) + (CFG.AMMO_GRENADE_OFFSET or 0)
                    if CFG.AMMO_GRENADE_MAX and v > CFG.AMMO_GRENADE_MAX then v = 0 end
                    p.LastAmmoGrenade = v
                end
                if cfg.LIFE then
                    local v = Read_Data_Safe(_MemHandles["LIFE"], cfg.LIFE, CFG.DATA_WIDTHS.LIFE) + (CFG.LIFE_OFFSET or 0)
                    if CFG.LIFE_MAX and v > CFG.LIFE_MAX then v = 0 end
                    p.LastLife = v
                end
                if cfg.LIFE_ALT then
                    local v = Read_Data_Safe(_MemHandles["LIFE_ALT"], cfg.LIFE_ALT, CFG.DATA_WIDTHS.LIFE_ALT) + (CFG.LIFE_ALT_OFFSET or 0)
                    if CFG.LIFE_ALT_MAX and v > CFG.LIFE_ALT_MAX then v = 0 end
                    p.LastLifeAlt = v
                end
                if type(cfg.DAMAGE_TAKEN) == "number" then
                    p.LastDmgMem = Read_Data_Safe(_MemHandles["DAMAGE_TAKEN"], cfg.DAMAGE_TAKEN, CFG.DATA_WIDTHS.DAMAGE_TAKEN)
                end
                if cfg.DAMAGE and type(cfg.DAMAGE) == "number" then
                    p.LastDamageVal = Read_Data_Safe(_MemHandles["DAMAGE"], cfg.DAMAGE, CFG.DATA_WIDTHS.DAMAGE)
                end
                if cfg.RUMBLE and type(cfg.RUMBLE) == "number" then
                    p.LastRumbleEventVal = Read_Data_Safe(_MemHandles["RUMBLE"], cfg.RUMBLE, CFG.DATA_WIDTHS.RUMBLE)
                end
                if cfg.RELOAD and type(cfg.RELOAD) == "number" then
                    p.LastReloadVal = Read_Data_Safe(_MemHandles["RELOAD"], cfg.RELOAD, CFG.DATA_WIDTHS.RELOAD)
                end
                if cfg.RECOIL and type(cfg.RECOIL) == "number" then
                    p.LastRecoilVal = Read_Data_Safe(_MemHandles["RECOIL"], cfg.RECOIL, CFG.DATA_WIDTHS.RECOIL)
                end
            end
        end
    end

    -- =========================================================================
    -- THE FRAME LOOP ENGINE (Frame_Logic)
    -- This is the heartbeat of the plugin. It evaluates memory conditions 60 
	-- times a second. It is isolated from the `pcall` wrapper below to prevent
	-- closure memory allocation (GC Spikes).
    -- =========================================================================
    local function Frame_Logic()
        local machine = manager.machine
        if not machine then _IsShuttingDown = true; return end
        
        local out = machine.output
        local current_time = machine.time
        if not out then return end
        
        -- -------------------------------------------------------------------------
        -- PERFORMANCE OPTIMIZATION: One-Time Bus Binding Cache
        -- Finds the specific MAME context only on frame 1, storing it locally.
        -- If the user configured a memory space as "region", we hook directly into the
        -- physical ROM memory region instead of the CPU address space to allow safe patching.
        -- -------------------------------------------------------------------------
        if not _HardwareBound then
            for key, conf in pairs(_MemConfig) do
                if string.lower(conf.space) == "region" then
                    local reg = machine.memory.regions[conf.tag]
                    if reg then _MemHandles[key] = reg end
                else
                    local dev = machine.devices[conf.tag]
                    if dev and dev.spaces[conf.space] then _MemHandles[key] = dev.spaces[conf.space] end
                end
            end
            _HardwareBound = true
        end
        
        -- -------------------------------------------------------------------------
        -- PHASE 0: WARMUP & INITIALIZATION FLUSH
        -- Ensures outputs are held silently during startup and perfectly
        -- synced the exact frame the boot delay expires.
        -- -------------------------------------------------------------------------
        local warmup_ok = Is_Warmup_Complete()
        
        -- Trigger initialization exactly when warmup completes
        if warmup_ok and not _WarmupFlushed then
            Register_Outputs_Safe(out)
            Seed_Frame_Baselines() -- prime Last* deltas from live values (no phantom "inserted" from NVRAM leftovers)
            _WarmupFlushed = true
            return -- Skip the rest of this frame so MAME actually broadcasts the '0' states!
        end
        
        local divisor = CFG.COINS_PER_CREDIT or 1
        if divisor < 1 then divisor = 1 end

        -- -------------------------------------------------------------------------
        -- PHASE 1: GLOBAL STATUS & ATTRACT MODE
        -- -------------------------------------------------------------------------
        local is_attract_mode = false
        if CFG.ATTRACT_STATUS and type(CFG.ATTRACT_STATUS) == "number" then
            local val = Read_Data_Safe(_MemHandles["GLOBAL_ATTRACT_STATUS"], CFG.ATTRACT_STATUS, CFG.DATA_WIDTHS.GLOBAL_ATTRACT_STATUS or 8)
            local active = CFG.ATTRACT_STATUS_ACTIVE_VALUE
            is_attract_mode = Value_Is_Active(val, active)
            Set_Global_Output(out, "GLOBAL_ATTRACT_STATUS", warmup_ok and (is_attract_mode and 1 or 0) or 0)
            if is_attract_mode then _PendingGlobalCreditDrops = 0 end
        end

        if CFG.CREDITS and type(CFG.CREDITS) == "number" then 
            local raw = Read_Data_Safe(_MemHandles["GLOBAL_CREDITS"], CFG.CREDITS, CFG.DATA_WIDTHS.GLOBAL_CREDITS)
            local current_credits = math.floor(raw / divisor)
            Set_Global_Output(out, "GLOBAL_CREDITS", warmup_ok and current_credits or 0)
            if warmup_ok then
                if current_credits > _LastGlobalCredits then
                    _GlobalCreditsInserted = _GlobalCreditsInserted + (current_credits - _LastGlobalCredits)
                    if CFG.ENABLE_CREDIT_COUNT then Set_Global_Output(out, "GLOBAL_CREDITS_INSERTED", _GlobalCreditsInserted) end
                elseif current_credits < _LastGlobalCredits then
                    _PendingGlobalCreditDrops = _PendingGlobalCreditDrops + (_LastGlobalCredits - current_credits)
                end
                _LastGlobalCredits = current_credits
            end
            if current_credits > 0 and warmup_ok then _HasCoinedUp = true end
        end

        local is_game_active = false
        local global_exists = false

        if CFG.GAME_STATUS and type(CFG.GAME_STATUS) == "number" then 
            global_exists = true
            if not is_attract_mode then
                local val = Read_Data_Safe(_MemHandles["GLOBAL_GAME_STATUS"], CFG.GAME_STATUS, CFG.DATA_WIDTHS.GLOBAL_GAME_STATUS)
                local active = CFG.GAME_STATUS_ACTIVE_VALUE
                is_game_active = Value_Is_Active(val, active)
            end
        end
        
        if is_game_active then
            if _GameActiveTick == _ZeroTime then _GameActiveTick = current_time end
            if (current_time - _GameActiveTick) <= _StatusDebounce then is_game_active = false end
        else
            _GameActiveTick = _ZeroTime; is_game_active = false
        end
        

        -- -------------------------------------------------------------------------
        -- PHASE 2: CORE PLAYER ITERATION
        -- Loops through P1, P2, P3, P4 sequentially.
        -- -------------------------------------------------------------------------
        local any_player_active = false
        local aggregated_credits = 0
        local using_individual_credits = false
        for i = 1, CFG.MAX_PLAYERS do
            local cfg = _PlayerCFG[i]
            local p = _Player[i]
            
            if is_attract_mode then p.PendingCreditDrops = 0 end
            
            -- Memory Polling Block
            local curr_ammo, curr_ammo_alt, curr_ammo_grenade, curr_life, curr_life_alt = 0, 0, 0, 0, 0
            
            if cfg.AMMO then 
                curr_ammo = Read_Data_Safe(_MemHandles["AMMO"], cfg.AMMO, CFG.DATA_WIDTHS.AMMO) + (CFG.AMMO_OFFSET or 0)
                if CFG.AMMO_MAX and curr_ammo > CFG.AMMO_MAX then curr_ammo = 0 end
            end
            if cfg.AMMO_ALT then 
                curr_ammo_alt = Read_Data_Safe(_MemHandles["AMMO_ALT"], cfg.AMMO_ALT, CFG.DATA_WIDTHS.AMMO_ALT) + (CFG.AMMO_ALT_OFFSET or 0)
                if CFG.AMMO_ALT_MAX and curr_ammo_alt > CFG.AMMO_ALT_MAX then curr_ammo_alt = 0 end
            end
            if cfg.AMMO_GRENADE then 
                curr_ammo_grenade = Read_Data_Safe(_MemHandles["AMMO_GRENADE"], cfg.AMMO_GRENADE, CFG.DATA_WIDTHS.AMMO_GRENADE) + (CFG.AMMO_GRENADE_OFFSET or 0)
                if CFG.AMMO_GRENADE_MAX and curr_ammo_grenade > CFG.AMMO_GRENADE_MAX then curr_ammo_grenade = 0 end
            end
            if cfg.LIFE then 
                curr_life = Read_Data_Safe(_MemHandles["LIFE"], cfg.LIFE, CFG.DATA_WIDTHS.LIFE) + (CFG.LIFE_OFFSET or 0)
                if CFG.LIFE_MAX and curr_life > CFG.LIFE_MAX then curr_life = 0 end
            end
            if cfg.LIFE_ALT then 
                curr_life_alt = Read_Data_Safe(_MemHandles["LIFE_ALT"], cfg.LIFE_ALT, CFG.DATA_WIDTHS.LIFE_ALT) + (CFG.LIFE_ALT_OFFSET or 0)
                if CFG.LIFE_ALT_MAX and curr_life_alt > CFG.LIFE_ALT_MAX then curr_life_alt = 0 end
            end

            -- Per-Player Credits processing
            local p_credits = 0
            local p_credits_known = false
            if cfg.CREDITS then
                if type(cfg.CREDITS) == "number" then 
                    local raw = Read_Data_Safe(_MemHandles["CREDITS"], cfg.CREDITS, CFG.DATA_WIDTHS.CREDITS)
                    p_credits = math.floor(raw / divisor)
                    p_credits_known = true
                    Set_Output(out, i, "CREDITS", warmup_ok and p_credits or 0)
                    
                    -- Aggregate individual credits for global override
                    aggregated_credits = aggregated_credits + p_credits
                    using_individual_credits = true
                    
                    if warmup_ok then
                        if p_credits > p.LastCredits then
                            p.CreditsInserted = p.CreditsInserted + (p_credits - p.LastCredits)
                            if CFG.ENABLE_CREDIT_COUNT then Set_Output(out, i, "CREDITS_INSERTED", p.CreditsInserted) end
                        elseif p_credits < p.LastCredits then
                            p.PendingCreditDrops = p.PendingCreditDrops + (p.LastCredits - p_credits)
                        end
                        p.LastCredits = p_credits
                    end
                elseif cfg.CREDITS == "auto" and CFG.CREDITS then 
                    p_credits = Read_Data_Safe(_MemHandles["GLOBAL_CREDITS"], CFG.CREDITS, CFG.DATA_WIDTHS.GLOBAL_CREDITS) 
                    p_credits_known = true
                    Set_Output(out, i, "CREDITS", warmup_ok and p_credits or 0)
                    
                    if warmup_ok then
                        if p_credits > p.LastCredits then
                            p.CreditsInserted = p.CreditsInserted + (p_credits - p.LastCredits)
                            if CFG.ENABLE_CREDIT_COUNT then Set_Output(out, i, "CREDITS_INSERTED", p.CreditsInserted) end
                        elseif p_credits < p.LastCredits then
                            p.PendingCreditDrops = p.PendingCreditDrops + (p.LastCredits - p_credits)
                        end
                        p.LastCredits = p_credits
                    end
                end
            end
            
            if cfg.LAMPSTART then
                local lampstart_val = warmup_ok and Read_Data_Safe(_MemHandles["LAMPSTART"], cfg.LAMPSTART, CFG.DATA_WIDTHS.LAMPSTART) or 0
                Set_Output(out, i, "LAMPSTART", lampstart_val)
                if CFG.DEMULSHOOTER_COMPATIBILITY then Set_Output(out, i, "CtmLmpStart", lampstart_val) end
            end

            local is_player_active = false
            local out_status_val = 0
            local out_status_alt_val = 0

            -- Priority Evaluation Hierarchy
            if not is_attract_mode then
                if (cfg.STATUS and cfg.STATUS ~= "auto") or (cfg.STATUS_ALT and cfg.STATUS_ALT ~= "auto") then
                    local p_stat_active = false
                    local p_stat_alt_active = false
                    if cfg.STATUS and cfg.STATUS ~= "auto" then
                        local val = Read_Data_Safe(_MemHandles["STATUS"], cfg.STATUS, CFG.DATA_WIDTHS.STATUS)
                        local act = cfg.STATUS_ACTIVE_VALUE or CFG.STATUS_ACTIVE_VALUE
                        p_stat_active = Value_Is_Active(val, act)
                    end
                    if cfg.STATUS_ALT and cfg.STATUS_ALT ~= "auto" then
                        local val = Read_Data_Safe(_MemHandles["STATUS_ALT"], cfg.STATUS_ALT, CFG.DATA_WIDTHS.STATUS_ALT)
                        local act = cfg.STATUS_ALT_ACTIVE_VALUE or CFG.STATUS_ALT_ACTIVE_VALUE
                        p_stat_alt_active = Value_Is_Active(val, act)
                    end
                    if global_exists then
                        if is_game_active and p_stat_active then out_status_val = 1 end
                        if is_game_active and p_stat_alt_active then out_status_alt_val = 1 end
                    else
                        if p_stat_active then out_status_val = 1 end
                        if p_stat_alt_active then out_status_alt_val = 1 end
                    end
                    if out_status_val == 1 or out_status_alt_val == 1 then is_player_active = true end
                elseif global_exists then
                    if is_game_active and (curr_life > 0 or curr_life_alt > 0) then is_player_active = true; out_status_val = 1; out_status_alt_val = 1 end
                else
                    if _HasCoinedUp and (curr_life > 0 or curr_life_alt > 0) and ((not p_credits_known) or p_credits > 0) then is_player_active = true; out_status_val = 1; out_status_alt_val = 1 end
                end
            end
            
            if not warmup_ok then is_player_active = false; out_status_val = 0; out_status_alt_val = 0 end
            
            if is_player_active then
                if p.ActiveTick == _ZeroTime then p.ActiveTick = current_time end
                if (current_time - p.ActiveTick) <= _StatusDebounce then is_player_active = false; out_status_val = 0; out_status_alt_val = 0 end
            else p.ActiveTick = _ZeroTime; out_status_val = 0; out_status_alt_val = 0 end
            
            p.IsActive = is_player_active
            if is_player_active then any_player_active = true end
            p.IsFFBAllowed = (CFG.FORCE_FEEDBACK_ENABLER == "status") and (out_status_val == 1 or out_status_alt_val == 1) or (CFG.FORCE_FEEDBACK_ENABLER == "life") and (curr_life > 0 or curr_life_alt > 0) or (CFG.FORCE_FEEDBACK_ENABLER == "gamestatus") and is_game_active or is_player_active
            
            if cfg.STATUS then Set_Output(out, i, "STATUS", out_status_val) end
            if cfg.STATUS_ALT then Set_Output(out, i, "STATUS_ALT", out_status_alt_val) end

            if CFG.ENABLE_CREDIT_COUNT and warmup_ok then
                local spawned = false
                
                -- Check 1: Did Player Status just change from inactive to active
                if is_player_active and not p.WasActive then
                    spawned = true
                    
                -- Check 2: Did life reset while Player Status remained active (for player continues)?
                -- The p.WasActive guard is what makes "remained active" real. Without it,
                -- an idle player whose offset-DERIVED life byte happens to move (vcop2:
                -- P2's auto address = P1+4 initializes the instant Start is pressed)
                -- spawn-steals the pending credit drop from the player who actually
                -- started - the log showed MSOP_P2_CreditsConsumed=1 on a P1-only game.
                elseif cfg.LIFE and p.WasActive then
                    if CFG.LIFE_DIRECTION == "decrease" and curr_life > p.LastLife and p.LastLife == 0 then spawned = true
                    elseif CFG.LIFE_DIRECTION == "increase" and curr_life < p.LastLife and curr_life == 0 then spawned = true end
                end
                
                if spawned then p.SpawnsAwaitingCredit = p.SpawnsAwaitingCredit + 1 end
                
                if p.SpawnsAwaitingCredit > 0 then
                    if p.PendingCreditDrops > 0 then
                        p.CreditsConsumed = p.CreditsConsumed + 1
                        p.PendingCreditDrops = p.PendingCreditDrops - 1
                        p.SpawnsAwaitingCredit = p.SpawnsAwaitingCredit - 1
                        Set_Output(out, i, "CREDITS_CONSUMED", p.CreditsConsumed)
                    elseif _PendingGlobalCreditDrops > 0 then
                        p.CreditsConsumed = p.CreditsConsumed + 1
                        _PendingGlobalCreditDrops = _PendingGlobalCreditDrops - 1
                        p.SpawnsAwaitingCredit = p.SpawnsAwaitingCredit - 1
                        Set_Output(out, i, "CREDITS_CONSUMED", p.CreditsConsumed)
                    end
                end
            end

            local just_died = (not is_player_active and p.WasActive)
            local primary_active = (out_status_val == 1)
            local alternate_active = (cfg.STATUS_ALT and cfg.STATUS_ALT ~= "auto") and (out_status_alt_val == 1) or primary_active

            -- -------------------------------------------------------------------------
            -- PHASE 3: HARDWARE TRIGGERS (Recoil & Reload)
            -- -------------------------------------------------------------------------
            local auto_recoil_triggered_this_frame = false
            local t_ammo = CFG.AMMO_THRESHOLD or 254
            local t_alt = CFG.AMMO_ALT_THRESHOLD or 254
            local t_grenade = CFG.AMMO_GRENADE_THRESHOLD or 254
            
            if p.IsFFBAllowed then
                  local trigger = 0
                  if CFG.ENABLE_RECOIL_AMMO ~= false and cfg.AMMO then
                      if CFG.AMMO_DIRECTION == "decrease" then if curr_ammo < p.LastAmmo and p.LastAmmo <= t_ammo then trigger = 1 end
                      elseif CFG.AMMO_DIRECTION == "change" then if curr_ammo ~= p.LastAmmo then trigger = 1 end
                      elseif curr_ammo > p.LastAmmo then trigger = 1 end
                  end
                  if CFG.ENABLE_RECOIL_AMMO_ALT ~= false and cfg.AMMO_ALT then
                      if CFG.AMMO_ALT_DIRECTION == "decrease" then if curr_ammo_alt < p.LastAmmoAlt and p.LastAmmoAlt <= t_alt then trigger = 2 end
                      elseif CFG.AMMO_ALT_DIRECTION == "change" then if curr_ammo_alt ~= p.LastAmmoAlt then trigger = 2 end
                      elseif curr_ammo_alt > p.LastAmmoAlt then trigger = 2 end
                  end
                  if CFG.ENABLE_RECOIL_AMMO_GRENADE ~= false and cfg.AMMO_GRENADE then
                      if CFG.AMMO_GRENADE_DIRECTION == "decrease" then if curr_ammo_grenade < p.LastAmmoGrenade and p.LastAmmoGrenade <= t_grenade then trigger = 3 end
                      elseif CFG.AMMO_GRENADE_DIRECTION == "change" then if curr_ammo_grenade ~= p.LastAmmoGrenade then trigger = 3 end
                      elseif curr_ammo_grenade > p.LastAmmoGrenade then trigger = 3 end
                  end
                  
                  -- Fire Recoil based on Ammo Math
                  if trigger > 0 and (cfg.RECOIL == "auto" or (type(cfg.RECOIL) == "number" and CFG.RECOIL_PRIORITY == "ammo")) then
                      if current_time - p.RecoilTick > _MinRecoilInterval then
                          if trigger == 1 then p.CurrentRecoilDuration = _RecoilDuration
                          elseif trigger == 2 then p.CurrentRecoilDuration = _RecoilAltDuration
                          elseif trigger == 3 then p.CurrentRecoilDuration = _RecoilGrenadeDuration end
                          
                          Set_Output(out, i, "RECOIL", 1); if CFG.DEMULSHOOTER_COMPATIBILITY then Set_Output(out, i, "CtmRecoil", 1) end
                          p.RecoilTick = current_time; p.IsRecoilActive = true; auto_recoil_triggered_this_frame = true
                          if not CFG.SIMULTANEOUS_PLAY and i > 1 then _Player[1].RecoilTick = current_time; _Player[1].IsRecoilActive = true end
                      end
                  end
                  
                  -- Fire Reload based on Ammo Math
                  if CFG.ENABLE_RELOAD_AMMO ~= false and cfg.AMMO then
                      if (CFG.AMMO_DIRECTION == "decrease" and curr_ammo > p.LastAmmo) or (CFG.AMMO_DIRECTION == "increase" and curr_ammo < p.LastAmmo) then
                          if cfg.RELOAD then Set_Output(out, i, "RELOAD", 1); p.ReloadTick = current_time; p.IsReloadActive = true; if not CFG.SIMULTANEOUS_PLAY and i > 1 then _Player[1].ReloadTick = current_time; _Player[1].IsReloadActive = true end end
                      end
                  end
                  if CFG.ENABLE_RELOAD_AMMO_ALT ~= false and cfg.AMMO_ALT then
                      if (CFG.AMMO_ALT_DIRECTION == "decrease" and curr_ammo_alt > p.LastAmmoAlt) or (CFG.AMMO_ALT_DIRECTION == "increase" and curr_ammo_alt < p.LastAmmoAlt) then
                          if cfg.RELOAD then Set_Output(out, i, "RELOAD", 1); p.ReloadTick = current_time; p.IsReloadActive = true; if not CFG.SIMULTANEOUS_PLAY and i > 1 then _Player[1].ReloadTick = current_time; _Player[1].IsReloadActive = true end end
                      end
                  end
                  if CFG.ENABLE_RELOAD_AMMO_GRENADE ~= false and cfg.AMMO_GRENADE then
                      if (CFG.AMMO_GRENADE_DIRECTION == "decrease" and curr_ammo_grenade > p.LastAmmoGrenade) or (CFG.AMMO_GRENADE_DIRECTION == "increase" and curr_ammo_grenade < p.LastAmmoGrenade) then
                          if cfg.RELOAD then Set_Output(out, i, "RELOAD", 1); p.ReloadTick = current_time; p.IsReloadActive = true; if not CFG.SIMULTANEOUS_PLAY and i > 1 then _Player[1].ReloadTick = current_time; _Player[1].IsReloadActive = true end end
                      end
                  end
                  
                  -- Fire Reload manually (based on Memory Address polling)
                  if cfg.RELOAD and type(cfg.RELOAD) == "number" then
                      local val = Read_Data_Safe(_MemHandles["RELOAD"], cfg.RELOAD, CFG.DATA_WIDTHS.RELOAD)
                      local manual_trigger = false
                      
                      if type(CFG.RELOAD_MEM_ADD_VALUE) == "table" then
                          local found_match = false
                          for _, v in ipairs(CFG.RELOAD_MEM_ADD_VALUE) do
                              if val == v then found_match = true; break end
                          end
                          
                          local last_was_match = false
                          for _, v in ipairs(CFG.RELOAD_MEM_ADD_VALUE) do
                              if p.LastReloadVal == v then last_was_match = true; break end
                          end
                          
                          manual_trigger = (found_match and not last_was_match)
                          
                      elseif type(CFG.RELOAD_MEM_ADD_VALUE) == "number" then
                          manual_trigger = (val == CFG.RELOAD_MEM_ADD_VALUE and p.LastReloadVal ~= CFG.RELOAD_MEM_ADD_VALUE)
                          
                      elseif type(CFG.RELOAD_MEM_MIN_VALUE) == "number" then
                          -- Trigger if value increased AND met the minimum threshold
                          manual_trigger = (val > p.LastReloadVal and val >= CFG.RELOAD_MEM_MIN_VALUE)
                          
                      else
                          manual_trigger = (val > p.LastReloadVal)
                      end
                      
                      if manual_trigger then
                          Set_Output(out, i, "RELOAD", 1)
                          p.ReloadTick = current_time; p.IsReloadActive = true
                          if not CFG.SIMULTANEOUS_PLAY and i > 1 then _Player[1].ReloadTick = current_time; _Player[1].IsReloadActive = true end
                      end
                      p.LastReloadVal = val
                  end
                  
                  -- Fire Recoil manually (based on Memory Address polling)
                  if not auto_recoil_triggered_this_frame then
                      if cfg.RECOIL and type(cfg.RECOIL) == "number" then
                          local val = Read_Data_Safe(_MemHandles["RECOIL"], cfg.RECOIL, CFG.DATA_WIDTHS.RECOIL)
                          if (CFG.RECOIL_PRIORITY ~= "ammo" or curr_ammo == 0) then
                              local manual_trigger = false
                              if type(CFG.RECOIL_MEM_ADD_VALUE) == "number" then
                                  if CFG.RECOIL_METHOD == "hold" then manual_trigger = (val == CFG.RECOIL_MEM_ADD_VALUE) else manual_trigger = (val == CFG.RECOIL_MEM_ADD_VALUE and p.LastRecoilVal ~= CFG.RECOIL_MEM_ADD_VALUE) end
                              else
                                  manual_trigger = (CFG.RECOIL_METHOD == "hold") and (val > 0) or (CFG.RECOIL_METHOD == "change") and (val ~= p.LastRecoilVal and val > 0) or (CFG.RECOIL_METHOD == "latch") and (val > 0 and p.LastRecoilVal == 0) or (val > p.LastRecoilVal)
                              end
                              
                              local active_interval = (CFG.RECOIL_METHOD == "hold") and _RecoilHoldInterval or _MinRecoilInterval
                              if manual_trigger and (current_time - p.RecoilTick > active_interval) then
                                  p.CurrentRecoilDuration = _RecoilDuration; Set_Output(out, i, "RECOIL", 1)
                                  if CFG.DEMULSHOOTER_COMPATIBILITY then Set_Output(out, i, "CtmRecoil", 1) end
                                  
                                  -- Use hardware fallback for primary shots if ammo is unmapped, OR if primary ammo is empty
                                  if CFG.ENABLE_SHOT_COUNT and warmup_ok and (not cfg.AMMO or curr_ammo == 0) then
                                      p.ShotCountPrimary = p.ShotCountPrimary + 1
                                      Set_Output(out, i, "SHOTS_FIRED_PRIMARY", p.ShotCountPrimary)
                                  end
                                  p.RecoilTick = current_time; p.IsRecoilActive = true
                                  if not CFG.SIMULTANEOUS_PLAY and i > 1 then _Player[1].RecoilTick = current_time; _Player[1].IsRecoilActive = true end
                              end
                          end
                          p.LastRecoilVal = val
                      end
                  end
            end

            -- -------------------------------------------------------------------------
            -- PHASE 4: STATISTICAL BROADCASTS & HIT DAMAGE
            -- Pushes live Ammo/Life numbers to external apps.
            -- -------------------------------------------------------------------------
            if is_player_active or just_died then
                if primary_active then
                    if cfg.AMMO then
                        Set_Output(out, i, "AMMO", warmup_ok and curr_ammo or 0)
                        -- Derived: 1 while rounds remain, 0 the instant the clip empties (reload needed).
                        -- Gated on _ClipEnabled so only depleting-clip games ever publish it.
                        if _ClipEnabled then Set_Output(out, i, "CLIP", (warmup_ok and curr_ammo > 0) and 1 or 0) end
                    end
                    if cfg.LIFE then Set_Output(out, i, "LIFE", warmup_ok and curr_life or 0) end
                    
                    if CFG.ENABLE_SHOT_COUNT and cfg.SHOTS_FIRED_PRIMARY and warmup_ok then
                        if type(cfg.SHOTS_FIRED_PRIMARY) == "number" then 
                             local val = Read_Data_Safe(_MemHandles["SHOTS_FIRED_PRIMARY"], cfg.SHOTS_FIRED_PRIMARY, CFG.DATA_WIDTHS.SHOTS_FIRED_PRIMARY)
                             Set_Output(out, i, "SHOTS_FIRED_PRIMARY", val); p.ShotCountPrimary = val
                        elseif cfg.SHOTS_FIRED_PRIMARY == "auto" and cfg.AMMO and p.WasActive then
                            local diff = (CFG.AMMO_DIRECTION == "decrease") and (curr_ammo < p.LastAmmo and p.LastAmmo <= t_ammo and p.LastAmmo - curr_ammo or 0) or ((curr_ammo > p.LastAmmo) and (curr_ammo - p.LastAmmo) or 0)
                            if diff > 0 or (CFG.AMMO_DIRECTION == "change" and curr_ammo ~= p.LastAmmo) then
                                p.ShotCountPrimary = p.ShotCountPrimary + (CFG.SHOTS_FIRED_METHOD == "bullets" and diff or 1)
                                Set_Output(out, i, "SHOTS_FIRED_PRIMARY", p.ShotCountPrimary)
                            end
                        end
                    end
                else
                    if cfg.AMMO then
                        Set_Output(out, i, "AMMO", 0)
                        if _ClipEnabled then Set_Output(out, i, "CLIP", 0) end
                    end
                    if cfg.LIFE then Set_Output(out, i, "LIFE", 0) end
                end

                if alternate_active then
                    if cfg.AMMO_ALT then Set_Output(out, i, "AMMO_ALT", warmup_ok and curr_ammo_alt or 0) end
                    if cfg.LIFE_ALT then Set_Output(out, i, "LIFE_ALT", warmup_ok and curr_life_alt or 0) end
                    
                    if CFG.ENABLE_SHOT_COUNT and cfg.SHOTS_FIRED_ALT and warmup_ok then
                        if type(cfg.SHOTS_FIRED_ALT) == "number" then
                            local val = Read_Data_Safe(_MemHandles["SHOTS_FIRED_ALT"], cfg.SHOTS_FIRED_ALT, CFG.DATA_WIDTHS.SHOTS_FIRED_ALT)
                            Set_Output(out, i, "SHOTS_FIRED_ALT", val); p.ShotCountAlt = val
                        elseif cfg.SHOTS_FIRED_ALT == "auto" and cfg.AMMO_ALT and p.WasActive then
                            local diff = (CFG.AMMO_ALT_DIRECTION == "decrease") and (curr_ammo_alt < p.LastAmmoAlt and p.LastAmmoAlt <= t_alt and p.LastAmmoAlt - curr_ammo_alt or 0) or ((curr_ammo_alt > p.LastAmmoAlt) and (curr_ammo_alt - p.LastAmmoAlt) or 0)
                            if diff > 0 or (CFG.AMMO_ALT_DIRECTION == "change" and curr_ammo_alt ~= p.LastAmmoAlt) then
                                p.ShotCountAlt = p.ShotCountAlt + (CFG.SHOTS_FIRED_ALT_METHOD == "bullets" and diff or 1)
                                Set_Output(out, i, "SHOTS_FIRED_ALT", p.ShotCountAlt)
                            end
                        end
                    end
                    
                    if cfg.AMMO_GRENADE then Set_Output(out, i, "AMMO_GRENADE", warmup_ok and curr_ammo_grenade or 0) end
                    if CFG.ENABLE_SHOT_COUNT and cfg.SHOTS_FIRED_GRENADE and warmup_ok then
                        if type(cfg.SHOTS_FIRED_GRENADE) == "number" then
                            local val = Read_Data_Safe(_MemHandles["SHOTS_FIRED_GRENADE"], cfg.SHOTS_FIRED_GRENADE, CFG.DATA_WIDTHS.SHOTS_FIRED_GRENADE)
                            Set_Output(out, i, "SHOTS_FIRED_GRENADE", val); p.ShotCountGrenade = val
                        elseif cfg.SHOTS_FIRED_GRENADE == "auto" and cfg.AMMO_GRENADE and p.WasActive then
                            local diff = (CFG.AMMO_GRENADE_DIRECTION == "decrease") and (curr_ammo_grenade < p.LastAmmoGrenade and p.LastAmmoGrenade <= t_grenade and p.LastAmmoGrenade - curr_ammo_grenade or 0) or ((curr_ammo_grenade > p.LastAmmoGrenade) and (curr_ammo_grenade - p.LastAmmoGrenade) or 0)
                            if diff > 0 or (CFG.AMMO_GRENADE_DIRECTION == "change" and curr_ammo_grenade ~= p.LastAmmoGrenade) then
                                p.ShotCountGrenade = p.ShotCountGrenade + (CFG.SHOTS_FIRED_GRENADE_METHOD == "bullets" and diff or 1)
                                Set_Output(out, i, "SHOTS_FIRED_GRENADE", p.ShotCountGrenade)
                            end
                        end
                    end
                else
                    if cfg.AMMO_ALT then Set_Output(out, i, "AMMO_ALT", 0) end
                    if cfg.LIFE_ALT then Set_Output(out, i, "LIFE_ALT", 0) end
                    if cfg.AMMO_GRENADE then Set_Output(out, i, "AMMO_GRENADE", 0) end
                end
            else
                if cfg.AMMO then
                    Set_Output(out, i, "AMMO", 0)
                    if _ClipEnabled then Set_Output(out, i, "CLIP", 0) end
                end
                if cfg.LIFE then Set_Output(out, i, "LIFE", 0) end
                if cfg.AMMO_ALT then Set_Output(out, i, "AMMO_ALT", 0) end
                if cfg.LIFE_ALT then Set_Output(out, i, "LIFE_ALT", 0) end
                if cfg.AMMO_GRENADE then Set_Output(out, i, "AMMO_GRENADE", 0) end
            end
            
            if CFG.ENABLE_SHOT_COUNT and warmup_ok then
                local total_shots = p.ShotCountPrimary + p.ShotCountAlt + p.ShotCountGrenade
                Set_Output(out, i, "SHOTS_FIRED", total_shots)
            end

            -- Hit Damage, Environmental Rumble, and Life Lost processing
            if is_player_active or just_died then
                local hit_triggered = false
                
                -- Calculate Damage Taken
                if type(cfg.DAMAGE_TAKEN) == "number" then
                    local val = Read_Data_Safe(_MemHandles["DAMAGE_TAKEN"], cfg.DAMAGE_TAKEN, CFG.DATA_WIDTHS.DAMAGE_TAKEN)
                    if val > p.LastDmgMem and warmup_ok then
                        if CFG.ENABLE_DAMAGE_COUNT then p.DamageCount = p.DamageCount + 1; Set_Output(out, i, "DAMAGE_TAKEN", p.DamageCount) end
                        hit_triggered = true
                    end
                    p.LastDmgMem = val
                elseif cfg.DAMAGE_TAKEN == "auto" and (cfg.LIFE or cfg.LIFE_ALT) and p.WasActive then
                    local hit = (cfg.LIFE and ((CFG.LIFE_DIRECTION == "decrease" and curr_life < p.LastLife) or (CFG.LIFE_DIRECTION == "increase" and curr_life > p.LastLife))) or (cfg.LIFE_ALT and ((CFG.LIFE_ALT_DIRECTION == "decrease" and curr_life_alt < p.LastLifeAlt) or (CFG.LIFE_ALT_DIRECTION == "increase" and curr_life_alt > p.LastLifeAlt)))
                    if hit and warmup_ok then 
                        if CFG.ENABLE_DAMAGE_COUNT then p.DamageCount = p.DamageCount + 1; Set_Output(out, i, "DAMAGE_TAKEN", p.DamageCount) end
                        hit_triggered = true
                    end
                end

                local ffb_now = p.IsFFBAllowed or (just_died and p.WasFFBAllowed)
                
                -- Trigger Damage (Hit) FFB
                if cfg.DAMAGE and ffb_now then
                    if type(cfg.DAMAGE) == "number" then
                        local val = Read_Data_Safe(_MemHandles["DAMAGE"], cfg.DAMAGE, CFG.DATA_WIDTHS.DAMAGE)
                        if val > p.LastDamageVal then
                            Set_Output(out, i, "DAMAGE", 1); if CFG.DEMULSHOOTER_COMPATIBILITY then Set_Output(out, i, "Damaged", 1) end
                            p.DamageTick = current_time; p.IsDamageActive = true
                            if not CFG.SIMULTANEOUS_PLAY and i > 1 then _Player[1].DamageTick = current_time; _Player[1].IsDamageActive = true end
                        end
                        p.LastDamageVal = val
                    elseif cfg.DAMAGE == "auto" and hit_triggered then
                        Set_Output(out, i, "DAMAGE", 1); if CFG.DEMULSHOOTER_COMPATIBILITY then Set_Output(out, i, "Damaged", 1) end
                        p.DamageTick = current_time; p.IsDamageActive = true
                        if not CFG.SIMULTANEOUS_PLAY and i > 1 then _Player[1].DamageTick = current_time; _Player[1].IsDamageActive = true end
                    end
                end
                
                -- Trigger Environmental Rumble FFB
                if cfg.RUMBLE and ffb_now then
                    if type(cfg.RUMBLE) == "number" then
                        local val = Read_Data_Safe(_MemHandles["RUMBLE"], cfg.RUMBLE, CFG.DATA_WIDTHS.RUMBLE)
                        if val > p.LastRumbleEventVal then
                            Set_Output(out, i, "RUMBLE", 1)
                            p.RumbleTick = current_time; p.IsRumbleActive = true
                            if not CFG.SIMULTANEOUS_PLAY and i > 1 then _Player[1].RumbleTick = current_time; _Player[1].IsRumbleActive = true end
                        end
                        p.LastRumbleEventVal = val
                    end
                end
                
                -- Calculate "Lives Lost" (Difference in life bar drops across the whole play session)
                if CFG.ENABLE_LIFE_LOST then
                    if cfg.LIFE_LOST == "auto" and (cfg.LIFE or cfg.LIFE_ALT) and warmup_ok and p.WasActive then
                         local lost = false
                         local diff = 0
                         if cfg.LIFE then
                             if CFG.LIFE_DIRECTION == "decrease" then
                                 if curr_life < p.LastLife then lost = true; diff = p.LastLife - curr_life end
                             else
                                 if curr_life > p.LastLife then lost = true; diff = curr_life - p.LastLife end
                             end
                         end
                         if cfg.LIFE_ALT then
                             if CFG.LIFE_ALT_DIRECTION == "decrease" then
                                 if curr_life_alt < p.LastLifeAlt then lost = true; diff = p.LastLifeAlt - curr_life_alt end
                             else
                                 if curr_life_alt > p.LastLifeAlt then lost = true; diff = curr_life_alt - p.LastLifeAlt end
                             end
                         end
                         if lost then
                             p.LifeLostCount = p.LifeLostCount + diff
                             Set_Output(out, i, "LIFE_LOST", p.LifeLostCount)
                         end
                    elseif type(cfg.LIFE_LOST) == "number" then
                         local val = Read_Data_Safe(_MemHandles["LIFE_LOST"], cfg.LIFE_LOST, CFG.DATA_WIDTHS.LIFE_LOST)
                         Set_Output(out, i, "LIFE_LOST", val)
                    end
                end
            end

            -- Update Frame History Cache (Used for Math on the NEXT frame)
            p.LastAmmo = curr_ammo; p.LastAmmoAlt = curr_ammo_alt; p.LastAmmoGrenade = curr_ammo_grenade
            p.LastLife = curr_life; p.LastLifeAlt = curr_life_alt; p.WasActive = p.IsActive; p.WasFFBAllowed = p.IsFFBAllowed

            -- Cleanup Hardware Timers (Shuts hardware off when time is up)
            if CFG.SIMULTANEOUS_PLAY or i == 1 then
                if p.IsRecoilActive and (current_time - p.RecoilTick > p.CurrentRecoilDuration) then Set_Output(out, i, "RECOIL", 0); if CFG.DEMULSHOOTER_COMPATIBILITY then Set_Output(out, i, "CtmRecoil", 0) end; p.IsRecoilActive = false end
                if p.IsReloadActive and (current_time - p.ReloadTick > _ReloadDuration) then Set_Output(out, i, "RELOAD", 0); p.IsReloadActive = false end
                if p.IsDamageActive and (current_time - p.DamageTick > _DamageDuration) then Set_Output(out, i, "DAMAGE", 0); if CFG.DEMULSHOOTER_COMPATIBILITY then Set_Output(out, i, "Damaged", 0) end; p.IsDamageActive = false end
                if p.IsRumbleActive and (current_time - p.RumbleTick > _RumbleDuration) then Set_Output(out, i, "RUMBLE", 0); p.IsRumbleActive = false end
            end
        end
        
        -- Override Global Credits if individual credits are actively mapped
        if using_individual_credits then
            Set_Global_Output(out, "GLOBAL_CREDITS", warmup_ok and aggregated_credits or 0)
            if warmup_ok then
                if aggregated_credits > _LastGlobalCredits then
                    _GlobalCreditsInserted = _GlobalCreditsInserted + (aggregated_credits - _LastGlobalCredits)
                    if CFG.ENABLE_CREDIT_COUNT then Set_Global_Output(out, "GLOBAL_CREDITS_INSERTED", _GlobalCreditsInserted) end
                elseif aggregated_credits < _LastGlobalCredits then
                    _PendingGlobalCreditDrops = _PendingGlobalCreditDrops + (_LastGlobalCredits - aggregated_credits)
                end
                _LastGlobalCredits = aggregated_credits
            end
            if aggregated_credits > 0 and warmup_ok then _HasCoinedUp = true end
        end
        
        local final_game_active = ((global_exists and is_game_active) or (not global_exists and any_player_active))
        Set_Global_Output(out, "GLOBAL_GAME_STATUS", warmup_ok and final_game_active and 1 or 0)

        -- DERIVED ATTRACT MODE:
        -- When no address exists, infer it: warmed up, no game running,
        -- no player session active. This is an OUTPUT-ONLY signal -
        -- unlike the address-backed attract detection in Phase 1, it must
        -- never veto memory reads or clear pending credit accounting,
        -- otherwise a derived-attract game could never observe its own game start.
        if not (CFG.ATTRACT_STATUS and type(CFG.ATTRACT_STATUS) == "number") then
            Set_Global_Output(out, "GLOBAL_ATTRACT_STATUS", (warmup_ok and not final_game_active and not any_player_active) and 1 or 0)
        end
        
        -- Walk-away protection: Clear session stats if inactive for a long time
        if not final_game_active then
            if _GameInactiveTick == _ZeroTime then 
                _GameInactiveTick = current_time 
            elseif _CreditsClearTimeout and (current_time - _GameInactiveTick > _CreditsClearTimeout) then
                _PendingGlobalCreditDrops = 0
                for i = 1, CFG.MAX_PLAYERS do 
                    _Player[i].PendingCreditDrops = 0 
                    _Player[i].SpawnsAwaitingCredit = 0
                end
            end
        else
            _GameInactiveTick = _ZeroTime
        end

        -- -------------------------------------------------------------------------
        -- PHASE 5: MEMORY PATCHING
        -- Actively overwrites MAME memory to disable blinding flashes.
        -- -------------------------------------------------------------------------
        if warmup_ok and CFG.SCREEN_FLASH then
            -- 1. Process Global Patch (If configured)
            if CFG.SCREEN_FLASH_MEMORY_ADDRESS and CFG.SCREEN_FLASH_DISABLE_VALUE then
                Write_Data_Safe(_MemHandles["SCREEN_FLASH"], CFG.SCREEN_FLASH_MEMORY_ADDRESS, CFG.DATA_WIDTHS.SCREEN_FLASH or 8, CFG.SCREEN_FLASH_DISABLE_VALUE)
            end
            
            -- 2. Process Per-Player Patches
            for i = 1, CFG.MAX_PLAYERS do
                local p_cfg = _PlayerCFG[i]
                if p_cfg.SCREEN_FLASH_MEMORY_ADDRESS and p_cfg.SCREEN_FLASH_DISABLE_VALUE then
                    Write_Data_Safe(_MemHandles["SCREEN_FLASH"], p_cfg.SCREEN_FLASH_MEMORY_ADDRESS, CFG.DATA_WIDTHS.SCREEN_FLASH or 8, p_cfg.SCREEN_FLASH_DISABLE_VALUE)
                end
            end
        end
    end

    -- -------------------------------------------------------------------------
    -- Driver_Source_Key()
    -- The running machine's DRIVER basename, lowercased, no directories, no
    -- extension: "…/src/mame/namco/namcos12.cpp" -> "namcos12". That is how
    -- native_outputs_by_driver.lua is keyed, and the same key MAME itself uses
    -- for its source/<name>.ini. game_driver.source_file is a compile-time
    -- __FILE__, so the separator can be either slash depending on the build
    -- host - both are handled. Returns nil if the field is unavailable.
    -- -------------------------------------------------------------------------
    local function Driver_Source_Key()
        local ok, src = pcall(function() return manager.machine.system.source_file end)
        if not ok or type(src) ~= "string" or src == "" then return nil end
        local base = src:match("([^/\\]+)$") or src
        base = base:gsub("%.[Cc][Pp][Pp]$", "")
        return base ~= "" and base:lower() or nil
    end

    -- -------------------------------------------------------------------------
    -- Probe_Enumerate_Outputs() / Enumerate_Native_Outputs()   [v9.1.0]
    -- Asks the running machine which outputs it has actually created, instead of
    -- trusting a list scraped from MAME's source months earlier.
    --
    -- This needs MAME's read-only device.outputs property. Unlike PR 15639's
    -- register_output (rejected - see the architecture notes at the top of this
    -- file), that property CREATES NOTHING: it lists what a device already made,
    -- which is information MAME already publishes to any external process through
    -- -output console and -output network. Where it is missing, every caller falls
    -- back to the scraped databases and behaviour is exactly v9.0.4's.
    --
    -- Why this matters beyond tidiness: the scraped data is keyed by driver SOURCE
    -- FILE, so a game inherits the union of every output declared by every sibling
    -- in the same .cpp - names its own machine never creates - while a game whose
    -- driver was never scraped gets nothing at all. Enumeration is exact for both.
    --
    -- Returns nil when this build cannot enumerate (the caller then falls back).
    -- An empty table is a real answer: this machine created no outputs.
    -- -------------------------------------------------------------------------
    -- Recognises MSOP's OWN synthetic output names, so enumeration can never mistake
    -- one for a driver's native output. This matters on any build where MSOP can still
    -- create outputs (MAME 0.288 and earlier, through the deprecated set_value): there
    -- its names really do exist in the machine's output table, and Set_Output_Safe
    -- already puts every one of them on the relay as it changes. Forwarding them again
    -- from Forward_Native_Outputs would double up that stream and blur the line its
    -- contract draws - a "native" output is the DRIVER's, never MSOP's. Matches the
    -- vocabulary MSOP writes: MSOP_* globals and per-player names, plus the three
    -- unprefixed per-player customs (P<n>_CtmRecoil, P<n>_CtmLmpStart, P<n>_Damaged).
    local function Is_MSOP_Output_Name(name)
        return (name:match("^MSOP_") or name:match("^P%d+_Ctm") or name:match("^P%d+_Damaged$")) ~= nil
    end

    local function Probe_Enumerate_Outputs()
        if _EnumerateOutputsSupported ~= nil then return _EnumerateOutputsSupported end

        local ok, val = pcall(function()
            local root = manager.machine.devices[":"]
            return root and root.outputs or nil
        end)
        _EnumerateOutputsSupported = (ok and type(val) == "table") and true or false

        if _EnumerateOutputsSupported then
            dbg_print("Native output discovery: ENUMERATED from the running machine "
                      .. "(device.outputs) - scraped databases not consulted")
        else
            dbg_print("Native output discovery: device.outputs unavailable on this build - "
                      .. "falling back to the scraped databases")
        end
        return _EnumerateOutputsSupported
    end

    local function Enumerate_Native_Outputs()
        if not Probe_Enumerate_Outputs() then return nil end

        local records = {}
        local ok = pcall(function()
            for _, dev in pairs(manager.machine.devices) do
                local list = dev.outputs
                if type(list) == "table" then
                    for _, item in ipairs(list) do
                        local rel = item.name
                        if type(rel) == "string" and not Is_MSOP_Output_Name(rel) then
                            local qualified = item.qualified_name
                            records[#records + 1] = {
                                dev  = dev,
                                name = rel,
                                wire = (type(qualified) == "string") and qualified or rel,
                            }
                        end
                    end
                end
            end
        end)
        if not ok then
            -- Something in the walk threw. Treat as unsupported for the rest of the
            -- session rather than retrying a broken path every ROM load.
            _EnumerateOutputsSupported = false
            dbg_print("Native output enumeration failed mid-walk - reverting to scraped databases")
            return nil
        end
        return records
    end

    -- -------------------------------------------------------------------------
    -- Forward_Native_Outputs()
    -- Mirrors curated NATIVE outputs (the ROM driver's own outputs, e.g.
    -- "lamp0" - NOT anything MSOP creates) over the relay so hookers still
    -- see them even though MAME runs with -output none under the relay and
    -- its own native output modules never get a chance to broadcast them.
    -- Deliberately one-directional (read via the existing proxy cache,
    -- forward via msop_out) - never written back through Set_Output_Safe,
    -- since the driver already holds the authoritative value; re-writing it
    -- would be redundant at best and fight the driver's own state at worst.
    -- Populate CFG.ADDITIONAL_OUTPUT_FORWARDS (a plain array of output
    -- names) per game for anything discovery can't see (e.g. a third-party
    -- script's own output). That list is always honoured, whichever discovery
    -- route below supplied the rest.
    --
    -- v9.1.0: _NativeForwards is an array of RECORDS, not bare names:
    --     { dev = <device or nil>, name = "lamp0", wire = "lamp0", proxy = ... }
    --   * dev   - the device that owns the output, when it was discovered by
    --             enumeration. nil for a name that came from a database or from
    --             ADDITIONAL_OUTPUT_FORWARDS, which resolves against the root
    --             device exactly as every earlier version did.
    --   * wire  - the name put on the relay. This is MAME's own qualified name,
    --             so an output owned by a subdevice goes out as "sub:lamp0",
    --             matching what MAME's -output network module would broadcast.
    --             For a root-device output (every arcade driver in practice)
    --             the qualified name IS the relative name, so payloads are
    --             byte-identical to v9.0.4's.
    --   * proxy - resolved lazily on first use and cached in the record; false
    --             once a miss is known to be permanent. See _RetryMissingProxies.
    -- -------------------------------------------------------------------------
    local function Forward_Native_Outputs()
        for _, fwd in ipairs(_NativeForwards) do
            local proxy = fwd.proxy
            if proxy == nil then
                if fwd.dev then
                    -- Enumerated: resolve against the device that actually owns the
                    -- output. Get_Output_Proxy only ever looks at the root device, so
                    -- this is the only path that can reach a subdevice's outputs.
                    local ok, p = pcall(function() return fwd.dev:output(fwd.name) end)
                    proxy = (ok and p and p:exists()) and p or false
                else
                    proxy = Get_Output_Proxy(fwd.name, nil) or false
                end
                -- Don't cache a miss while misses are still worth retrying (an output
                -- whose device started late may only appear a few frames in).
                if proxy or not _RetryMissingProxies then fwd.proxy = proxy end
            end
            if proxy then
                msop_out(fwd.wire, proxy:get())
            end
        end
    end

    -- -------------------------------------------------------------------------
    -- Compute_Outputs()
    -- Safe execution wrapper for the Frame_Logic engine.
    -- -------------------------------------------------------------------------
    local function Compute_Outputs()
        -- Ensure the ROM is valid and memory spaces are bound, and bail out
        -- immediately once shutdown has started (Frame_Logic sets
        -- _IsShuttingDown itself if manager.machine goes away mid-frame,
        -- but Unhook_Frame isn't guaranteed to have detached this notifier
        -- by the very next frame - this stops any further pcall(Frame_Logic)
        -- attempts as soon as that flag flips, rather than relying solely
        -- on Frame_Logic's own internal guard to catch it every time).
        if _IsShuttingDown then return end

        -- Frame_Logic is the MSOP profile engine and REQUIRES CFG. An unsupported ROM has CFG == nil
        -- but may still be running in pass-through mode (v9.0.2) - where the only job is mirroring
        -- MAME's own native outputs over the relay - so skip the engine and fall through to the
        -- forward + flush below. (Previously this returned early on `not CFG`, which meant an
        -- unsupported ROM forwarded nothing AND never flushed the relay at all.)
        if CFG then
            -- Execute the massive Frame_Logic engine safely
            -- pcall prevents garbage collection spikes and handles errors gracefully
            local ok, err = pcall(Frame_Logic)
            if not ok then dbg_print("FRAME ERROR: " .. tostring(err)) end
        end

        -- Mirror any curated native driver outputs for this ROM (no-op if
        -- none are configured)
        local ok2, err2 = pcall(Forward_Native_Outputs)
        if not ok2 then dbg_print("NATIVE FORWARD ERROR: " .. tostring(err2)) end

        -- FLUSH CHANGES OVER THE NETWORK
        -- This blasts everything Frame_Logic generated this frame over TCP
        flush_payload_to_relay()
    end

    -- -------------------------------------------------------------------------
    -- Unhook_Frame()
    -- Deterministically detaches the frame notifier. on_start() re-fires on
    -- every reset (soft resets included) and previously just overwrote the
    -- old subscription, leaving the abandoned one firing until garbage
    -- collection got around to it - stacking two engine passes per frame in
    -- the meantime.
    -- -------------------------------------------------------------------------
    local function Unhook_Frame()
        local sub = exports.subscriptions.frame
        if sub then
            if type(sub) == "userdata" and sub.unsubscribe then
                pcall(function() sub:unsubscribe() end)
            end
            exports.subscriptions.frame = nil
        elseif emu.register_frame_done then
            emu.register_frame_done(nil, "frame")
        end
    end

    -- -------------------------------------------------------------------------
    -- on_post_load()
    -- SAVE-STATE ALIGNMENT: any output that is genuinely part of the machine
    -- snaps to its saved value on load - but this engine's Lua-side mirrors,
    -- counters, and attotime anchors are NOT saved. (v9.1.0: MSOP's own outputs
    -- are no longer among them on any stock build, since nothing outside the
    -- driver can add to the output table - see the REMOVED IN v9.1.0 note. The
    -- adopt() calls below therefore fall back to the session value for MSOP
    -- names and only find real data where an output actually exists, which is
    -- exactly what they were written to handle.)
    -- Left alone, the first frames after a load fire phantom deltas
    -- (ammo jump -> recoil/reload, credit jump -> "inserted") and the stale
    -- session counters immediately overwrite the freshly restored counter outputs.
    -- Strategy:
    --   1. re-seed memory delta baselines from restored RAM
    --   2. ADOPT restored counter outputs as the session counters (the
    --      outputs are the saved truth; proxy:get() returns it)
    --   3. kill in-flight FFB pulses - their attotime anchors belong to the
    --      pre-load timeline and can wedge comparisons for minutes
    --   4. wipe change-detection mirrors so every next write re-broadcasts;
    --      the core de-duplicates identical values, so clients only ever see
    --      the values that genuinely differ
    -- -------------------------------------------------------------------------
    local function on_post_load()
        if _IsShuttingDown or not CFG or not _WarmupFlushed then
            -- a state loaded before warmup ever completed this session isn't
            -- being tracked yet; the normal warmup flush will handle it
            return
        end
        local ok, err = pcall(function()
            Seed_Frame_Baselines()

            local function adopt(name, fallback)
                if not name then return fallback end
                local proxy = Get_Output_Proxy(name, nil)
                if proxy then
                    local got = proxy:get()
                    if type(got) == "number" then return got end
                end
                return fallback
            end

            _GlobalCreditsInserted = adopt(_GlobalOutputs["GLOBAL_CREDITS_INSERTED"], _GlobalCreditsInserted)
            _PendingGlobalCreditDrops = 0

            local now = manager.machine.time
            local debounce_age = emu.attotime.from_msec((CFG.STATUS_DEBOUNCE_MS or 0) + 20)
            local game_restored = adopt(_GlobalOutputs["GLOBAL_GAME_STATUS"], 0) == 1
            _GameActiveTick = game_restored and (now - debounce_age) or _ZeroTime
            _GameInactiveTick = _ZeroTime
            _GlobalLastOutputs = {}

            for i = 1, CFG.MAX_PLAYERS do
                local p = _Player[i]
                local names = _OutputNames[i] or {}

                p.ShotCountPrimary = adopt(names["SHOTS_FIRED_PRIMARY"], p.ShotCountPrimary)
                p.ShotCountAlt     = adopt(names["SHOTS_FIRED_ALT"], p.ShotCountAlt)
                p.ShotCountGrenade = adopt(names["SHOTS_FIRED_GRENADE"], p.ShotCountGrenade)
                p.DamageCount      = adopt(names["DAMAGE_TAKEN"], p.DamageCount)
                p.LifeLostCount    = adopt(names["LIFE_LOST"], p.LifeLostCount)
                p.CreditsInserted  = adopt(names["CREDITS_INSERTED"], p.CreditsInserted)
                p.CreditsConsumed  = adopt(names["CREDITS_CONSUMED"], p.CreditsConsumed)

                -- adopt restored activity so Check 1 doesn't phantom-spawn a
                -- credit claim for a player who was already mid-session; the
                -- pre-aged ActiveTick keeps an active player's Status output
                -- seamless through the debounce window instead of blipping 0
                local was_active = adopt(names["STATUS"], 0) == 1
                p.IsActive, p.WasActive = was_active, was_active
                p.ActiveTick = was_active and (now - debounce_age) or _ZeroTime
                p.IsFFBAllowed, p.WasFFBAllowed = was_active, was_active

                p.RecoilTick, p.ReloadTick, p.DamageTick, p.RumbleTick = _ZeroTime, _ZeroTime, _ZeroTime, _ZeroTime
                p.IsRecoilActive, p.IsReloadActive, p.IsDamageActive, p.IsRumbleActive = false, false, false, false
                p.PendingCreditDrops, p.SpawnsAwaitingCredit = 0, 0
                p.LastOutputs = {}
            end

            -- a state saved mid-pulse restores RECOIL/RELOAD/etc as 1 with no
            -- timer left running to turn them off - force every pulse low
            if manager.machine and manager.machine.output then
                local out = manager.machine.output
                for i = 1, CFG.MAX_PLAYERS do
                    Set_Output(out, i, "RECOIL", 0)
                    Set_Output(out, i, "RELOAD", 0)
                    Set_Output(out, i, "DAMAGE", 0)
                    Set_Output(out, i, "RUMBLE", 0)
                    if CFG.DEMULSHOOTER_COMPATIBILITY then
                        Set_Output(out, i, "CtmRecoil", 0)
                        Set_Output(out, i, "Damaged", 0)
                    end
                end
            end
            dbg_print("Save state loaded - baselines re-seeded, counters adopted from restored outputs")
        end)
        if not ok then dbg_print("POST-LOAD RESYNC ERROR: " .. tostring(err)) end
    end

    -- -------------------------------------------------------------------------
    -- on_machine_stop()
    -- Cleanup hook. Halts processing and destroys subscriptions.
    -- -------------------------------------------------------------------------
    local function on_machine_stop()
        _IsShuttingDown = true

        -- v9.1.0: drop the native-forward records. Each one can hold a device handle
        -- and a resolved output proxy belonging to the machine now being torn down
        -- (v9.0.4 held only names, which were harmless to keep). on_start rebuilds
        -- this list wholesale for every ROM, so nothing is lost by clearing it here -
        -- it only guarantees no stale machine reference can outlive its machine. Same
        -- reasoning as the _ProxyCache reset in on_start.
        _NativeForwards = {}

        -- ALWAYS broadcast mame_stop so hookers know to sleep
        broadcast_native_event("mame_stop = 1\r\n")
        
        -- Safely restore modified memory values before shutting down
        if CFG and CFG.SCREEN_FLASH then
            local conf = _MemConfig["SCREEN_FLASH"]
            if conf and manager and manager.machine then
                
                -- Determine the exact memory space hook
                local mem_handle = nil
                if string.lower(conf.space) == "region" then
                    mem_handle = manager.machine.memory.regions[conf.tag]
                elseif manager.machine.devices[conf.tag] then
                    local dev = manager.machine.devices[conf.tag]
                    if dev.spaces[conf.space] then
                        mem_handle = dev.spaces[conf.space]
                    end
                end
                
                if mem_handle then
                    -- 1. Restore Global Patch
                    if CFG.SCREEN_FLASH_MEMORY_ADDRESS and CFG.SCREEN_FLASH_RESTORE_VALUE then
                        Write_Data_Safe(mem_handle, CFG.SCREEN_FLASH_MEMORY_ADDRESS, CFG.DATA_WIDTHS.SCREEN_FLASH or 8, CFG.SCREEN_FLASH_RESTORE_VALUE)
                    end
                    
                    -- 2. Restore Per-Player Patches
                    for i = 1, CFG.MAX_PLAYERS do
                        local p_cfg = _PlayerCFG[i]
                        if p_cfg and p_cfg.SCREEN_FLASH_MEMORY_ADDRESS and p_cfg.SCREEN_FLASH_RESTORE_VALUE then
                            Write_Data_Safe(mem_handle, p_cfg.SCREEN_FLASH_MEMORY_ADDRESS, CFG.DATA_WIDTHS.SCREEN_FLASH or 8, p_cfg.SCREEN_FLASH_RESTORE_VALUE)
                        end
                    end
                end
            end
        end

        Unhook_Frame()
    end

    -- -------------------------------------------------------------------------
    -- REMOVED IN v9.1.0 - Register_Master_List() and the devices-started hook
    -- -------------------------------------------------------------------------
    -- What used to live here registered MSOP's own synthetic output names
    -- (MSOP_P1_Ammo and the rest) against the root device by calling
    -- root:register_output(), early enough that MAME had not yet locked its output
    -- table for save states. It required a patched MAME core to exist at all.
    --
    -- That core change was submitted upstream as mamedev/mame PR #15639 and was
    -- REJECTED - on principle, not for anything fixable in the code. MAME's
    -- maintainers hold that a machine's outputs are a STATIC part of its
    -- configuration, in the same way as its I/O ports and devices: fixed for a
    -- given system configuration, and therefore not something a script may add to.
    -- Allowing it would also make save states depend on which scripts happened to
    -- be loaded. The attempt before it, PR #15618, was closed for the same
    -- underlying reason.
    --
    --   https://github.com/mamedev/mame/pull/15639   (create outputs - rejected)
    --   https://github.com/mamedev/mame/pull/15618   (the earlier attempt)
    --
    -- Do not reintroduce this. MSOP does not need it: its own outputs travel over
    -- the relay (see the MSOP RELAY TRANSPORT LAYER section), which never depended
    -- on MAME holding them, and which is the only delivery path that works on stock
    -- 0.289+ in any case.
    --
    -- What MSOP does still want from MAME is the opposite direction - being able to
    -- READ which outputs a machine has created. That is introspection rather than
    -- creation, adds nothing to the output table, and is what
    -- Enumerate_Native_Outputs uses where the build supports it.
    -- -------------------------------------------------------------------------

    -- =========================================================================
    -- THE BOOT HOOK (on_start)
    -- This fires exactly once when a specific ROM finishes launching.
    -- Initializes arrays, validates DB config, and sets up timers.
    -- =========================================================================
    local function on_start()
        dbg_print("on_start triggered. Current MAME Phase: " .. tostring(manager.machine.phase))
        if not manager or not manager.machine then return end

        -- Pass 38: settle the relay decision from MAME's live version + -output mode
        -- BEFORE the first relay use below (one-shot; no-ops on subsequent resets).
        -- Settle the create-capability question BEFORE the relay decision: resolve_relay_mode's
        -- capability gate needs the answer, and left to the first real write it would arrive too
        -- late (which is exactly how -output windows went dark on a version-misreporting build).
        pcall(function() Probe_Legacy_Set_Value(manager.machine.output) end)
        resolve_relay_mode()

        local rom_name = manager.machine.system.name

        -- Clear the back-off so every ROM start gets one free dial regardless of how the
        -- last one went. A ROM boundary is the cheapest possible place to spend a failed
        -- connect - MAME is already loading, so the stall hides in work the player is
        -- waiting on anyway - and it is exactly when a relay is most likely to have
        -- appeared (MESH launched between games, or launching the game itself).
        next_retry_at = 0
        retry_backoff = 0

        -- ALWAYS broadcast mame_start with the actual ROM name so hookers load the right profile
        broadcast_native_event("mame_start = " .. rom_name .. "\r\n")
        
        dbg_print("Checking ROM [" .. rom_name .. "] against database")
		dbg_osd("Checking ROM [" .. rom_name .. "] against database")
        
        if db and type(db) == "table" and db[rom_name] then
            
            -- Merge game data with default template to ensure stability
            local merged = deep_merge(db["_default"], db[rom_name])
            
            -- Check if the user has explicitly disabled this ROM
            if merged.ENABLE_ROM == false then
                dbg_print("DISABLED - ROM [" .. rom_name .. "] disabled via ENABLE_ROM flag")
                dbg_osd("DISABLED - ROM " .. rom_name .. " disabled by user")
                CFG = nil
                
                Unhook_Frame()
                return
            end
            
            dbg_print("ENABLED - ROM [" .. rom_name .. "] found in database")
            dbg_osd("ENABLED - ROM [" .. rom_name .. "]")
            
            CFG = normalize_variables(merged)
            
            -- Fix JSON limitations for hex strings
            convert_hex_strings_to_numbers(CFG) 
            
            -- Stable numeric identity for the MSOP_LuaROMid output: a
            -- database-supplied LUA_ROM_ID always wins; otherwise derive a
            -- deterministic 31-bit FNV-1a hash of the ROM short name, so the
            -- id never changes across plugin or database updates.
            _RomIdNum = tonumber(CFG.LUA_ROM_ID) or fnv1a_31(rom_name)

            -- Reset Engine Tracking
            _IsShuttingDown = false
            _HasCoinedUp = not CFG.CREDITS
            
            _LastGlobalCredits = 0
            _GlobalCreditsInserted = 0
            _PendingGlobalCreditDrops = 0
            
            -- Reset Memory Hardware Cache
            _MemConfig = {}
            _MemHandles = {}
            _HardwareBound = false
            _OutputNames = {}
            _GlobalOutputs = {}

            -- Reset Output Proxy Cache
            -- CRITICAL: each cached proxy is bound to the root device_t of the
            -- machine that was running when it was created. Switching to a new
            -- ROM (e.g. via a frontend, or MAME's own game-select menu) destroys
            -- that machine and constructs a fresh one - any proxy left in this
            -- cache would be pointing at a device/output table that no longer
            -- exists. Since output names (e.g. "MSOP_P1_Ammo") are templated
            -- and reused across every supported game, a stale entry here WILL
            -- get hit again on the next ROM. Must be cleared every on_start.
            _ProxyCache = {}

            -- v9.1.0: pass-through sets this true and nothing used to clear it, so a
            -- single unsupported ROM left it set for the rest of the session. That
            -- kept Forward_Native_Outputs re-resolving a permanently absent name on
            -- every frame instead of caching the miss once. Supported ROMs resolve
            -- their outputs at start, so reset it here.
            _RetryMissingProxies = false

            -- Resolve this ROM's native-output forward list once per load.
            --
            -- v9.1.0: when this build can enumerate (device.outputs), the running
            -- machine IS the list, and the scraped databases are not consulted at
            -- all. They are keyed by driver source file, so they both name outputs a
            -- given machine never creates and miss machines nobody scraped; asking
            -- the machine is exact in both directions. Without enumeration this falls
            -- back to native_outputs_by_rom.lua's auto-scraped entry for this ROM exactly as
            -- v9.0.4 did (regenerated wholesale by msop_native_outputs_compiler.py -
            -- never hand-edit it).
            --
            -- database.lua's hand-curated ADDITIONAL_OUTPUT_FORWARDS is applied on top
            -- either way: it exists for names no discovery route can see, e.g. another
            -- script's own output. Deduped by wire name; every part may be absent with
            -- no error. See Forward_Native_Outputs for the record shape.
            _NativeForwards = {}
            do
                local seen = {}
                local function add_name(name)
                    if type(name) == "string" and not seen[name] then
                        seen[name] = true
                        _NativeForwards[#_NativeForwards + 1] = { name = name, wire = name }
                    end
                end

                local enumerated = Enumerate_Native_Outputs()
                if enumerated then
                    for _, rec in ipairs(enumerated) do
                        if not seen[rec.wire] then
                            seen[rec.wire] = true
                            _NativeForwards[#_NativeForwards + 1] = rec
                        end
                    end
                else
                    for _, name in ipairs(driver_db[rom_name] or {}) do add_name(name) end
                end

                for _, name in ipairs(CFG.ADDITIONAL_OUTPUT_FORWARDS or {}) do add_name(name) end
            end

            -- Establish exact attotime durations for the specific machine
            _RecoilDuration = emu.attotime.from_msec(CFG.RECOIL_DURATION_MS or 40)
            _RecoilAltDuration = emu.attotime.from_msec(CFG.RECOIL_ALT_DURATION_MS or 80)
            _RecoilGrenadeDuration = emu.attotime.from_msec(CFG.RECOIL_GRENADE_DURATION_MS or 150)
            _MinRecoilInterval = emu.attotime.from_msec(CFG.MIN_RECOIL_INTERVAL_MS or 0)
            _RecoilHoldInterval = CFG.RECOIL_HOLD_MS and emu.attotime.from_msec(CFG.RECOIL_HOLD_MS) or _MinRecoilInterval
			-- SAFETY CLAMP: Prevent machine-gun freeze by forcing interval > duration
			if _MinRecoilInterval <= _RecoilDuration then _MinRecoilInterval = emu.attotime.from_msec((CFG.RECOIL_DURATION_MS or 40) + 20) end
			if _RecoilHoldInterval <= _RecoilDuration then _RecoilHoldInterval = emu.attotime.from_msec((CFG.RECOIL_DURATION_MS or 40) + 20) end
            _ReloadDuration = emu.attotime.from_msec(CFG.RELOAD_DURATION_MS or 40)
            _DamageDuration = emu.attotime.from_msec(CFG.DAMAGE_DURATION_MS or 250)
            _RumbleDuration = emu.attotime.from_msec(CFG.RUMBLE_DURATION_MS or CFG.DAMAGE_DURATION_MS or 250)
            _StartupTime = emu.attotime.from_msec(CFG.STARTUP_DELAY_MS or 0)
            _ZeroTime = emu.attotime.from_seconds(0)
            -- Hoisted out of the frame loop (see the declaration comment above). Identical
            -- values to what Frame_Logic used to compute inline; CREDITS_CLEAR_TIMEOUT_SEC is
            -- optional, so its constant stays nil when unset and the frame guard still short-
            -- circuits exactly as before.
            _StatusDebounce = emu.attotime.from_msec(CFG.STATUS_DEBOUNCE_MS or 0)
            _CreditsClearTimeout = CFG.CREDITS_CLEAR_TIMEOUT_SEC and emu.attotime.from_seconds(CFG.CREDITS_CLEAR_TIMEOUT_SEC) or nil

            _GameActiveTick = _ZeroTime
            _GameInactiveTick = _ZeroTime
            _WarmupFlushed = false -- Resets the warmup state for consecutive ROM loads
            
            -- Reset all multi-player arrays (prevents "dirty RAM" carrying over from past games)
            for i = 1, 4 do
                _Player[i] = { 
                    LastOutputs={}, LastAmmo=0, LastAmmoAlt=0, LastAmmoGrenade=0, LastLife=0, LastLifeAlt=0, LastDmgMem=0, LastCredits=0, LastReloadVal=0,
                    RecoilTick=_ZeroTime, ReloadTick=_ZeroTime, DamageTick=_ZeroTime, RumbleTick=_ZeroTime,
                    CurrentRecoilDuration=_RecoilDuration, LastRecoilVal=0, LastDamageVal=0, LastRumbleEventVal=0,
                    ShotCountPrimary=0, ShotCountAlt=0, ShotCountGrenade=0, DamageCount=0, LifeLostCount=0, CreditsInserted=0, CreditsConsumed=0, PendingCreditDrops=0, SpawnsAwaitingCredit=0,
                    IsActive=false, WasActive=false, ActiveTick=_ZeroTime,
                    IsRecoilActive=false, IsReloadActive=false, IsDamageActive=false, IsRumbleActive=false,
                    IsFFBAllowed=false, WasFFBAllowed=false
                }
            end
            
            -- Generate strings and math offsets
            Resolve_Addresses_And_Strings()
            
            -- Engage the frame loop, dropping any prior session/soft-reset
            -- subscription deterministically first (on_start re-fires on
            -- every reset; stacking notifiers double-runs the engine)
            Unhook_Frame()
            if emu.add_machine_frame_notifier then
                exports.subscriptions.frame = emu.add_machine_frame_notifier(Compute_Outputs)
            else
                emu.register_frame_done(Compute_Outputs, "frame")
            end
        else
            CFG = nil

            -- PASS-THROUGH MODE (v9.0.2)
            -- The ROM has no MSOP profile, but MAME's own NATIVE outputs still exist. Under the relay
            -- the instance runs with -output none/console, so MAME's own network module never gets to
            -- broadcast them and the hookers see NOTHING at all. Mirror whatever native names we know
            -- for this ROM so unsupported games still deliver their lamps/LEDs/etc.
            --
            -- v9.1.0: this is where enumeration pays off most. The limitation that used to be
            -- recorded here - "Lua cannot ENUMERATE MAME's output table; output_manager's Lua
            -- usertype exposes only get/set_value(+indexed), and neither add_global_notifier nor
            -- notify_all is bound" - is precisely what the read-only device.outputs property
            -- lifts. With it, an unsupported game forwards its REAL outputs whether or not anyone
            -- ever scraped its driver. Without it, the scraped-database path below still applies
            -- unchanged, and a ROM with no entry forwards nothing here and should simply run with
            -- -output network instead, letting MAME broadcast its own natives directly.
            _ProxyCache = {}
            _RetryMissingProxies = true
            _NativeForwards = {}
            do
                local seen = {}
                local via

                local enumerated = Enumerate_Native_Outputs()
                if enumerated then
                    for _, rec in ipairs(enumerated) do
                        if not seen[rec.wire] then
                            seen[rec.wire] = true
                            _NativeForwards[#_NativeForwards + 1] = rec
                        end
                    end
                    via = "enumerated from the running machine"
                else
                    -- The ROM's own scraped entry wins (it is the more specific of the two, and can
                    -- carry layout-derived names the driver source never declares). Only when the ROM
                    -- has no entry at all - the normal case for a game MSOP does not support - fall
                    -- back to whatever its DRIVER declares, keyed by source file basename.
                    local list = driver_db[rom_name]
                    via = "rom"
                    if not list or #list == 0 then
                        local src = Driver_Source_Key()
                        if src then
                            list = mame_driver_db[src]
                            via = "driver:" .. src
                        end
                    end
                    for _, name in ipairs(list or {}) do
                        if type(name) == "string" and not seen[name] then
                            seen[name] = true
                            _NativeForwards[#_NativeForwards + 1] = { name = name, wire = name }
                        end
                    end
                end

                if #_NativeForwards > 0 then
                    dbg_print("Pass-through source: " .. via)
                end
            end

            -- SPLIT-PORT (v9.0.4): when the relay has been moved off 8000, MAME's OWN output
            -- server is running there and already broadcasting every native output of every
            -- game - including these. Forwarding them again over the relay would deliver each
            -- one twice to anything reading both sockets, so pass-through stands down and lets
            -- MAME do the job it is doing better (no scraped list, no missing names).
            if _RelayPort ~= 8000 then
                _NativeForwards = {}
                dbg_print("PASS-THROUGH skipped - split-port: MAME's own server on 8000 is "
                          .. "already broadcasting this ROM's native outputs")
            end

            Unhook_Frame()
            if _UseRelay and #_NativeForwards > 0 then
                dbg_print("PASS-THROUGH - ROM [" .. rom_name .. "] not in database; forwarding "
                          .. #_NativeForwards .. " native output(s) over the relay")
                dbg_osd("MSOP pass-through: " .. #_NativeForwards .. " native outputs")
                if emu.add_machine_frame_notifier then
                    exports.subscriptions.frame = emu.add_machine_frame_notifier(Compute_Outputs)
                else
                    emu.register_frame_done(Compute_Outputs, "frame")
                end
            else
                dbg_print("DISABLED - ROM [" .. rom_name .. "] not supported in database"
                          .. (_UseRelay and " (no scraped native outputs to forward)" or ""))
                dbg_osd("DISABLED - ROM " .. rom_name .. " not supported")
            end
        end
    end
    
    -- =========================================================================
    -- COMPATIBILITY API REGISTRATION
    -- =========================================================================
    
    -- Prevent duplicate hook registration on consecutive ROM loads
    if not stateoutput.api_hooks_bound then
        dbg_print("Binding API Hooks...")
        
        -- 0. Global Pause/Resume Notifiers (Works for all games)
        if emu.add_machine_pause_notifier then
            exports.subscriptions.pause = emu.add_machine_pause_notifier(function()
                broadcast_native_event("pause = 1\r\n")
            end)
        end
        
        if emu.add_machine_resume_notifier then
            exports.subscriptions.resume = emu.add_machine_resume_notifier(function()
                broadcast_native_event("pause = 0\r\n")
            end)
        end
        
        -- 1. (v9.1.0) The devices-started hook that used to register MSOP's own
        --    synthetic outputs has been removed along with Register_Master_List
        --    itself - see the "REMOVED IN v9.1.0" note just above on_start, and
        --    https://github.com/mamedev/mame/pull/15639 for why that capability is
        --    never coming back. Nothing replaces it here: native outputs are now
        --    discovered by enumeration from within on_start, which needs no hook of
        --    its own because a machine's outputs already exist by the time
        --    machine_reset fires.

        -- 2. RESET Phase: Load the ROM configuration and bind memory
        if emu.add_machine_reset_notifier then
            dbg_print("Hooked on_start to machine_reset (RESET)")
            exports.subscriptions.reset = emu.add_machine_reset_notifier(on_start)
        else
            emu.register_start(on_start)
        end
        
        -- 3. STOP Phase: Cleanup on session end
        if emu.add_machine_stop_notifier then
            exports.subscriptions.stop = emu.add_machine_stop_notifier(on_machine_stop)
        elseif emu.register_stop then
            emu.register_stop(on_machine_stop)
        end

        -- 4. SAVE-STATE Phase: re-align Lua mirrors with restored output values
        if emu.add_machine_post_load_notifier then
            dbg_print("Hooked on_post_load to post_load notifier (save-state resync)")
            exports.subscriptions.post_load = emu.add_machine_post_load_notifier(on_post_load)
        elseif emu.register_postload then
            dbg_print("Hooked on_post_load to register_postload (save-state resync, legacy)")
            emu.register_postload(on_post_load)
        end
        
        -- Mark hooks as bound so they don't stack on the next ROM launch
        stateoutput.api_hooks_bound = true
    end
end

return exports