@echo off
echo Script Started...
python msop_database_driver_compiler.py %*
pause
