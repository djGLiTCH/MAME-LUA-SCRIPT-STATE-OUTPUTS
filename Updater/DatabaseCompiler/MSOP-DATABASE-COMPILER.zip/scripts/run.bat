@echo off
REM MSOP Database Compiler - launcher (Windows). Runs the database compiler, then the driver compiler.
REM %~dp0 = this scripts\ folder, so it works regardless of the current working directory.
REM
REM Set MAME_SRC below to your MAME source checkout (the folder that contains src\mame) to enable the
REM driver compiler; leave it EMPTY to skip that step. (msop_database_driver_compiler.py also has its
REM own MAME_SRC_PATH default if you ever run it directly.)
set "MAME_SRC="

echo === Database Compiler (input\database\games ^<-^> database.lua/json) ===
python "%~dp0msop_database_compiler.py"
if errorlevel 1 goto :error

echo.
if "%MAME_SRC%"=="" (
    echo === Driver Compiler SKIPPED - MAME_SRC not set in this launcher ===
) else (
    echo === Driver Compiler ^(MAME source -^> database_driver.lua^) ===
    python "%~dp0msop_database_driver_compiler.py" --mame-src "%MAME_SRC%"
    if errorlevel 1 goto :error
)

echo.
echo Done.
pause
exit /b 0

:error
echo.
echo A step failed - see the output above.
pause
exit /b 1
