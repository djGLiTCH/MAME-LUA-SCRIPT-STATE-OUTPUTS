@echo off
REM MSOP Database Compiler - STABLE channel launcher (Windows).
REM One-shot, no prompts: stamps plugin.json channel=stable, syncs versions/dates in
REM input\, then compiles to output\stateoutput\ (mode 1). See run.bat for the
REM interactive version and the optional driver-compiler step.
python "%~dp0msop_database_compiler.py" stable
if errorlevel 1 (
    echo.
    echo The compile failed - see the output above.
    pause
    exit /b 1
)
echo.
echo Done - output\stateoutput\ is tagged STABLE and ready to ship.
pause
exit /b 0
