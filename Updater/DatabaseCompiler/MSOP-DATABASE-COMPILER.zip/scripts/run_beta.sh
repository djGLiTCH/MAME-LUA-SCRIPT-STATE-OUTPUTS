#!/usr/bin/env bash
# MSOP Database Compiler - BETA channel launcher (Linux/macOS).
# One-shot, no prompts: stamps plugin.json channel=beta, syncs versions/dates in
# input/, then compiles to output/stateoutput/ (mode 1). See run.sh for the
# interactive version and the optional driver-compiler step.
set -e
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PY="$(command -v python3 || command -v python)"
"$PY" "$DIR/msop_database_compiler.py" beta
echo
echo "Done - output/stateoutput/ is tagged BETA and ready to ship."
