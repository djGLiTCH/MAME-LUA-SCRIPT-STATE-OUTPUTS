#!/usr/bin/env bash
# MSOP Database Compiler - launcher (Linux/macOS). Runs the database compiler, then the driver compiler.
# Paths resolve from this script's own location, so it works regardless of the current directory.
#
# Set MAME_SRC to your MAME source checkout (the folder that contains src/mame) to enable the driver
# compiler; leave it EMPTY to skip that step. (msop_database_driver_compiler.py also has its own
# MAME_SRC_PATH default if you ever run it directly.)
set -e
MAME_SRC=""

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PY="$(command -v python3 || command -v python)"

echo "=== Database Compiler (input/stateoutput/game_json <-> database.lua/json) ==="
"$PY" "$DIR/msop_database_compiler.py"

echo
if [ -z "$MAME_SRC" ]; then
  echo "=== Driver Compiler SKIPPED - MAME_SRC not set in this launcher ==="
else
  echo "=== Driver Compiler (MAME source -> database_driver.lua) ==="
  "$PY" "$DIR/msop_database_driver_compiler.py" --mame-src "$MAME_SRC"
fi

echo
echo "Done."
