# MAME State Output Project (MSOP)
## MSOP Database Compiler

- **Created By:** Jacob Simpson (DJ GLiTCH)
- **Copyright:** (c) 2026 Jacob Simpson (DJ GLiTCH). All Rights Reserved.
- **License:** GNU General Public License GPL-v3.0
- **Repository:** https://github.com/djGLiTCH/MAME-LUA-SCRIPT-STATE-OUTPUTS

---

Compiles the per-game MSOP configs into the MSOP Lua plugin's runtime database, and (optionally)
scrapes a MAME source checkout for each game's native output names. Structured the same way as the
Hooker INI Compiler: `scripts/` = run, `input/` = edit, `output/` = generated, `archive/` = history.

## Folder layout

```
Database Compiler/
├── scripts/            YOU RUN THIS
│   ├── msop_database_compiler.py         games <-> database.json, and -> database.lua
│   ├── msop_database_driver_compiler.py  MAME source -> database_driver.lua (+ scrape report)
│   ├── run.bat                           Windows: runs both (driver skipped if no MAME path)
│   └── run.sh                            Linux/macOS: runs both (driver skipped if no MAME path)
│
├── input/              YOU EDIT THIS
│   ├── stateoutput/    the human-maintained plugin source:
│   │                   init.lua, plugin.json, readme.txt  (the plugin runtime; versions/dates auto-aligned on run)
│   └── database/       the game-data source:
│       ├── games/*.json    per-game configs (one file per ROM, + _default.json)
│       └── database.json   single-file mirror, interchangeable with games/
│
├── output/             GENERATED  (safe to delete; rebuilt on every run)
│   ├── stateoutput/    the deployable plugin folder for MSOP Plugin releases:
│   │                   database.lua + database_driver.lua + copies of init.lua/plugin.json/readme.txt
│   └── results/        mame_driver_native_output_scrape_report.json (driver audit aid)
│
└── archive/            HISTORY (old script/init versions)
```

At a glance: **`scripts/` = run, `input/` = edit, `output/` = generated, `archive/` = history.**
Grab **`output/stateoutput/`** as the finished plugin folder to ship in an MSOP Plugin release.

## How to run

- `scripts/run.bat` (Windows) or `scripts/run.sh` (Linux/macOS) — runs the database compiler
  (interactive mode menu), then the driver compiler. The driver step is **skipped** unless you set
  `MAME_SRC` at the top of the launcher to your MAME source checkout (the folder that contains
  `src/mame`).
- **Release-channel launchers (headless, no prompts):**
  - `scripts/run_stable.bat` / `scripts/run_stable.sh` — stamps `plugin.json` `channel = "stable"`,
    syncs versions/dates in `input/`, then compiles (mode 1). `output/stateoutput/` comes out tagged
    STABLE, ready to zip.
  - `scripts/run_beta.bat` / `scripts/run_beta.sh` — same, tagged BETA.
  - Equivalent direct calls: `python scripts/msop_database_compiler.py stable` (or `beta`). Any other
    argument prints usage and exits with code 2.
- Or run either script directly with no argument for the interactive menu:
  `python scripts/msop_database_compiler.py` / `python scripts/msop_database_driver_compiler.py`.

Both scripts resolve their paths from the project root via `__file__`, so they run from any directory.

## What each does

- **`msop_database_compiler.py`** — two interactive modes:
  - **Mode 1:** `input/database/games/*.json` → `input/database/database.json` +
    `output/stateoutput/database.lua`.
  - **Mode 2:** `input/database/database.json` → `input/database/games/*.json` +
    `output/stateoutput/database.lua`.

  Either mode aligns the version/date across `init.lua`/`plugin.json`/`readme.txt` in
  `input/stateoutput/` (including init.lua's `PLUGIN_VERSION_NUM`/`PLUGIN_DATE_NUM` constants) and
  copies them into `output/stateoutput/`, so the output is a complete plugin folder. It needs no MAME
  source. With a `stable`/`beta` argument it additionally stamps `plugin.json`'s `channel` and runs
  mode 1 headlessly (see the release-channel launchers above). The deploy-time `relay` member (the
  per-install stamp the Configurator writes into installed copies) is always **stripped** from the
  source/shipped `plugin.json` if it ever leaks in — manual installs must self-detect.

- **`msop_database_driver_compiler.py`** — scrapes a MAME source checkout for each supported ROM's
  native output names and writes `output/stateoutput/database_driver.lua` (the companion `init.lua`
  loads it; missing/stale just degrades to no native forwarding). With the scrape report enabled
  (default; `--no-scrape-report` to skip) it also writes
  `output/results/mame_driver_native_output_scrape_report.json`.
