# MAME State Output Project (MSOP)
## MSOP Hooker INI Compiler

- **Created By:** Jacob Simpson (DJ GLiTCH)
- **Copyright:** (c) 2026 Jacob Simpson (DJ GLiTCH). All Rights Reserved.
- **License:** GNU General Public License GPL-v3.0
- **Repository:** https://github.com/djGLiTCH/MAME-LUA-SCRIPT-STATE-OUTPUTS

---

Compiles hand-maintained MSOP game profiles into per-hardware **MAME Hooker `.ini`** files.
The tooling lives in `scripts/` (local-only, git-ignored); everything else is either
hand-maintained input or generated output.

## Folder layout

```
Hooker INI Compiler/
├── scripts/            YOU RUN THIS   (git-ignored, local-only)
│   ├── msop_hooker_ini_compiler.py   compiles input/games/*.json -> output/ini/*.ini
│   ├── run.bat                        Windows launcher
│   └── run.sh                         Linux/macOS launcher
│
├── input/              YOU EDIT THIS  (hand-maintained source)
│   ├── config/                  settings.json (player/hardware assignments)
│   │                            + stateevents.json (event -> command definitions)
│   ├── peripherals/             peripheral (gun) payload profiles (gun4ir.json, sinden.json, _default.json, ...)
│   ├── ledcontrollers/          LED controller profiles (zones + bindings, e.g. wled.json)
│   └── games/                   MSOP game-profile JSON, one file per game, per platform subfolder
│
├── output/             GENERATED      (safe to delete; rebuilt on every run)
│   └── ini/                     final MAME Hooker .ini files (mirrors input/games layout)
│
└── archive/            HISTORY
    ├── versions/               old dated compiler zips + prior script versions
    └── one-off/                single-use maintenance scripts
```

At a glance: **`scripts/` = run, `input/` = edit, `output/` = generated, `archive/` = history.**

## How to run

- `scripts/run.bat` (Windows) or `scripts/run.sh` (Linux/macOS), or
- `python scripts/msop_hooker_ini_compiler.py`.

The script resolves its paths from the project root via `__file__`, so it can be run from any
working directory.

## What it does

`msop_hooker_ini_compiler.py` walks every `input/games/<platform>/<game>.json` profile and,
for each one, merges:

- the player hardware assignments in `input/config/settings.json`,
- the event → command map in `input/config/stateevents.json`, and
- the hex payloads in `input/peripherals/*.json`

into an `output/ini/<platform>/<game>.ini` for MAME Hooker / OutputHooker, mirroring the input's
per-platform subfolder layout.

### Empty template mode

Emit an **empty template** — every game's `.ini` still lists all of its outputs (and the
system-event headers), but with empty values, ignoring all player/hardware assignments. This is the
version shipped in the distribution zip, so a user can hand-fill their own commands. Turn it on
either way:

- pass `--empty` on the command line (`python scripts/msop_hooker_ini_compiler.py --empty`), or
- set `GENERATE_EMPTY_TEMPLATE = True` near the top of `msop_hooker_ini_compiler.py` (handy if you
  don't want to remember the command).
