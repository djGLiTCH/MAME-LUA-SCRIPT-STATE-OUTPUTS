# Hooker Program Compatibility Matrix

**Policy:** the MSOP Hooker INI Compiler targets the **MAMEhooker-family INI dialect** — the
subset understood by MAMEhooker, OutputHooker, QMamehook, and any future hooker program that
consumes the same `gamename.ini` format. Hook Of The Reaper (HOTR) is **not** an INI target:
HOTR drives light guns through its own per-gun *default LG* files (`.hor`), and a separate
compiler for those will be organised later. Anything marked "MSOP only" below is an extension
of MSOP Configurator's internal hooker engine and must not be relied on by exported INIs.

Sources (all verified against program source code or official documentation, 2026-07):
MAMEhooker 5.1 `docs/readme.txt` + `Command Reference.txt` · OutputHooker v1.6.0 source
(`core/OutputHookerCore.cpp`, `Global.h`) · QMamehook (SeongGino, `qhookermain.cpp`) ·
Hook Of The Reaper v1.3.1 source (`HookerEngine/HookerEngine.cpp`, `Global.h`) ·
MSOP Configurator native player-hardware engine (MainWindow.axaml.cs).

## INI command verbs

| Verb | Meaning | MAMEhooker 5.1 | OutputHooker 1.6 | QMamehook | HOTR 1.3.x (INI path) | MSOP Native |
|---|---|---|---|---|---|---|
| `cmo` | COM port open | Y | Y | Y | Y | S¹ |
| `cmc` | COM port close | Y | Y | Y | Y | S¹ |
| `css` | COM settings | Y | Y | N | Y | N |
| `csl` | COM line ctrl (DTR/RTS) | Y | N | N | Y | N |
| `cmr` | COM read → buffer | Y | Y | N | Y | N |
| `cmw` | COM write text | Y | Y | Y | Y | **Y** |
| `tsc` / `tsd` | TCP connect/disconnect | N | Y | N | N | S¹ |
| `tss` | TCP send | N | Y | N | N | **Y** |
| `udp` | UDP send | N | Y | N | N | N² |
| `hpr` | HTTP POST | N | Y | N | N | **Y** |
| `ghd` | Generic HID write | Y | Y | N | Y | **Y** |
| `nll` | Null command | Y (no-op) | Y (no-op) | N | Y (no-op) | **Y (pause!)³** |
| `wat` | Wait N ms | Y | N | N | N | N³ |
| `lws lwp lwc lwr lwk` | LEDWiz | Y | Y | N | N | N⁴ |
| `uls uli ulf ulk` | Ultimarc PacDrive/PacLED64 | Y | Y | N | Y | N⁴ |
| `ulc ulp uld` | Ultimarc scripts (UHID) | Y | Y (`ulc`) | N | N | N |
| `ffb / ffa / dff` | Force feedback | Y (`dff/ffa`) | Y (`ffb/ffa`) | N | N | N |
| `xip / xia` | XInput rumble | Y | N | N | N | N |
| `kbd spk ply pya dsp dss wii lpt lpe` | Misc outputs | Y | Y (`ply` only) | N | N | N |
| `apl / apc / cmd / cdw` | Launch/close app | Y (`cmd/cdw`) | Y (`apl/apc`) | N | N | N |
| `lds sds sdf sbf ibf bmo rfs lop lfs kls lwa cpy kll log qut ref` | MAMEhooker scripting | Y | N | N | N | N |

¹ MSOP's engine ignores `cmo`/`cmc`/`tsc` because its transport layer opens/closes devices
from the Hardware → Configuration rows; the INI lines remain for external hookers.
² UDP endpoints belong to MSOP's LED Controller entries, not ad-hoc INI writes.
³ **Pacing:** `nll <ms>` is a no-op in every external hooker; MAMEhooker's real delay verb
`wat` is MAMEhooker-only (and errors OutputHooker's INI validator). Inter-command pacing is
therefore NOT portably expressible in an INI. MSOP honours `nll <ms>` as a pause (extension)
and additionally enforces the per-player Solenoid Delay at runtime.
⁴ LED boards are driven natively by MSOP's LED Controllers engine, not via INI verbs.

## Value tokens & dialect features

| Feature | MAMEhooker | OutputHooker | QMamehook | HOTR (INI) | MSOP Native |
|---|---|---|---|---|---|
| `%s%` current value | Y | Y | Y | Y | Y |
| `%s%` inside `ghd` bytes | ? (undocumented) | **Y — multi-`%s%` splits value into tens/units digits** | n/a | Y | Y (OutputHooker semantics) |
| `%b1%–%b10%` buffers | Y | N | N | N | N |
| `%outputname%` cross-output | Y | N | N | N | N |
| `%d1% %d0%` digit split | N | N | N | Y (default-LG layer) | N — use `ghd` multi-`%s%` instead |
| `D:<ms>` inline delay | N | N | N | Y (default-LG layer ONLY, not INIs) | N — never emit into INIs |
| `\|` value-indexed sections | Y | Y | Y | Y | Y |
| `,` multi-command | Y | Y | Y | Y | Y |
| `0xNN` + `"text"` byte strings in `cmw` | N (sent as literal text) | N (literal text) | N (literal text) | Y (default-LG layer only) | **Y (MSOP extension)⁵** |

⁵ MSOP's native engine detects a `cmw` payload consisting entirely of `0xNN` tokens and
quoted ASCII strings (the Xenas dialect) and encodes it to raw bytes before writing. External
hookers send such payloads as literal text — profiles using this dialect are flagged in their
Description and only fully work with MSOP native (or HOTR via default LG files).

## Per-consumer notes

- **MAMEhooker 5.1** — the reference dialect. Windows-only. Richest scripting; `ghd` byte
  behaviour with `%s%` is undocumented, so digit displays are marked untested there.
- **OutputHooker 1.6** — closest to a superset for devices; adds the network verbs
  (`tsc/tss/udp/hpr`). Its INI validator shows an error dialog for unknown verbs, so exported
  INIs must never contain `wat`, `%d1%`, or `D:` tokens.
- **QMamehook** — serial-only and whitelisted (OpenFIRE `0xF143`, GUN4IR `0x2341`, Blamcon;
  RS3 needs manual whitelisting on Linux). `cmw` port numbers are player slots (detection
  order), not Windows COM numbers. Only `cmo/cmw/cmc` + `%s%`.
- **HOTR** — reads game INIs but ignores network verbs; guns are driven via its internal
  default-LG layer, which is where `%d` digits, `D:` delays, byte dialects, per-gun pacing
  (AimTrak 250 ms, Alien 40–65 ms, RS3 `Z0` 110/145 ms) and the redacted AimTrak recoil
  command live. HOTR support = the future default-LG compiler, not these INIs.
- **MSOP native engine** — executes the compiled INI (or the same content resolved in real
  time). Honours `nll` pauses, enforces Solenoid Delay recovery gaps, executes `ghd` via
  HidSharp, and drops stale queued commands (TTL) so bursts can't backlog. LED_* commands are
  consumed by the Lighting engine, never sent to guns.
