#!/usr/bin/env bash
# MSOP Plugin Output Generator - launcher (Linux/macOS)
# Paths are resolved from this script's own location, so it works regardless
# of the current working directory.
set -e

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PY="$(command -v python3 || command -v python)"

"$PY" "$DIR/msop_plugin_output_generator.py"

echo
echo "Done."
