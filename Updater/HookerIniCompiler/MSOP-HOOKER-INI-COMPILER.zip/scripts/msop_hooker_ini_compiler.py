#
# MAME STATE OUTPUT PROJECT (MSOP)
# MSOP HOOKER INI COMPILER  (compile: game json -> ini)
# Compiler Version: 0.9.1
# Compiler Date: 2026.07.10
# Project: https://github.com/djGLiTCH/MAME-LUA-SCRIPT-STATE-OUTPUTS
# License: GNU GENERAL PUBLIC LICENSE GPL-v3.0
# Copyright (c) 2026 Jacob Simpson (DJ GLiTCH). All Rights Reserved.
#
# Compiles the hand-maintained MSOP JSON game profiles from 'input/games/' into
# hardware-specific MAME Hooker '.ini' files in 'output/ini/'.
#
# This compiler acts as the bridge between universal game state events and
# specific hardware commands. It dynamically reads player hardware assignments
# from 'input/config/settings.json', matches them against the event definitions
# in 'input/config/stateevents.json', and extracts the correct hexadecimal
# payloads from the profiles in 'input/playerhardware/'.
#
# All paths are resolved relative to the project root (the parent of this
# 'scripts/' folder) via __file__, so this can be run from any working
# directory - e.g. straight from scripts/run.bat.
#
# Key Features:
#   [1] Dynamic Variable Injection: Replaces static tags in hardware profiles
#       with dynamic player settings.
#   [2] Hardware Protections: Injects buffer flushes ('nll') and sequential
#       delays to prevent serial lockups on slower hardware chips.
#   [3] Comprehensive Diagnostics: Tracks missing payloads, undefined events,
#       and unmapped outputs, generating a detailed summary upon completion.
#   [4] Priority bottleneck (single-LED/single-display guns show the highest-priority
#       active command per game, from the profile Default_Priorities lists) and
#       Trigger/Value-aware [Output] line layout (triggers: "nll|cmds"; values:
#       one catch-all section) - mirrors the MSOP Configurator IniCompilerService.
#   [5] Transport-aware output (matches the MSOP Configurator's IniCompilerService):
#       serial guns -> 'cmw <port> <payload>' wrapped in cmo/cmc;
#       network guns (Metadata.Communication_Method == Network) -> 'tss <player>'
#       plus a 'tsc <player> <ip> <port>' connect line in MameStart;
#       USB HID guns (Metadata.Communication_Method == HID) -> MAMEhooker-family
#       'ghd <player> &HVID &HPID <byteCount> <bytes>' writes with no cmo/cmc.
#       See HOOKER-COMPATIBILITY-MATRIX.md for which hooker consumes what.
#

import os
import sys
import json
import textwrap

# ==========================================
# PROJECT PATHS (root-anchored via __file__)
# ==========================================
# scripts/msop_hooker_ini_compiler.py -> parent of 'scripts/' is the project root.
BASE_DIR     = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONFIG_DIR   = os.path.join(BASE_DIR, "input", "config")     # settings + state-event defs
HARDWARE_DIR = os.path.join(BASE_DIR, "input", "playerhardware")   # per-device payload profiles
GAMES_DIR    = os.path.join(BASE_DIR, "input", "games")      # hand-maintained game profiles (json)
INI_DIR      = os.path.join(BASE_DIR, "output", "ini")       # our output (.ini)

# EMPTY TEMPLATE MODE - every game's .ini lists all of its outputs (and the system events) with
# empty values, ignoring all player/hardware assignments. This is the version that ships in the
# distribution zip so a user can hand-fill their own commands. A normal run compiles real payloads
# from settings.json + the hardware profiles as usual.
#
# Set GENERATE_EMPTY_TEMPLATE to True below to always run in this mode (no command needed), or leave
# it False and pass --empty on the command line for a one-off. Either turns it on.
GENERATE_EMPTY_TEMPLATE = False
EMPTY_TEMPLATE_MODE = GENERATE_EMPTY_TEMPLATE or "--empty" in sys.argv

# ==========================================
# 0. DIAGNOSTIC REPORTER SETUP
# ==========================================
class DiagnosticReporter:
    """
    Tracks and categorizes all anomalies during the compilation process.
    - Errors: Syntax crashes, missing necessary payloads, undefined events. (Drops Health %)
    - Warnings: Unassigned players, unexpected events.
    - Info: Explicitly unsupported hardware features, explicitly unmapped state outputs.
    """
    def __init__(self):
        self.critical_errors = []
        self.hardware_warnings = {}
        self.game_warnings = {}
        self.connection_warnings = []

    def init_hw(self, hw_name):
        if hw_name not in self.hardware_warnings:
            self.hardware_warnings[hw_name] = {
                "missing_global": False, 
                "missing_commands": set(), 
                "unsupported_commands": set(), 
                "total_requests": 0
            }

    def init_game(self, game_name):
        if game_name not in self.game_warnings:
            self.game_warnings[game_name] = {
                "unassigned_players": set(),  # Treated as WARNING (expected bypass)
                "unmapped_events": set(),     # Treated as WARNING (defined but unmapped)
                "invalid_events": set(),      # Treated as ERROR (typo or missing from definitions)
                "missing_system": set(),      # Treated as ERROR
                "info_mappings": set(),       # Treated as INFO (captured but intentionally false)
                "total_mappings": 0,
                "error_count": 0,
                "warning_count": 0,
                "info_count": 0
            }

    def log_game_error(self, game_name, category, message):
        self.init_game(game_name)
        self.game_warnings[game_name][category].add(message)
        self.game_warnings[game_name]["error_count"] += 1

    def log_game_warning(self, game_name, category, message):
        self.init_game(game_name)
        self.game_warnings[game_name][category].add(message)
        self.game_warnings[game_name]["warning_count"] += 1

    def log_game_info(self, game_name, category, message):
        self.init_game(game_name)
        self.game_warnings[game_name][category].add(message)
        self.game_warnings[game_name]["info_count"] += 1

    def print_summary(self, active_players, settings):
        """Prints the final formatted console report categorizing all tracked data."""
        print("\n" + "=" * 70)
        print(" COMPILATION DIAGNOSTIC & SUMMARY".center(70))
        print("=" * 70)

        # --- 1. Configuration Summary ---
        print("\n[SETTINGS / CONFIGURATION]")
        print(f"  + Total Players Assigned: {len(active_players)}")
        for p_key, p_data in sorted(active_players.items()):
            hw = p_data.get('Hardware_Target', 'None')
            port = p_data.get('COM_Port', 'None')
            baud = p_data.get('Baud_Rate', 'None')
            print(f"      {p_key}: Hardware={hw} | COM={port} | Baud={baud}")
        
        prefs = settings.get("Engine_Preferences", {})
        refresh = prefs.get("Refresh_Time_ms", prefs.get("Refresh_Time_MS", "33"))
        if not refresh:
            refresh_display = "0 ms (maximum cycle refresh)"
        else:
            refresh_display = f"{refresh}ms"
        print(f"  + Engine Refresh Time: {refresh_display}")

        if self.critical_errors:
            print("\n[CRITICAL ERRORS] - Files Skipped")
            for err in self.critical_errors:
                print(f"  X {err}")

        if self.connection_warnings:
            print("\n[CONNECTION ERRORS] - Settings.json")
            for warn in self.connection_warnings:
                print(f"  ! {warn}")

        # Track Success Rates and Specific Files
        hw_success_files = []
        hw_info_files = []
        hw_error_files = []
        
        game_success_files = []
        game_warn_files = []
        game_error_files = []

        # --- 2. Hardware Profiles Report ---
        print("\n[HARDWARE PROFILES]")
        for hw, data in sorted(self.hardware_warnings.items()):
            err_count = 0
            messages = []
            
            if data["missing_global"]:
                err_count += 1
                messages.append("      [ERROR] Missing Master [Global] block.")
            
            missing_cmds = len(data["missing_commands"])
            unsupported_cmds = len(data["unsupported_commands"])
            
            if missing_cmds > 0:
                err_count += missing_cmds
                if missing_cmds == data["total_requests"] and data["total_requests"] > 0:
                    messages.append("      [FATAL] No valid state event command references found (Profile appears completely empty).")
                else:
                    messages.append(f"      [ERROR] Missing payloads for {missing_cmds} requested command(s):")
                    for cmd in sorted(data['missing_commands']):
                        messages.append(f"          - {cmd}")
                    
            if unsupported_cmds > 0:
                messages.append(f"      [INFO] Hardware explicitly lacks support for {unsupported_cmds} command(s):")
                for cmd in sorted(data['unsupported_commands']):
                    messages.append(f"          - {cmd}")
            
            # Tally logic for Final Summary Tracking
            hw_filename = hw
            if err_count > 0:
                hw_error_files.append(hw_filename)
            elif unsupported_cmds > 0:
                hw_info_files.append(hw_filename)
            else:
                hw_success_files.append(hw_filename)

            if err_count == 0 and unsupported_cmds == 0:
                print(f"  + {hw}.json: 100% Healthy (0 Errors)")
            elif err_count == 0:
                print(f"  ~ {hw}.json: 100% Healthy (0 Errors, {unsupported_cmds} Info)")
                for msg in messages:
                    print(msg)
            else:
                pct = max(0, 100 - int((err_count / max(1, data["total_requests"])) * 100))
                print(f"  - {hw}.json: {pct}% Health ({err_count} Errors)")
                for msg in messages:
                    print(msg)

        # --- 3. Game Profiles Report ---
        print("\n[GAME PROFILES]")
        for game, data in sorted(self.game_warnings.items()):
            total = data["total_mappings"]
            err_count = data["error_count"]
            warn_count = data["warning_count"]
            info_count = data["info_count"]
            
            # Tally logic for Final Summary Tracking
            game_filename = game
            if err_count > 0:
                game_error_files.append(game_filename)
            elif warn_count > 0:
                game_warn_files.append(game_filename)
            else:
                game_success_files.append(game_filename)
            
            pct = max(0, 100 - int((err_count / max(1, total)) * 100))
            
            if len(data["invalid_events"]) == total and total > 0:
                print(f"  - {game}.json: 0% Health ({err_count} Errors) - FATAL: No valid state event references found.")
            elif err_count == 0 and warn_count == 0:
                info_str = f", {info_count} Info" if info_count > 0 else ""
                print(f"  + {game}.json: 100% Mapped (0 Errors{info_str})")
            elif err_count == 0:
                info_str = f", {info_count} Info" if info_count > 0 else ""
                print(f"  ~ {game}.json: 100% Mapped (0 Errors, {warn_count} Warnings{info_str})")
            else:
                warn_str = f", {warn_count} Warnings" if warn_count > 0 else ""
                info_str = f", {info_count} Info" if info_count > 0 else ""
                print(f"  - {game}.json: {pct}% Health ({err_count} Errors{warn_str}{info_str})")
                
            if data["invalid_events"]:
                print(f"      [ERROR] Invalid State Events (Unknown event not in definitions):")
                for evt in sorted(data['invalid_events']):
                    print(f"          - {evt}")
            if data["missing_system"]:
                print(f"      [ERROR] Missing System Payloads:")
                for evt in sorted(data['missing_system']):
                    print(f"          - {evt}")
            if data["unmapped_events"]:
                print(f"      [WARNING] Defined but Unmapped State Events:")
                for evt in sorted(data['unmapped_events']):
                    print(f"          - {evt}")
            if data["unassigned_players"]:
                print(f"      [WARNING] Expected Missing Assignments (Players bypassed):")
                for evt in sorted(data['unassigned_players']):
                    print(f"          - {evt}")
            if data.get("info_mappings"):
                print(f"      [INFO] Explicitly Unmapped State Outputs:")
                for evt in sorted(data['info_mappings']):
                    print(f"          - {evt}")

        # --- 4. Final Compilation Summary ---
        total_hw = len(self.hardware_warnings)
        total_games = len(self.game_warnings)
        
        hw_succ_rate = (len(hw_success_files) / max(1, total_hw)) * 100 if total_hw > 0 else 0
        hw_info_rate = (len(hw_info_files) / max(1, total_hw)) * 100 if total_hw > 0 else 0
        hw_err_rate  = (len(hw_error_files) / max(1, total_hw)) * 100 if total_hw > 0 else 0
        
        game_succ_rate = (len(game_success_files) / max(1, total_games)) * 100 if total_games > 0 else 0
        game_warn_rate = (len(game_warn_files) / max(1, total_games)) * 100 if total_games > 0 else 0
        game_err_rate  = (len(game_error_files) / max(1, total_games)) * 100 if total_games > 0 else 0

        # Helper function to print vertical lists
        def print_file_list(file_list):
            if not file_list: return
            for file in sorted(file_list):
                print(f"          - {file}")

        print("\n" + "=" * 70)
        print(" FINAL COMPILATION SUMMARY")
        print("-" * 70)
        print(f"  - Hardware Profiles Processed: {total_hw}")
        print(f"     * Success Rate (Valid): {hw_succ_rate:.1f}% ({len(hw_success_files)}/{total_hw} files)")
        print_file_list(hw_success_files)
        print(f"     * Info Rate (Expected): {hw_info_rate:.1f}% ({len(hw_info_files)}/{total_hw} files)")
        print_file_list(hw_info_files)
        print(f"     * Error Rate (Failed):  {hw_err_rate:.1f}% ({len(hw_error_files)}/{total_hw} files)")
        print_file_list(hw_error_files)
        
        print(f"\n  - Game Profiles Converted:     {total_games}")
        print(f"     * Success Rate (Valid/Mapped):   {game_succ_rate:.1f}% ({len(game_success_files)}/{total_games} files)")
        print_file_list(game_success_files)
        print(f"     * Warning Rate (Invalid/Unmapped): {game_warn_rate:.1f}% ({len(game_warn_files)}/{total_games} files)")
        print_file_list(game_warn_files)
        print(f"     * Error Rate (Compilation Errors): {game_err_rate:.1f}% ({len(game_error_files)}/{total_games} files)")
        print_file_list(game_error_files)
        print("=" * 70 + "\n")

diagnostics = DiagnosticReporter()

# ==========================================
# 1. INITIALIZATION & DATA LOADING
# ==========================================
COMPILER_VERSION = "0.9.1"
COMPILER_DATE = "2026.07.10"

print("-" * 70)
print("MAME STATE OUTPUT PROJECT (MSOP)".center(70))
print("MSOP HOOKER INI COMPILER".center(70))
print("-" * 70)
print(f" Compiler Version: {COMPILER_VERSION}")
print(f" Compiler Date: {COMPILER_DATE}\n")
print(" Project: https://github.com/djGLiTCH/MAME-LUA-SCRIPT-STATE-OUTPUTS")
print(" License: GNU GENERAL PUBLIC LICENSE GPL-v3.0")
print(" Copyright (c) 2026 Jacob Simpson (DJ GLiTCH). All Rights Reserved.")
print("-" * 70)
print("\n[STARTING] Compiling MSOP game JSON profiles to MAME Hooker INIs...\n")

# Load core configuration files
with open(os.path.join(CONFIG_DIR, "settings.json"), "r") as f:
    settings = json.load(f)

with open(os.path.join(CONFIG_DIR, "stateevents.json"), "r") as f:
    universal_bridge = json.load(f)

# Extract mapping dictionaries from the bridge
state_to_cmd = universal_bridge.get("State_Event_To_Command", {})
sys_to_cmd = universal_bridge.get("System_Event_To_Command", {})
state_defs = universal_bridge.get("State_Event_Definitions", {})

active_players = {}
hardware_db = {}

# Build the active hardware database based ONLY on players defined in settings.json
for p_key, p_config in settings.get("Player_Assignments", {}).items():
    hw_target = p_config.get("Hardware_Target")
    if hw_target:
        # Validate that connection variables exist to prevent broken COM strings
        if not p_config.get("COM_Port") or not p_config.get("Baud_Rate"):
            diagnostics.connection_warnings.append(f"Player '{p_key}' is missing COM_Port or Baud_Rate.")
            
        active_players[p_key] = p_config
        
        # Load the hardware JSON into memory if it hasn't been cached yet
        if hw_target not in hardware_db:
            hw_path = os.path.join(HARDWARE_DIR, f"{hw_target}.json")
            if os.path.exists(hw_path):
                try:
                    with open(hw_path, "r") as f:
                        hw_data = json.load(f)
                        hardware_db[hw_target] = hw_data
                        diagnostics.init_hw(hw_target)

                        # Verify the shared command set exists ("Commands" in the current
                        # schema; "Global" in legacy profiles).
                        if "Commands" not in hw_data and "Global" not in hw_data:
                            diagnostics.hardware_warnings[hw_target]["missing_global"] = True
                except json.JSONDecodeError:
                    diagnostics.critical_errors.append(f"Malformed JSON syntax in input/hardware/{hw_target}.json")
            else:
                diagnostics.critical_errors.append(f"Hardware profile '{hw_target}.json' not found.")


# Empty-template mode: drop every player/hardware assignment so all outputs compile to empty
# values, while still emitting one line per output (and the system-event headers) for every game.
if EMPTY_TEMPLATE_MODE:
    print("[EMPTY TEMPLATE MODE] Ignoring player/hardware assignments - emitting empty commands.\n")
    active_players = {}
    hardware_db = {}


# ==========================================
# 2. COMPILER LOGIC FUNCTIONS
# ==========================================

# Master toggle for injecting safety delays (nll ms) between sequential commands.
# Crucial for preventing serial lockup on slower hardware chips.
ENABLE_SAFETY_DELAYS = False

# Master toggle for generating all mapped events in the output INI files in alphabetical order (A-Z).
SORT_INI_OUTPUTS = True


def inject_variables(raw_payload, player_config):
    """Replaces static placeholder tags in hardware profiles with dynamic player settings."""
    if not raw_payload: return ""
    # settings.json uses 'Solenoid_Delay_ms'; accept the legacy 'Solenoid_Delay_MS' casing too.
    delay = player_config.get("Solenoid_Delay_ms", player_config.get("Solenoid_Delay_MS", ""))
    cmd = raw_payload.replace("<SOLENOID_DELAY_MS>", str(delay))
    return cmd


def get_hardware_metadata(hw_profile, key):
    """Reads a Metadata value from a hardware profile ('' when absent/false/null)."""
    value = hw_profile.get("Metadata", {}).get(key)
    if value is None or value is False:
        return ""
    return str(value)


def build_ghd_prefix(hw_profile, player_key):
    """
    For USB HID guns (Metadata.Communication_Method contains 'HID') every payload compiles
    to a MAMEhooker-family 'ghd <device> &HVID &HPID' write instead of a cmw/tss line: the
    device number is the player number, VID/PID come from the profile metadata, and the
    profile payload supplies the '<byteCount> <bytes>' tail.
    Returns None for serial/network guns (the existing cmw/tss path).
    Mirrors IniCompilerService.BuildGhdPrefix in the MSOP Configurator - keep in sync.
    """
    method = get_hardware_metadata(hw_profile, "Communication_Method")
    if "hid" not in method.lower():
        return None

    def to_amp_hex(raw):
        t = str(raw or "").strip()
        if not t or t.lower() in ("false", "null", "none"):
            return "&H0000"
        if t.lower().startswith("0x"):
            t = t[2:]
        return "&H" + t

    player_num = player_key[1:] if player_key.startswith("P") else player_key
    vid = to_amp_hex(get_hardware_metadata(hw_profile, "VID"))
    pid = to_amp_hex(get_hardware_metadata(hw_profile, f"PID_P{player_num}"))
    return f"ghd {player_num} {vid} {pid}"


def is_network_gun(hw_profile):
    """Network guns (e.g. Sinden via TCP) use 'tss <player>' writes and a 'tsc' connect."""
    return "network" in get_hardware_metadata(hw_profile, "Communication_Method").lower()

def filter_display_preference(command_array, display_pref):
    """
    Filters out any display commands (e.g., LED screens) that do not match 
    the player's specific Display_Preference defined in settings.json.
    """
    filtered = []
    target_display_cmd = f"Display_{display_pref}"
    for cmd in command_array:
        if cmd.startswith("Display_"):
            if cmd == target_display_cmd:
                filtered.append(cmd)
        else:
            filtered.append(cmd)
    return filtered

def get_hardware_payload(hw_profile, hw_name, cmd, player_key):
    """
    Safely retrieves the hardware hex/text payload using a fallback hierarchy:
    1. Player-Specific override block (root-level legacy, or nested inside 'Commands'
       in the current profile schema - e.g. sinden.json "Commands": { ..., "P1": {...} })
    2. The shared 'Commands' set (current schema)
    3. Master [Global] fallback / root level (legacy schemas)

    If the payload is explicitly set to 'false' (boolean or string), it is logged
    as an intentionally unsupported feature, preventing false-positive errors.
    A payload of None (null) means UNKNOWN - logged as missing.
    """
    diagnostics.hardware_warnings[hw_name]["total_requests"] += 1

    commands_block = hw_profile.get("Commands", {})

    payload = None
    if player_key in hw_profile and isinstance(hw_profile[player_key], dict) and cmd in hw_profile[player_key]:
        payload = hw_profile[player_key][cmd]
    elif player_key in commands_block and isinstance(commands_block[player_key], dict) and cmd in commands_block[player_key]:
        payload = commands_block[player_key][cmd]
    elif cmd in commands_block:
        payload = commands_block[cmd]
    elif "Global" in hw_profile and cmd in hw_profile["Global"]:
        payload = hw_profile["Global"][cmd]
    elif cmd in hw_profile:
        payload = hw_profile[cmd]

    # Flag as intentionally unsupported (Info)
    if payload is False or str(payload).strip().lower() == "false":
        diagnostics.hardware_warnings[hw_name]["unsupported_commands"].add(cmd)
        return ""

    # Flag as accidentally missing / unknown (Error)
    if not payload:
        diagnostics.hardware_warnings[hw_name]["missing_commands"].add(cmd)
        return ""

    return str(payload)

def format_payloads_with_delay(raw_payload, port, interval_ms, prefix=None):
    """
    Formats the raw payload into a safe transmission string using the pipe delimiter (|).

    `prefix` selects the transport verb (default: serial 'cmw <port>'):
      - 'tss <player>'                    network guns (OutputHooker consumes these)
      - 'ghd <player> &HVID &HPID'        USB HID guns (payload = '<byteCount> <bytes>')

    CRITICAL HARDWARE PROTECTIONS (serial/network only):
    1. Null Flush ('nll'): Prepending an empty nll command flushes dirty data from
       the Windows serial buffer, ensuring the first byte of the actual payload is never dropped.
       (Without this, guns often drop external commands and fall back to physical auto-recoil).
    2. Interval Delays ('nll MS'): Injects a pause between rapid sequential commands
       so the hardware chip has time to process before the next byte arrives.
       NOTE: external hookers treat 'nll' as a no-op; only MSOP's native engine actually
       pauses on 'nll <ms>' (see HOOKER-COMPATIBILITY-MATRIX.md).
    """
    if not raw_payload: return []

    is_ghd = prefix is not None and prefix.startswith("ghd")
    command_prefix = prefix if prefix else f"cmw {port}"

    # VALUE-SECTIONED payloads (e.g. the RS3's Ammo_Value 'Z0|Z1|Z2|Z3|Z4|Z5'): the '|' picks
    # the section by the OUTPUT'S VALUE, so every section needs its own transport prefix and
    # exactly one section fires - no flush, no interval delays. Emitted as a single
    # pre-sectioned line; empty sections become nll (a safe no-op).
    if "|" in raw_payload:
        sections = [s.strip() for s in raw_payload.split("|")]
        return ["|".join(f"{command_prefix} {s}" if s else "nll" for s in sections)]

    # Plain commands, comma-separated in the profile. NO section markers here - the EVENT
    # layout (trigger off-section / value catch-all) is applied by the caller, so a trigger's
    # LED payload fires together with its solenoid payload instead of landing in a dead
    # value section.
    commands = [cmd.strip() for cmd in raw_payload.split(",")]
    formatted_lines = []

    for i, cmd in enumerate(commands):
        formatted_lines.append(f"{command_prefix} {cmd}")

        # Inject the hardware breathing interval
        if ENABLE_SAFETY_DELAYS and interval_ms != "0" and i < len(commands) - 1:
            formatted_lines.append(f"nll {interval_ms}")

    return formatted_lines


def layout_output_line(commands, normalized_event):
    """
    Lays one event's commands out as a MAMEhooker [Output] line. '|' separates VALUE sections
    (section index = the output's value, last section catches the rest), ',' separates commands
    WITHIN a section:
      Trigger events -> 'nll|cmdA,cmdB'  (value 0 = off no-op; any non-zero fires ALL of the
                        event's payloads together - solenoid AND its LED)
      Value events   -> 'cmdA,cmdB'      (single catch-all so every change fires, %s% carrying
                        the value)
      Pre-sectioned payloads (explicit value maps like the RS3's 'Z0|Z1|...') own the whole
      line - they cannot legally combine with other commands.
    Mirrors IniCompilerService.BuildGameIniContent's LayoutLine - keep in sync.
    """
    if not commands:
        return ""
    sectioned = next((c for c in commands if "|" in c), None)
    if sectioned:
        return sectioned
    joined = ",".join(commands)
    kind = state_defs.get(normalized_event, "Trigger")
    return joined if str(kind).lower() == "value" else f"nll|{joined}"


def peek_hardware_payload(hw_profile, cmd, player_key):
    """Silent payload probe for the priority contest (no diagnostics side effects)."""
    commands_block = hw_profile.get("Commands", {})
    payload = None
    if player_key in hw_profile and isinstance(hw_profile[player_key], dict) and cmd in hw_profile[player_key]:
        payload = hw_profile[player_key][cmd]
    elif player_key in commands_block and isinstance(commands_block[player_key], dict) and cmd in commands_block[player_key]:
        payload = commands_block[player_key][cmd]
    elif cmd in commands_block:
        payload = commands_block[cmd]
    elif "Global" in hw_profile and cmd in hw_profile["Global"]:
        payload = hw_profile["Global"][cmd]
    elif cmd in hw_profile:
        payload = hw_profile[cmd]
    if payload is False or payload is None or str(payload).strip().lower() in ("false", "null", ""):
        return None
    return str(payload)


def compute_priority_winners(hw_profile, game_profile, player_key):
    """
    The STRICT priority bottleneck, mirroring IniCompilerService.CompileWithStrictPriority's
    cross-event scan: single-LED / single-display guns can only show one thing per game, so the
    highest-priority LED_* and Display_* command that (a) is reachable from any of THIS game's
    mapped events targeting this player (or Global) and (b) has a usable payload wins; every
    other LED/Display command compiles away for this game. Priorities come from the profile's
    Default_Priorities lists (the standalone compiler has no per-player custom lists).
    Returns (allowed_led, allowed_display, led_list, display_list).
    """
    priorities = hw_profile.get("Default_Priorities", {}) or {}
    led_list = priorities.get("LED", []) or []
    display_list = priorities.get("Display", []) or []
    allowed_led = None
    allowed_display = None

    for _, event_mapping in game_profile.items():
        if not isinstance(event_mapping, str) or event_mapping.lower() == "false":
            continue
        target = event_mapping.split("_")[0] if "_" in event_mapping else "Global"
        if target != player_key and target != "Global":
            continue
        normalized = event_mapping
        if normalized.startswith(("P1_", "P2_", "P3_", "P4_")):
            normalized = "PX_" + normalized[3:]
        for hw_cmd in state_to_cmd.get(normalized, []):
            if hw_cmd in led_list and peek_hardware_payload(hw_profile, hw_cmd, player_key):
                if allowed_led is None or led_list.index(hw_cmd) < led_list.index(allowed_led):
                    allowed_led = hw_cmd
            if hw_cmd in display_list and peek_hardware_payload(hw_profile, hw_cmd, player_key):
                if allowed_display is None or display_list.index(hw_cmd) < display_list.index(allowed_display):
                    allowed_display = hw_cmd

    return allowed_led, allowed_display, led_list, display_list


def command_defined(hw_profile, cmd, player_key):
    """True when the profile carries this command key anywhere (even as false/null)."""
    commands_block = hw_profile.get("Commands", {})
    if player_key in commands_block and isinstance(commands_block[player_key], dict) and cmd in commands_block[player_key]:
        return True
    if player_key in hw_profile and isinstance(hw_profile[player_key], dict) and cmd in hw_profile[player_key]:
        return True
    return cmd in commands_block or cmd in hw_profile.get("Global", {}) or cmd in hw_profile


def build_transport_prefix(hw_profile, player_key):
    """The per-player transport prefix for format_payloads_with_delay (None = serial cmw)."""
    ghd = build_ghd_prefix(hw_profile, player_key)
    if ghd:
        return ghd
    if is_network_gun(hw_profile):
        player_num = player_key[1:] if player_key.startswith("P") else player_key
        return f"tss {player_num}"
    return None

def compile_system_events(game_profile, game_name):
    """
    Compiles the universal MameStart and MameStop headers, which handle 
    opening COM ports, setting baud rates, establishing external communication 
    mode, and setting the game's specific Aspect Ratio.
    """
    system_outputs = {}
    game_aspect_ratio = game_profile.get("System_AspectRatio")

    for sys_event, cmd_list in sys_to_cmd.items():
        compiled_lines = []
        for p_key, p_config in active_players.items():
            hw_target = p_config["Hardware_Target"]
            if hw_target not in hardware_db: continue
            hw_profile = hardware_db[hw_target]
            port = p_config["COM_Port"]
            interval = str(hw_profile.get("Commands", {}).get("Command_Interval_ms", "0") or "0")

            # HID guns compile to ghd writes; network guns are opened by the tsc lines
            # appended to MameStart. Only true serial ports get the cmo/cmc wrappers.
            prefix = build_transport_prefix(hw_profile, p_key)
            is_serial_port = prefix is None

            # Network guns: prepend the TCP connect / disconnect for OutputHooker.
            if is_network_gun(hw_profile) and port:
                player_num = p_key[1:] if p_key.startswith("P") else p_key
                if sys_event == "MameStart":
                    parts = str(port).split(":")
                    ip = parts[0]
                    tcp_port = parts[1] if len(parts) > 1 else "13000"
                    compiled_lines.append(f"tsc {player_num} {ip} {tcp_port}")

            for cmd_name in cmd_list:
                if cmd_name == "Open_COM":
                    if is_serial_port:
                        cmo_str = f"cmo {port} baud={p_config['Baud_Rate']}_parity=N_data=8_stop=1"
                        compiled_lines.append(cmo_str)
                        compiled_lines.append("nll")  # buffer-flush placeholder after the port opens

                        # Hardcoded Boot Delay: Gives the COM port serial chip time to wake up
                        # before blasting the External Mode initialization command.
                        if ENABLE_SAFETY_DELAYS and interval != "0":
                            compiled_lines.append("nll 1500")

                    raw_payload = get_hardware_payload(hw_profile, hw_target, "COM_Open", p_key)
                    # Only try the legacy alternate spelling when the primary key is absent
                    # entirely (an explicit false/null answer should not log a second miss).
                    if not raw_payload and not command_defined(hw_profile, "COM_Open", p_key):
                        raw_payload = get_hardware_payload(hw_profile, hw_target, "Open_COM", p_key)

                    # Inject the game's Aspect Ratio hex code directly into the boot sequence
                    if sys_event == "MameStart" and game_aspect_ratio:
                        aspect_payload = get_hardware_payload(hw_profile, hw_target, game_aspect_ratio, p_key)
                        if aspect_payload:
                            if raw_payload:
                                raw_payload += f", {aspect_payload}"
                            else:
                                raw_payload = aspect_payload
                        else:
                            diagnostics.log_game_error(game_name, "missing_system", f"Requested {game_aspect_ratio} but hardware {hw_target} has no payload mapped.")

                    if raw_payload:
                        safe_commands = format_payloads_with_delay(raw_payload, port, interval, prefix)
                        compiled_lines.extend(safe_commands)

                elif cmd_name == "Close_COM":
                    raw_payload = get_hardware_payload(hw_profile, hw_target, "COM_Close", p_key)
                    if not raw_payload and not command_defined(hw_profile, "COM_Close", p_key):
                        raw_payload = get_hardware_payload(hw_profile, hw_target, "Close_COM", p_key)

                    if raw_payload:
                        safe_commands = format_payloads_with_delay(raw_payload, port, interval, prefix)
                        compiled_lines.extend(safe_commands)

                    if is_serial_port:
                        # Flush Delay: Ensures the final disconnect command fully transmits
                        # before the Windows COM buffer is aggressively killed by cmc.
                        if ENABLE_SAFETY_DELAYS and interval != "0":
                            compiled_lines.append(f"nll {interval}")

                        compiled_lines.append(f"cmc {port}")
                else:
                    raw_payload = get_hardware_payload(hw_profile, hw_target, cmd_name, p_key)
                    if raw_payload:
                        safe_commands = format_payloads_with_delay(raw_payload, port, interval, prefix)
                        compiled_lines.extend(safe_commands)

        if compiled_lines:
            system_outputs[sys_event] = " | ".join(compiled_lines)
        else:
            system_outputs[sys_event] = ""

    return system_outputs


# ==========================================
# 3. GAME PROCESSING & RECURSIVE FOLDER MIRRORING
# ==========================================
refresh_time = settings.get("Engine_Preferences", {}).get("Refresh_Time_ms",
               settings.get("Engine_Preferences", {}).get("Refresh_Time_MS", "33")) or "33"

# Recursively crawl 'input/games'. This perfectly duplicates any sub-folders
# (like input/games/MAME_Standard or input/games/DemulShooter) into 'output/ini'.
for root, _, files in os.walk(GAMES_DIR):
    for filename in files:
        if filename.endswith(".json"):
            game_name = filename.replace(".json", "")
            input_filepath = os.path.join(root, filename)
            rel_path = os.path.relpath(root, GAMES_DIR)

            output_dir = os.path.join(INI_DIR, rel_path)
            os.makedirs(output_dir, exist_ok=True)

            try:
                with open(input_filepath, "r", encoding="utf-8") as f:
                    game_profile = json.load(f)
            except json.JSONDecodeError:
                diagnostics.critical_errors.append(f"Malformed JSON syntax in input/games/{rel_path}/{filename}. Skipping.")
                continue
                
            diagnostics.init_game(game_name)
            system_events_dict = compile_system_events(game_profile, game_name)
            output_lines = []
            
            # Process every mapped event inside the game's JSON profile
            # Added a toggle to ensure all ini state hooks are generated alphabetically A-Z if enabled
            mapping_items = sorted(game_profile.items()) if SORT_INI_OUTPUTS else game_profile.items()
            for state_output, event_mapping in mapping_items:
                if state_output.startswith("System_"):
                    continue

                diagnostics.game_warnings[game_name]["total_mappings"] += 1
                
                # GRACEFUL BYPASS: Intentionally false mappings captured by json_compiler
                if event_mapping.lower() == "false":
                    diagnostics.log_game_info(game_name, "info_mappings", state_output)
                    output_lines.append(f"{state_output}=")
                    continue
                
                # Determine which player is the target (P1, P2, etc.) or if it's Global
                target_player = event_mapping.split("_")[0] if "_" in event_mapping else "Global"
                
                # Normalize tags (e.g., convert P1_Recoil to the bridge's universal PX_Recoil)
                normalized_event = event_mapping
                if normalized_event.startswith(("P1_", "P2_", "P3_", "P4_")):
                    normalized_event = "PX_" + normalized_event[3:]
                    
                # VALIDATION: Check if the mapped event is legally defined in the bridge
                if normalized_event not in state_to_cmd and not normalized_event.startswith("Global_"):
                    if normalized_event in state_defs:
                        # Event exists in definitions, but hasn't been mapped to hex commands yet -> WARNING
                        diagnostics.log_game_warning(game_name, "unmapped_events", event_mapping)
                    else:
                        # Event doesn't exist anywhere in the bridge (likely a typo) -> ERROR
                        diagnostics.log_game_error(game_name, "invalid_events", event_mapping)
                
                hardware_commands = state_to_cmd.get(normalized_event, [])
                
                # PATH A: Player-Specific Event (e.g., P1 fires a shot)
                if target_player in active_players:
                    p_config = active_players[target_player]
                    hw_target = p_config["Hardware_Target"]
                    hw_profile = hardware_db.get(hw_target, {})

                    pref = p_config.get("Display_Preference", "None")
                    filtered_cmds = filter_display_preference(hardware_commands, pref)
                    interval = str(hw_profile.get("Commands", {}).get("Command_Interval_ms", "0") or "0")
                    prefix = build_transport_prefix(hw_profile, target_player)

                    # Single-LED / single-display bottleneck (mirrors the MSOP Configurator).
                    allowed_led, allowed_display, led_list, display_list = compute_priority_winners(hw_profile, game_profile, target_player)

                    valid_commands = []
                    for cmd in filtered_cmds:
                        if cmd in led_list and cmd != allowed_led:
                            continue
                        if cmd in display_list and cmd != allowed_display:
                            continue
                        raw_payload = get_hardware_payload(hw_profile, hw_target, cmd, target_player)
                        if raw_payload:
                            parsed_payload = inject_variables(raw_payload, p_config)
                            if valid_commands and ENABLE_SAFETY_DELAYS and interval != "0":
                                valid_commands.append(f"nll {interval}")  # gap between payload groups
                            valid_commands.extend(format_payloads_with_delay(parsed_payload, p_config['COM_Port'], interval, prefix))

                    # One [Output] line per event, laid out by the event's Trigger/Value type.
                    output_lines.append(f"{state_output}={layout_output_line(valid_commands, normalized_event)}")
                        
                # PATH B: Global Event (e.g., Earthquake rumble sent to all connected guns).
                # Every player's commands combine into ONE list with ONE layout, so all guns
                # fire together on the event.
                elif target_player == "Global":
                    combined_commands = []
                    if hardware_commands:
                        for p_key, p_config in active_players.items():
                            hw_target = p_config["Hardware_Target"]
                            hw_profile = hardware_db.get(hw_target, {})
                            pref = p_config.get("Display_Preference", "None")
                            filtered_cmds = filter_display_preference(hardware_commands, pref)
                            interval = str(hw_profile.get("Commands", {}).get("Command_Interval_ms", "0") or "0")
                            prefix = build_transport_prefix(hw_profile, p_key)
                            allowed_led, allowed_display, led_list, display_list = compute_priority_winners(hw_profile, game_profile, p_key)

                            for cmd in filtered_cmds:
                                if cmd in led_list and cmd != allowed_led:
                                    continue
                                if cmd in display_list and cmd != allowed_display:
                                    continue
                                raw_payload = get_hardware_payload(hw_profile, hw_target, cmd, p_key)
                                if raw_payload:
                                    parsed_payload = inject_variables(raw_payload, p_config)
                                    if combined_commands and ENABLE_SAFETY_DELAYS and interval != "0":
                                        combined_commands.append(f"nll {interval}")
                                    combined_commands.extend(format_payloads_with_delay(parsed_payload, p_config['COM_Port'], interval, prefix))

                    output_lines.append(f"{state_output}={layout_output_line(combined_commands, normalized_event)}")
                
                # PATH C: Unassigned Player Target (e.g., Game maps P3, but user only owns 2 guns)
                else:
                    diagnostics.log_game_warning(game_name, "unassigned_players", target_player)
                    output_lines.append(f"{state_output}=")


            # ==========================================
            # 4. FILE GENERATION
            # ==========================================
            # Construct the final .ini file matching the standardised "MAME Hooker" schema
            ini_content = f"""[General]
MameStart={system_events_dict.get('MameStart', '')}
MameStop={system_events_dict.get('MameStop', '')}
StateChange={system_events_dict.get('StateChange', '')}
OnRotate={system_events_dict.get('OnRotate', '')}
OnPause={system_events_dict.get('OnPause', '')}

[KeyStates]
RefreshTime={refresh_time}

[Output]
{chr(10).join(output_lines)}
"""
            output_filepath = os.path.join(output_dir, f"{game_name}.ini")
            with open(output_filepath, "w", encoding="utf-8") as f:
                f.write(ini_content)

# Trigger final reporting
diagnostics.print_summary(active_players, settings)