#
# MAME STATE OUTPUT PROJECT (MSOP)
# MSOP HOOKER INI COMPILER  (compile: game json -> ini)
# Compiler Version: 0.8.1
# Compiler Date: 2026.07.08
# Project: https://github.com/djGLiTCH/MAME-LUA-SCRIPT-STATE-OUTPUTS
# License: GNU GENERAL PUBLIC LICENSE GPL-v3.0
# Copyright (c) 2026 Jacob Simpson (DJ GLiTCH). All Rights Reserved.
#
# Compiles the hand-maintained MSOP JSON game profiles from 'input/games/' into
# hardware-specific MAME Hooker '.ini' files in 'output/ini/'.
#
# This compiler acts as the bridge between universal game state events and
# specific hardware commands. It dynamically reads player hardware assignments
# from 'input/config/settings.json', matches them against the event definitions
# in 'input/config/stateevents.json', and extracts the correct hexadecimal
# payloads from the profiles in 'input/playerhardware/'.
#
# All paths are resolved relative to the project root (the parent of this
# 'scripts/' folder) via __file__, so this can be run from any working
# directory - e.g. straight from scripts/run.bat.
#
# Key Features:
#   [1] Dynamic Variable Injection: Replaces static tags in hardware profiles
#       with dynamic player settings.
#   [2] Hardware Protections: Injects buffer flushes ('nll') and sequential
#       delays to prevent serial lockups on slower hardware chips.
#   [3] Comprehensive Diagnostics: Tracks missing payloads, undefined events,
#       and unmapped outputs, generating a detailed summary upon completion.
#

import os
import sys
import json
import textwrap

# ==========================================
# PROJECT PATHS (root-anchored via __file__)
# ==========================================
# scripts/msop_hooker_ini_compiler.py -> parent of 'scripts/' is the project root.
BASE_DIR     = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONFIG_DIR   = os.path.join(BASE_DIR, "input", "config")     # settings + state-event defs
HARDWARE_DIR = os.path.join(BASE_DIR, "input", "playerhardware")   # per-device payload profiles
GAMES_DIR    = os.path.join(BASE_DIR, "input", "games")      # hand-maintained game profiles (json)
INI_DIR      = os.path.join(BASE_DIR, "output", "ini")       # our output (.ini)

# EMPTY TEMPLATE MODE - every game's .ini lists all of its outputs (and the system events) with
# empty values, ignoring all player/hardware assignments. This is the version that ships in the
# distribution zip so a user can hand-fill their own commands. A normal run compiles real payloads
# from settings.json + the hardware profiles as usual.
#
# Set GENERATE_EMPTY_TEMPLATE to True below to always run in this mode (no command needed), or leave
# it False and pass --empty on the command line for a one-off. Either turns it on.
GENERATE_EMPTY_TEMPLATE = False
EMPTY_TEMPLATE_MODE = GENERATE_EMPTY_TEMPLATE or "--empty" in sys.argv

# ==========================================
# 0. DIAGNOSTIC REPORTER SETUP
# ==========================================
class DiagnosticReporter:
    """
    Tracks and categorizes all anomalies during the compilation process.
    - Errors: Syntax crashes, missing necessary payloads, undefined events. (Drops Health %)
    - Warnings: Unassigned players, unexpected events.
    - Info: Explicitly unsupported hardware features, explicitly unmapped state outputs.
    """
    def __init__(self):
        self.critical_errors = []
        self.hardware_warnings = {}
        self.game_warnings = {}
        self.connection_warnings = []

    def init_hw(self, hw_name):
        if hw_name not in self.hardware_warnings:
            self.hardware_warnings[hw_name] = {
                "missing_global": False, 
                "missing_commands": set(), 
                "unsupported_commands": set(), 
                "total_requests": 0
            }

    def init_game(self, game_name):
        if game_name not in self.game_warnings:
            self.game_warnings[game_name] = {
                "unassigned_players": set(),  # Treated as WARNING (expected bypass)
                "unmapped_events": set(),     # Treated as WARNING (defined but unmapped)
                "invalid_events": set(),      # Treated as ERROR (typo or missing from definitions)
                "missing_system": set(),      # Treated as ERROR
                "info_mappings": set(),       # Treated as INFO (captured but intentionally false)
                "total_mappings": 0,
                "error_count": 0,
                "warning_count": 0,
                "info_count": 0
            }

    def log_game_error(self, game_name, category, message):
        self.init_game(game_name)
        self.game_warnings[game_name][category].add(message)
        self.game_warnings[game_name]["error_count"] += 1

    def log_game_warning(self, game_name, category, message):
        self.init_game(game_name)
        self.game_warnings[game_name][category].add(message)
        self.game_warnings[game_name]["warning_count"] += 1

    def log_game_info(self, game_name, category, message):
        self.init_game(game_name)
        self.game_warnings[game_name][category].add(message)
        self.game_warnings[game_name]["info_count"] += 1

    def print_summary(self, active_players, settings):
        """Prints the final formatted console report categorizing all tracked data."""
        print("\n" + "=" * 70)
        print(" COMPILATION DIAGNOSTIC & SUMMARY".center(70))
        print("=" * 70)

        # --- 1. Configuration Summary ---
        print("\n[SETTINGS / CONFIGURATION]")
        print(f"  + Total Players Assigned: {len(active_players)}")
        for p_key, p_data in sorted(active_players.items()):
            hw = p_data.get('Hardware_Target', 'None')
            port = p_data.get('COM_Port', 'None')
            baud = p_data.get('Baud_Rate', 'None')
            print(f"      {p_key}: Hardware={hw} | COM={port} | Baud={baud}")
        
        prefs = settings.get("Engine_Preferences", {})
        refresh = prefs.get("Refresh_Time_MS", "33")
        if not refresh:
            refresh_display = "0 ms (maximum cycle refresh)"
        else:
            refresh_display = f"{refresh}ms"
        print(f"  + Engine Refresh Time: {refresh_display}")

        if self.critical_errors:
            print("\n[CRITICAL ERRORS] - Files Skipped")
            for err in self.critical_errors:
                print(f"  X {err}")

        if self.connection_warnings:
            print("\n[CONNECTION ERRORS] - Settings.json")
            for warn in self.connection_warnings:
                print(f"  ! {warn}")

        # Track Success Rates and Specific Files
        hw_success_files = []
        hw_info_files = []
        hw_error_files = []
        
        game_success_files = []
        game_warn_files = []
        game_error_files = []

        # --- 2. Hardware Profiles Report ---
        print("\n[HARDWARE PROFILES]")
        for hw, data in sorted(self.hardware_warnings.items()):
            err_count = 0
            messages = []
            
            if data["missing_global"]:
                err_count += 1
                messages.append("      [ERROR] Missing Master [Global] block.")
            
            missing_cmds = len(data["missing_commands"])
            unsupported_cmds = len(data["unsupported_commands"])
            
            if missing_cmds > 0:
                err_count += missing_cmds
                if missing_cmds == data["total_requests"] and data["total_requests"] > 0:
                    messages.append("      [FATAL] No valid state event command references found (Profile appears completely empty).")
                else:
                    messages.append(f"      [ERROR] Missing payloads for {missing_cmds} requested command(s):")
                    for cmd in sorted(data['missing_commands']):
                        messages.append(f"          - {cmd}")
                    
            if unsupported_cmds > 0:
                messages.append(f"      [INFO] Hardware explicitly lacks support for {unsupported_cmds} command(s):")
                for cmd in sorted(data['unsupported_commands']):
                    messages.append(f"          - {cmd}")
            
            # Tally logic for Final Summary Tracking
            hw_filename = hw
            if err_count > 0:
                hw_error_files.append(hw_filename)
            elif unsupported_cmds > 0:
                hw_info_files.append(hw_filename)
            else:
                hw_success_files.append(hw_filename)

            if err_count == 0 and unsupported_cmds == 0:
                print(f"  + {hw}.json: 100% Healthy (0 Errors)")
            elif err_count == 0:
                print(f"  ~ {hw}.json: 100% Healthy (0 Errors, {unsupported_cmds} Info)")
                for msg in messages:
                    print(msg)
            else:
                pct = max(0, 100 - int((err_count / max(1, data["total_requests"])) * 100))
                print(f"  - {hw}.json: {pct}% Health ({err_count} Errors)")
                for msg in messages:
                    print(msg)

        # --- 3. Game Profiles Report ---
        print("\n[GAME PROFILES]")
        for game, data in sorted(self.game_warnings.items()):
            total = data["total_mappings"]
            err_count = data["error_count"]
            warn_count = data["warning_count"]
            info_count = data["info_count"]
            
            # Tally logic for Final Summary Tracking
            game_filename = game
            if err_count > 0:
                game_error_files.append(game_filename)
            elif warn_count > 0:
                game_warn_files.append(game_filename)
            else:
                game_success_files.append(game_filename)
            
            pct = max(0, 100 - int((err_count / max(1, total)) * 100))
            
            if len(data["invalid_events"]) == total and total > 0:
                print(f"  - {game}.json: 0% Health ({err_count} Errors) - FATAL: No valid state event references found.")
            elif err_count == 0 and warn_count == 0:
                info_str = f", {info_count} Info" if info_count > 0 else ""
                print(f"  + {game}.json: 100% Mapped (0 Errors{info_str})")
            elif err_count == 0:
                info_str = f", {info_count} Info" if info_count > 0 else ""
                print(f"  ~ {game}.json: 100% Mapped (0 Errors, {warn_count} Warnings{info_str})")
            else:
                warn_str = f", {warn_count} Warnings" if warn_count > 0 else ""
                info_str = f", {info_count} Info" if info_count > 0 else ""
                print(f"  - {game}.json: {pct}% Health ({err_count} Errors{warn_str}{info_str})")
                
            if data["invalid_events"]:
                print(f"      [ERROR] Invalid State Events (Unknown event not in definitions):")
                for evt in sorted(data['invalid_events']):
                    print(f"          - {evt}")
            if data["missing_system"]:
                print(f"      [ERROR] Missing System Payloads:")
                for evt in sorted(data['missing_system']):
                    print(f"          - {evt}")
            if data["unmapped_events"]:
                print(f"      [WARNING] Defined but Unmapped State Events:")
                for evt in sorted(data['unmapped_events']):
                    print(f"          - {evt}")
            if data["unassigned_players"]:
                print(f"      [WARNING] Expected Missing Assignments (Players bypassed):")
                for evt in sorted(data['unassigned_players']):
                    print(f"          - {evt}")
            if data.get("info_mappings"):
                print(f"      [INFO] Explicitly Unmapped State Outputs:")
                for evt in sorted(data['info_mappings']):
                    print(f"          - {evt}")

        # --- 4. Final Compilation Summary ---
        total_hw = len(self.hardware_warnings)
        total_games = len(self.game_warnings)
        
        hw_succ_rate = (len(hw_success_files) / max(1, total_hw)) * 100 if total_hw > 0 else 0
        hw_info_rate = (len(hw_info_files) / max(1, total_hw)) * 100 if total_hw > 0 else 0
        hw_err_rate  = (len(hw_error_files) / max(1, total_hw)) * 100 if total_hw > 0 else 0
        
        game_succ_rate = (len(game_success_files) / max(1, total_games)) * 100 if total_games > 0 else 0
        game_warn_rate = (len(game_warn_files) / max(1, total_games)) * 100 if total_games > 0 else 0
        game_err_rate  = (len(game_error_files) / max(1, total_games)) * 100 if total_games > 0 else 0

        # Helper function to print vertical lists
        def print_file_list(file_list):
            if not file_list: return
            for file in sorted(file_list):
                print(f"          - {file}")

        print("\n" + "=" * 70)
        print(" FINAL COMPILATION SUMMARY")
        print("-" * 70)
        print(f"  - Hardware Profiles Processed: {total_hw}")
        print(f"     * Success Rate (Valid): {hw_succ_rate:.1f}% ({len(hw_success_files)}/{total_hw} files)")
        print_file_list(hw_success_files)
        print(f"     * Info Rate (Expected): {hw_info_rate:.1f}% ({len(hw_info_files)}/{total_hw} files)")
        print_file_list(hw_info_files)
        print(f"     * Error Rate (Failed):  {hw_err_rate:.1f}% ({len(hw_error_files)}/{total_hw} files)")
        print_file_list(hw_error_files)
        
        print(f"\n  - Game Profiles Converted:     {total_games}")
        print(f"     * Success Rate (Valid/Mapped):   {game_succ_rate:.1f}% ({len(game_success_files)}/{total_games} files)")
        print_file_list(game_success_files)
        print(f"     * Warning Rate (Invalid/Unmapped): {game_warn_rate:.1f}% ({len(game_warn_files)}/{total_games} files)")
        print_file_list(game_warn_files)
        print(f"     * Error Rate (Compilation Errors): {game_err_rate:.1f}% ({len(game_error_files)}/{total_games} files)")
        print_file_list(game_error_files)
        print("=" * 70 + "\n")

diagnostics = DiagnosticReporter()

# ==========================================
# 1. INITIALIZATION & DATA LOADING
# ==========================================
COMPILER_VERSION = "0.8.2"
COMPILER_DATE = "2026.07.08"

print("-" * 70)
print("MAME STATE OUTPUT PROJECT (MSOP)".center(70))
print("MSOP HOOKER INI COMPILER".center(70))
print("-" * 70)
print(f" Compiler Version: {COMPILER_VERSION}")
print(f" Compiler Date: {COMPILER_DATE}\n")
print(" Project: https://github.com/djGLiTCH/MAME-LUA-SCRIPT-STATE-OUTPUTS")
print(" License: GNU GENERAL PUBLIC LICENSE GPL-v3.0")
print(" Copyright (c) 2026 Jacob Simpson (DJ GLiTCH). All Rights Reserved.")
print("-" * 70)
print("\n[STARTING] Compiling MSOP game JSON profiles to MAME Hooker INIs...\n")

# Load core configuration files
with open(os.path.join(CONFIG_DIR, "settings.json"), "r") as f:
    settings = json.load(f)

with open(os.path.join(CONFIG_DIR, "stateevents.json"), "r") as f:
    universal_bridge = json.load(f)

# Extract mapping dictionaries from the bridge
state_to_cmd = universal_bridge.get("State_Event_To_Command", {})
sys_to_cmd = universal_bridge.get("System_Event_To_Command", {})
state_defs = universal_bridge.get("State_Event_Definitions", {})

active_players = {}
hardware_db = {}

# Build the active hardware database based ONLY on players defined in settings.json
for p_key, p_config in settings.get("Player_Assignments", {}).items():
    hw_target = p_config.get("Hardware_Target")
    if hw_target:
        # Validate that connection variables exist to prevent broken COM strings
        if not p_config.get("COM_Port") or not p_config.get("Baud_Rate"):
            diagnostics.connection_warnings.append(f"Player '{p_key}' is missing COM_Port or Baud_Rate.")
            
        active_players[p_key] = p_config
        
        # Load the hardware JSON into memory if it hasn't been cached yet
        if hw_target not in hardware_db:
            hw_path = os.path.join(HARDWARE_DIR, f"{hw_target}.json")
            if os.path.exists(hw_path):
                try:
                    with open(hw_path, "r") as f:
                        hw_data = json.load(f)
                        hardware_db[hw_target] = hw_data
                        diagnostics.init_hw(hw_target)

                        # Verify the crucial Global fallback block exists
                        if "Global" not in hw_data:
                            diagnostics.hardware_warnings[hw_target]["missing_global"] = True
                except json.JSONDecodeError:
                    diagnostics.critical_errors.append(f"Malformed JSON syntax in input/hardware/{hw_target}.json")
            else:
                diagnostics.critical_errors.append(f"Hardware profile '{hw_target}.json' not found.")


# Empty-template mode: drop every player/hardware assignment so all outputs compile to empty
# values, while still emitting one line per output (and the system-event headers) for every game.
if EMPTY_TEMPLATE_MODE:
    print("[EMPTY TEMPLATE MODE] Ignoring player/hardware assignments - emitting empty commands.\n")
    active_players = {}
    hardware_db = {}


# ==========================================
# 2. COMPILER LOGIC FUNCTIONS
# ==========================================

# Master toggle for injecting safety delays (nll ms) between sequential commands.
# Crucial for preventing serial lockup on slower hardware chips.
ENABLE_SAFETY_DELAYS = False

# Master toggle for generating all mapped events in the output INI files in alphabetical order (A-Z).
SORT_INI_OUTPUTS = True


def inject_variables(raw_payload, player_config):
    """Replaces static placeholder tags in hardware profiles with dynamic player settings."""
    if not raw_payload: return ""
    cmd = raw_payload.replace("<SOLENOID_DELAY_MS>", str(player_config.get("Solenoid_Delay_MS", "")))
    return cmd

def filter_display_preference(command_array, display_pref):
    """
    Filters out any display commands (e.g., LED screens) that do not match 
    the player's specific Display_Preference defined in settings.json.
    """
    filtered = []
    target_display_cmd = f"Display_{display_pref}"
    for cmd in command_array:
        if cmd.startswith("Display_"):
            if cmd == target_display_cmd:
                filtered.append(cmd)
        else:
            filtered.append(cmd)
    return filtered

def get_hardware_payload(hw_profile, hw_name, cmd, player_key):
    """
    Safely retrieves the hardware hex/text payload using a fallback hierarchy:
    1. Player-Specific (e.g., P1 override)
    2. Master [Global] fallback
    3. Root level (legacy)
    
    If the payload is explicitly set to 'false' (boolean or string), it is logged 
    as an intentionally unsupported feature, preventing false-positive errors.
    """
    diagnostics.hardware_warnings[hw_name]["total_requests"] += 1
    
    payload = None
    if player_key in hw_profile and cmd in hw_profile[player_key]:
        payload = hw_profile[player_key][cmd]
    elif "Global" in hw_profile and cmd in hw_profile["Global"]:
        payload = hw_profile["Global"][cmd]
    elif cmd in hw_profile:
        payload = hw_profile[cmd]
        
    # Flag as intentionally unsupported (Info)
    if payload is False or str(payload).strip().lower() == "false":
        diagnostics.hardware_warnings[hw_name]["unsupported_commands"].add(cmd)
        return ""
        
    # Flag as accidentally missing (Error)
    if not payload:
        diagnostics.hardware_warnings[hw_name]["missing_commands"].add(cmd)
        return ""
        
    return str(payload)

def format_payloads_with_delay(raw_payload, port, interval_ms):
    """
    Formats the raw payload into a safe serial transmission string using the pipe delimiter (|).
    
    CRITICAL HARDWARE PROTECTIONS:
    1. Null Flush ('nll'): Prepending an empty nll command flushes dirty data from 
       the Windows serial buffer, ensuring the first byte of the actual payload is never dropped.
       (Without this, guns often drop external commands and fall back to physical auto-recoil).
    2. Interval Delays ('nll MS'): Injects a pause between rapid sequential commands 
       so the hardware chip has time to process before the next byte arrives.
    """
    if not raw_payload: return []
    commands = [cmd.strip() for cmd in raw_payload.split(",")]
    formatted_lines = []
    
    # Inject the software handshake / buffer flush
    formatted_lines.append("nll")
    
    for i, cmd in enumerate(commands):
        formatted_lines.append(f"cmw {port} {cmd}")
        
        # Inject the hardware breathing interval
        if ENABLE_SAFETY_DELAYS and interval_ms != "0" and i < len(commands) - 1:
            formatted_lines.append(f"nll {interval_ms}")
            
    return formatted_lines

def compile_system_events(game_profile, game_name):
    """
    Compiles the universal MameStart and MameStop headers, which handle 
    opening COM ports, setting baud rates, establishing external communication 
    mode, and setting the game's specific Aspect Ratio.
    """
    system_outputs = {}
    game_aspect_ratio = game_profile.get("System_AspectRatio")
    
    for sys_event, cmd_list in sys_to_cmd.items():
        compiled_lines = []
        for p_key, p_config in active_players.items():
            hw_target = p_config["Hardware_Target"]
            if hw_target not in hardware_db: continue
            hw_profile = hardware_db[hw_target]
            port = p_config["COM_Port"]
            interval = hw_profile.get("Global", {}).get("Command_Interval_MS", "0")
            
            for cmd_name in cmd_list:
                if cmd_name == "Open_COM":
                    cmo_str = f"cmo {port} baud={p_config['Baud_Rate']}_parity=N_data=8_stop=1"
                    compiled_lines.append(cmo_str)
                    
                    # Hardcoded Boot Delay: Gives the COM port serial chip time to wake up 
                    # before blasting the External Mode initialization command.
                    if ENABLE_SAFETY_DELAYS and interval != "0":
                        compiled_lines.append("nll 1500")
                    
                    raw_payload = get_hardware_payload(hw_profile, hw_target, "COM_Open", p_key)
                    if not raw_payload:
                        raw_payload = get_hardware_payload(hw_profile, hw_target, "Open_COM", p_key)
                        
                    # Inject the game's Aspect Ratio hex code directly into the boot sequence
                    if sys_event == "MameStart" and game_aspect_ratio:
                        aspect_payload = get_hardware_payload(hw_profile, hw_target, game_aspect_ratio, p_key)
                        if aspect_payload:
                            if raw_payload:
                                raw_payload += f", {aspect_payload}"
                            else:
                                raw_payload = aspect_payload
                        else:
                            diagnostics.log_game_error(game_name, "missing_system", f"Requested {game_aspect_ratio} but hardware {hw_target} has no payload mapped.")
                                
                    if raw_payload:
                        safe_commands = format_payloads_with_delay(raw_payload, port, interval)
                        compiled_lines.extend(safe_commands)
                        
                elif cmd_name == "Close_COM":
                    raw_payload = get_hardware_payload(hw_profile, hw_target, "COM_Close", p_key)
                    if not raw_payload:
                        raw_payload = get_hardware_payload(hw_profile, hw_target, "Close_COM", p_key)
                        
                    if raw_payload:
                        safe_commands = format_payloads_with_delay(raw_payload, port, interval)
                        compiled_lines.extend(safe_commands)
                        
                    # Flush Delay: Ensures the final disconnect command fully transmits 
                    # before the Windows COM buffer is aggressively killed by cmc.
                    if ENABLE_SAFETY_DELAYS and interval != "0":
                        compiled_lines.append(f"nll {interval}")
                        
                    compiled_lines.append(f"cmc {port}")
                else:
                    raw_payload = get_hardware_payload(hw_profile, hw_target, cmd_name, p_key)
                    if raw_payload:
                        safe_commands = format_payloads_with_delay(raw_payload, port, interval)
                        compiled_lines.extend(safe_commands)
                        
        if compiled_lines:
            system_outputs[sys_event] = " | ".join(compiled_lines)
        else:
            system_outputs[sys_event] = ""
            
    return system_outputs


# ==========================================
# 3. GAME PROCESSING & RECURSIVE FOLDER MIRRORING
# ==========================================
refresh_time = settings.get("Engine_Preferences", {}).get("Refresh_Time_MS", "33")

# Recursively crawl 'input/games'. This perfectly duplicates any sub-folders
# (like input/games/MAME_Standard or input/games/DemulShooter) into 'output/ini'.
for root, _, files in os.walk(GAMES_DIR):
    for filename in files:
        if filename.endswith(".json"):
            game_name = filename.replace(".json", "")
            input_filepath = os.path.join(root, filename)
            rel_path = os.path.relpath(root, GAMES_DIR)

            output_dir = os.path.join(INI_DIR, rel_path)
            os.makedirs(output_dir, exist_ok=True)

            try:
                with open(input_filepath, "r", encoding="utf-8") as f:
                    game_profile = json.load(f)
            except json.JSONDecodeError:
                diagnostics.critical_errors.append(f"Malformed JSON syntax in input/games/{rel_path}/{filename}. Skipping.")
                continue
                
            diagnostics.init_game(game_name)
            system_events_dict = compile_system_events(game_profile, game_name)
            output_lines = []
            
            # Process every mapped event inside the game's JSON profile
            # Added a toggle to ensure all ini state hooks are generated alphabetically A-Z if enabled
            mapping_items = sorted(game_profile.items()) if SORT_INI_OUTPUTS else game_profile.items()
            for state_output, event_mapping in mapping_items:
                if state_output.startswith("System_"):
                    continue

                diagnostics.game_warnings[game_name]["total_mappings"] += 1
                
                # GRACEFUL BYPASS: Intentionally false mappings captured by json_compiler
                if event_mapping.lower() == "false":
                    diagnostics.log_game_info(game_name, "info_mappings", state_output)
                    output_lines.append(f"{state_output}=")
                    continue
                
                # Determine which player is the target (P1, P2, etc.) or if it's Global
                target_player = event_mapping.split("_")[0] if "_" in event_mapping else "Global"
                
                # Normalize tags (e.g., convert P1_Recoil to the bridge's universal PX_Recoil)
                normalized_event = event_mapping
                if normalized_event.startswith(("P1_", "P2_", "P3_", "P4_")):
                    normalized_event = "PX_" + normalized_event[3:]
                    
                # VALIDATION: Check if the mapped event is legally defined in the bridge
                if normalized_event not in state_to_cmd and not normalized_event.startswith("Global_"):
                    if normalized_event in state_defs:
                        # Event exists in definitions, but hasn't been mapped to hex commands yet -> WARNING
                        diagnostics.log_game_warning(game_name, "unmapped_events", event_mapping)
                    else:
                        # Event doesn't exist anywhere in the bridge (likely a typo) -> ERROR
                        diagnostics.log_game_error(game_name, "invalid_events", event_mapping)
                
                hardware_commands = state_to_cmd.get(normalized_event, [])
                
                # PATH A: Player-Specific Event (e.g., P1 fires a shot)
                if target_player in active_players:
                    p_config = active_players[target_player]
                    hw_target = p_config["Hardware_Target"]
                    hw_profile = hardware_db.get(hw_target, {})
                    
                    pref = p_config.get("Display_Preference", "None")
                    filtered_cmds = filter_display_preference(hardware_commands, pref)
                    interval = hw_profile.get("Global", {}).get("Command_Interval_MS", "0")
                    
                    valid_commands = []
                    for cmd in filtered_cmds:
                        raw_payload = get_hardware_payload(hw_profile, hw_target, cmd, target_player)
                        if raw_payload:
                            parsed_payload = inject_variables(raw_payload, p_config)
                            safe_commands = format_payloads_with_delay(parsed_payload, p_config['COM_Port'], interval)
                            valid_commands.extend(safe_commands)
                            
                    # Stitch final valid commands with pipe delimiter and safety delays
                    if valid_commands:
                        if ENABLE_SAFETY_DELAYS and interval != "0":
                            final_payload_string = f" | nll {interval} | ".join(valid_commands)
                        else:
                            final_payload_string = " | ".join(valid_commands)
                            
                        output_lines.append(f"{state_output}={final_payload_string}")
                    else:
                        # Maintain empty key to prevent OutputHooker parser crashes
                        output_lines.append(f"{state_output}=")
                        
                # PATH B: Global Event (e.g., Earthquake rumble sent to all connected guns)
                elif target_player == "Global":
                    if hardware_commands:
                        global_payloads = []
                        # Loop through every active player and gather their specific hardware hex codes
                        for p_key, p_config in active_players.items():
                            hw_target = p_config["Hardware_Target"]
                            hw_profile = hardware_db.get(hw_target, {})
                            pref = p_config.get("Display_Preference", "None")
                            filtered_cmds = filter_display_preference(hardware_commands, pref)
                            interval = hw_profile.get("Global", {}).get("Command_Interval_MS", "0")
                            
                            player_valid_commands = []
                            for cmd in filtered_cmds:
                                raw_payload = get_hardware_payload(hw_profile, hw_target, cmd, p_key)
                                if raw_payload:
                                    parsed_payload = inject_variables(raw_payload, p_config)
                                    safe_commands = format_payloads_with_delay(parsed_payload, p_config['COM_Port'], interval)
                                    player_valid_commands.extend(safe_commands)
                                    
                            if player_valid_commands:
                                if ENABLE_SAFETY_DELAYS and interval != "0":
                                    global_payloads.append(f" | nll {interval} | ".join(player_valid_commands))
                                else:
                                    global_payloads.append(" | ".join(player_valid_commands))
                                    
                        if global_payloads:
                            output_lines.append(f"{state_output}={' | '.join(global_payloads)}")
                        else:
                            output_lines.append(f"{state_output}=")
                    else:
                        output_lines.append(f"{state_output}=")
                
                # PATH C: Unassigned Player Target (e.g., Game maps P3, but user only owns 2 guns)
                else:
                    diagnostics.log_game_warning(game_name, "unassigned_players", target_player)
                    output_lines.append(f"{state_output}=")


            # ==========================================
            # 4. FILE GENERATION
            # ==========================================
            # Construct the final .ini file matching the standardised "MAME Hooker" schema
            ini_content = f"""[General]
MameStart={system_events_dict.get('MameStart', '')}
MameStop={system_events_dict.get('MameStop', '')}
StateChange={system_events_dict.get('StateChange', '')}
OnRotate={system_events_dict.get('OnRotate', '')}
OnPause={system_events_dict.get('OnPause', '')}

[KeyStates]
RefreshTime={refresh_time}

[Output]
{chr(10).join(output_lines)}
"""
            output_filepath = os.path.join(output_dir, f"{game_name}.ini")
            with open(output_filepath, "w", encoding="utf-8") as f:
                f.write(ini_content)

# Trigger final reporting
diagnostics.print_summary(active_players, settings)