#!/usr/bin/env bash
# MSOP INI to JSON Colours Compiler - launcher (Linux/macOS)
# Paths are resolved from this script's own location, so it works regardless
# of the current working directory.
set -e

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PY="$(command -v python3 || command -v python)"

echo "=== Converting INI to JSON ==="
"$PY" "$DIR/msop_ini_to_json_colour_compiler.py"

echo
echo "Done."
