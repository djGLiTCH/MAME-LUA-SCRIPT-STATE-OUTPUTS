#
# MAME STATE OUTPUT PROJECT (MSOP)
# MSOP INI TO JSON COLOUR COMPILER
# Compiler Version: 1.0.1
# Compiler Date: 2026.07.10
# Project: https://github.com/djGLiTCH/MAME-LUA-SCRIPT-STATE-OUTPUTS
# License: GNU GENERAL PUBLIC LICENSE GPL-v3.0
# Copyright (c) 2026 Jacob Simpson (DJ GLiTCH). All Rights Reserved.
#

import json
import os
from datetime import datetime

# ==========================================
# PROJECT PATHS (root-anchored via __file__)
# ==========================================
BASE_DIR   = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
INPUT_DIR  = os.path.join(BASE_DIR, "input", "colours")
OUTPUT_DIR = os.path.join(BASE_DIR, "output", "colours")

# ==========================================
# JSON CONVERTER SCRIPT
# ==========================================

def parse_config_to_dict(filepath):
    """Parses the bracketed configuration format into a Python dictionary."""
    parsed_data = {}
    current_section = None
    
    with open(filepath, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            
            # Skip empty lines and comments
            if not line or line.startswith('#') or line.startswith(';'):
                continue
            
            # Match section headers (e.g., [1942])
            if line.startswith('[') and line.endswith(']'):
                current_section = line[1:-1]
                parsed_data[current_section] = {}
            # Match key=value pairs (e.g., P1_COIN=White)
            elif '=' in line and current_section is not None:
                key, value = line.split('=', 1)
                parsed_data[current_section][key.strip()] = value.strip()
                
    return parsed_data

def print_summary(stats, export_status):
    """Prints the end-of-run console report."""
    print("\n" + "=" * 70)
    print(" CONVERSION SUMMARY")
    print("=" * 70)
    
    if stats["files"] > 0 or stats["errors"] > 0:
        print(f" Total Files Converted    : {stats['files']}")
        print(f" Files with Errors        : {stats['errors']}")
        print(f" Total Games Extracted    : {stats['sections']}")
        print(f" Total Mappings Extracted : {stats['mappings']}")
    else:
        print(" No valid files found to process.")

    print("-" * 70)
    print(f" Database JSON Export     : {export_status}")
    print("=" * 70 + "\n")

def main():
    COMPILER_VERSION = "1.0.1"
    COMPILER_DATE = datetime.now().strftime("%Y.%m.%d")
    
    # ---------------------------------------------------------
    # Custom MSOP Header 
    # ---------------------------------------------------------
    print("-" * 70)
    print("MAME STATE OUTPUT PROJECT (MSOP)".center(70))
    print("MSOP INI TO JSON COLOUR CONVERTER".center(70))
    print("-" * 70)
    print(f" Script Version: {COMPILER_VERSION}")
    print(f" Script Date: {COMPILER_DATE}\n")
    print(" Project: https://github.com/djGLiTCH/MAME-LUA-SCRIPT-STATE-OUTPUTS")
    print(" License: GNU GENERAL PUBLIC LICENSE GPL-v3.0")
    print(" Copyright (c) 2026 Jacob Simpson (DJ GLiTCH). All Rights Reserved.")
    print("-" * 70)
    
    print(f"\n[INFO] Scanning '{INPUT_DIR}' for files to convert...\n")
    
    stats = {"files": 0, "sections": 0, "mappings": 0, "errors": 0}
    export_status = "Skipped"
    
    if not os.path.exists(INPUT_DIR):
        print(f"[CRITICAL] Could not find '{INPUT_DIR}'.")
        export_status = "Failed (Input directory missing)"
    else:
        # Ensure output directory exists before processing
        os.makedirs(OUTPUT_DIR, exist_ok=True)
        
        # Get all files in the input directory
        files_found = [f for f in os.listdir(INPUT_DIR) if os.path.isfile(os.path.join(INPUT_DIR, f))]
        
        if not files_found:
            print(" [INFO] No files found in the input directory.")
            export_status = "Skipped (No files)"
        else:
            for filename in files_found:
                input_filepath = os.path.join(INPUT_DIR, filename)
                
                # Create corresponding .json filename
                base_name, _ = os.path.splitext(filename)
                output_filename = base_name + ".json"
                output_filepath = os.path.join(OUTPUT_DIR, output_filename)
                
                try:
                    # Parse the text file
                    master_db = parse_config_to_dict(input_filepath)
                    
                    sec_count = len(master_db)
                    map_count = sum(len(v) for v in master_db.values())
                    
                    stats["sections"] += sec_count
                    stats["mappings"] += map_count
                    
                    # Write to pretty-print JSON
                    with open(output_filepath, 'w', encoding='utf-8') as f:
                        json.dump(master_db, f, indent=4)
                        
                    print(f" [SUCCESS] {filename} -> {output_filename} ({sec_count} games, {map_count} mappings)")
                    stats["files"] += 1
                    
                except Exception as e:
                    print(f" [ERROR]   Failed on {filename} -> {e}")
                    stats["errors"] += 1
            
            # Determine overall export status based on results
            if stats["files"] > 0 and stats["errors"] == 0:
                export_status = "Success"
            elif stats["files"] > 0 and stats["errors"] > 0:
                export_status = "Partial Success"
            else:
                export_status = "Failed (Errors on all files)"

    print_summary(stats, export_status)

if __name__ == "__main__":
    main()