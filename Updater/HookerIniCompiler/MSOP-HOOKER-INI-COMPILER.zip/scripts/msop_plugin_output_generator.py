#
# MAME STATE OUTPUT PROJECT (MSOP)
# MSOP PLUGIN OUTPUT GENERATOR  (Database game config -> MAME_MSOP_Plugin hooker JSON)
# Compiler Version: 1.1.0
# Compiler Date: 2026.07.08
# Project: https://github.com/djGLiTCH/MAME-LUA-SCRIPT-STATE-OUTPUTS
# License: GNU GENERAL PUBLIC LICENSE GPL-v3.0
# Copyright (c) 2026 Jacob Simpson (DJ GLiTCH). All Rights Reserved.
#
# The MSOP-plugin games under input/games/MAME_MSOP_Plugin/ describe exactly which MSOP_ state
# outputs each game emits. That set is fully determined by the game's config in the Database
# Compiler, so this script derives those hooker JSONs authoritatively from it - replacing the old
# HOTR .txt ingestion path. The derivation mirrors init.lua's own output logic (Option A: the
# COMPLETE set the plugin can emit for a given config) and also folds in the native MAME driver
# outputs the plugin forwards verbatim (database_driver.lua + a game's ADDITIONAL_OUTPUT_FORWARDS),
# so each game JSON is all-inclusive of everything exposed for that ROM.
#
# Paths are root-anchored via __file__; the Database Compiler is read from the sibling folder.
#

import os
import re
import sys
import json

BASE_DIR    = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))       # Hooker INI Compiler/
DB_ROOT     = os.path.join(BASE_DIR, "..", "Database Compiler")
DB_GAMES    = os.path.join(DB_ROOT, "input", "database", "games")
DRIVER_LUA  = os.path.join(DB_ROOT, "output", "stateoutput", "database_driver.lua")
OUT_DIR     = os.path.join(BASE_DIR, "input", "games", "MAME_MSOP_Plugin")

# --- value mapping: an output maps to a real Hooker event only if that event exists in
# state_output_events.json; everything else is present-but-unmapped ("false"). Identity except LampStart. ---
SUFFIX_EVENT = {
    "Ammo": "Ammo", "Life": "Life", "Recoil": "Recoil", "Reload": "Reload",
    "Damage": "Damage", "Rumble": "Rumble", "LampStart": "LED_Start",
}


def load_driver_natives():
    """Parse database_driver.lua into {rom: [native_output_name, ...]}. These are the raw MAME
    driver outputs the plugin forwards verbatim (init.lua's Forward_Native_Outputs -> msop_out with
    the native name, no MSOP_ prefix). Optional: returns {} if the file isn't present (e.g. driver
    was never compiled because no MAME source path was set)."""
    if not os.path.exists(DRIVER_LUA):
        return {}
    txt = open(DRIVER_LUA, encoding="utf-8").read()
    natives = {}
    for m in re.finditer(r'\["([^"]+)"\]\s*=\s*\{(.*?)\}', txt, re.S):
        natives[m.group(1)] = re.findall(r'"([^"]+)"', m.group(2))
    return natives


def truthy(v):
    """A resolved config field is 'active' (drives an output) when it's a real address or a kept
    'auto' - i.e. anything that isn't false/None/empty."""
    if v is None or v is False:
        return False
    if isinstance(v, str) and v.strip().lower() in ("", "false"):
        return False
    return True


def resolve_players(game, default):
    """Replicate init.lua's config resolution and return, per player index, the set of ACTIVE
    (output-driving) config fields. P1 inherits _default (mostly false, RECOIL/RELOAD/DAMAGE/shots
    = auto), the auto hardware is disabled unless its source exists, and P2..MAX_PLAYERS resolve
    their _default 'auto' against P1 via PLAYER_MEMORY_OFFSET (so they mirror P1's active fields)."""
    def merged(pkey):
        m = dict(default.get(pkey, {}))
        m.update(game.get(pkey, {}))
        # normalise LAMP_START -> LAMPSTART (init.lua does the same)
        if "LAMP_START" in m and "LAMPSTART" not in m:
            m["LAMPSTART"] = m.pop("LAMP_START")
        return m

    max_players = game.get("MAX_PLAYERS", default.get("MAX_PLAYERS", 2))
    p1 = merged("P1")

    # P1 hardware auto-disable: an 'auto' derived trigger only survives if its source field exists.
    has_ammo = truthy(p1.get("AMMO")) or truthy(p1.get("AMMO_ALT")) or truthy(p1.get("AMMO_GRENADE"))
    has_life = truthy(p1.get("LIFE")) or truthy(p1.get("LIFE_ALT"))
    for key in ("RECOIL", "RELOAD", "DAMAGE", "RUMBLE", "LAMPSTART"):
        if p1.get(key) == "auto":
            if key in ("RECOIL", "RELOAD") and has_ammo:      pass
            elif key == "DAMAGE" and has_life:                pass
            elif key == "LAMPSTART":                          pass  # kept (rare)
            else:                                             p1[key] = False

    active = {1: {k for k, v in p1.items() if truthy(v)}}

    # P2..MAX_PLAYERS: their _default 'auto' resolves from P1; game may override with real/false.
    for i in range(2, int(max_players) + 1):
        pi = merged("P" + str(i))
        act = set()
        for k, v in pi.items():
            if v == "auto":
                if k in active[1]:            # inherits P1 (offset-linked) -> active
                    act.add(k)
            elif truthy(v):                   # explicit real value on this player
                act.add(k)
        active[i] = act
    return active, int(max_players)


def build_outputs(game, default, natives=None):
    active, max_players = resolve_players(game, default)
    flag = lambda k: bool(game.get(k, default.get(k, True)))
    demul = flag("DEMULSHOOTER_COMPATIBILITY")
    out = {}

    def put(name, value):
        out[name] = value

    def event_value(suffix, p):
        ev = SUFFIX_EVENT.get(suffix)
        return "P{}_{}".format(p, ev) if ev else "false"

    for i in range(1, max_players + 1):
        a = active[i]
        # per-player outputs gated by their driving config field(s)
        gates = {
            "Ammo": "AMMO" in a, "AmmoAlt": "AMMO_ALT" in a, "AmmoGrenade": "AMMO_GRENADE" in a,
            "Life": "LIFE" in a, "LifeAlt": "LIFE_ALT" in a,
            "Status": "STATUS" in a, "StatusAlt": "STATUS_ALT" in a,
            "Recoil": "RECOIL" in a, "Reload": "RELOAD" in a, "Damage": "DAMAGE" in a,
            "Rumble": "RUMBLE" in a, "LampStart": "LAMPSTART" in a,
            "ShotsFiredPrimary": ("AMMO" in a) and flag("ENABLE_SHOT_COUNT"),
            "ShotsFiredAlt":     ("AMMO_ALT" in a) and flag("ENABLE_SHOT_COUNT"),
            "ShotsFiredGrenade": ("AMMO_GRENADE" in a) and flag("ENABLE_SHOT_COUNT"),
            "LifeLost":   (("LIFE" in a) or ("LIFE_ALT" in a)) and flag("ENABLE_LIFE_LOST"),
            "DamageTaken": (("LIFE" in a) or ("LIFE_ALT" in a) or ("DAMAGE" in a)) and flag("ENABLE_DAMAGE_COUNT"),
            "CreditsInserted": ("CREDITS" in a) and flag("ENABLE_CREDIT_COUNT"),
            "CreditsConsumed": ("CREDITS" in a) and flag("ENABLE_CREDIT_COUNT"),
        }
        for suffix, on in gates.items():
            if on:
                put("MSOP_P{}_{}".format(i, suffix), event_value(suffix, i))
        # DemulShooter aliases (unprefixed output names; not Hooker-mapped -> "false")
        if demul:
            if gates["Recoil"]:    put("P{}_CtmRecoil".format(i), "false")
            if gates["Damage"]:    put("P{}_Damaged".format(i), "false")
            if gates["LampStart"]: put("P{}_CtmLmpStart".format(i), "false")

    # global outputs (present but not Hooker-mapped) + always-on plugin identity/aspect
    put("MSOP_Credits", "false")
    put("MSOP_GameStatus", "false")
    put("MSOP_AttractStatus", "false")
    put("MSOP_GlobalCreditsInserted", "false")
    put("MSOP_LuaVersion", "false")
    put("MSOP_LuaDate", "false")
    put("MSOP_LuaROMid", "false")
    put("System_AspectRatio", "AspectRatio_4_3")

    # native driver outputs the plugin forwards verbatim (raw MAME output names, no MSOP_ prefix):
    # the union of database_driver.lua's scraped list for this ROM and the game's hand-curated
    # ADDITIONAL_OUTPUT_FORWARDS. Present-but-unmapped -> "false" (not Hooker event vocabulary);
    # a pre-existing key (e.g. an MSOP_ output) is never overwritten by a same-named native.
    for native_name in list(natives or []) + list(game.get("ADDITIONAL_OUTPUT_FORWARDS", []) or []):
        out.setdefault(native_name, "false")
    return dict(sorted(out.items()))


def supported_roms():
    for name in sorted(os.listdir(DB_GAMES)):
        if name.endswith(".json") and not name.startswith("_"):
            yield name[:-5]


def main():
    preview = "--preview" in sys.argv
    only = None
    if "--rom" in sys.argv:
        only = sys.argv[sys.argv.index("--rom") + 1]

    default = json.load(open(os.path.join(DB_GAMES, "_default.json"), encoding="utf-8"))
    natives = load_driver_natives()
    if not natives:
        print("NOTE: {} not found - native driver outputs will be omitted.".format(
            os.path.normpath(DRIVER_LUA)), file=sys.stderr)
    if not preview:
        os.makedirs(OUT_DIR, exist_ok=True)

    written = 0
    for rom in supported_roms():
        if only and rom != only:
            continue
        game = json.load(open(os.path.join(DB_GAMES, rom + ".json"), encoding="utf-8"))
        outputs = build_outputs(game, default, natives.get(rom, []))
        if preview or only:
            print("--- {} ({} outputs) ---".format(rom, len(outputs)))
            print(json.dumps(outputs, indent=2))
        if not preview:
            with open(os.path.join(OUT_DIR, rom + ".json"), "w", encoding="utf-8") as f:
                json.dump(outputs, f, indent=2)
            written += 1

    if not preview:
        print("\nGenerated {} MAME_MSOP_Plugin JSON files.".format(written))


if __name__ == "__main__":
    main()
