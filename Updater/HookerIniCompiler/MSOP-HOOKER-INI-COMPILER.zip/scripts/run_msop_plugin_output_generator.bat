@echo off
REM MSOP Plugin Output Generator - launcher (Windows)
REM %~dp0 = this scripts\ folder, so it works regardless of the current
REM working directory.

python "%~dp0msop_plugin_output_generator.py"
if errorlevel 1 goto :error

echo.
echo Done.
pause
exit /b 0

:error
echo.
echo Compile failed - see the output above.
pause
exit /b 1
