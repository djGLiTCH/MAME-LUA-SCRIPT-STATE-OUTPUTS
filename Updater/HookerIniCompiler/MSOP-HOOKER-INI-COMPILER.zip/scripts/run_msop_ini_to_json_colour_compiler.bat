@echo off
REM MSOP INI to JSON Colours Compiler - launcher (Windows)
REM %~dp0 = this scripts\ folder, so it works regardless of the current
REM working directory.

echo === Converting INI to JSON ===
python "%~dp0msop_ini_to_json_colour_compiler.py"
if errorlevel 1 goto :error

echo.
echo Done.
pause
exit /b 0

:error
echo.
echo Compile failed - see the output above.
pause
exit /b 1
