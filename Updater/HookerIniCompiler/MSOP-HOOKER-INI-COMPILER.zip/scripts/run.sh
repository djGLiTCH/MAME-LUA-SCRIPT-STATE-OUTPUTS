#!/usr/bin/env bash
# MSOP Hooker INI Compiler - launcher (Linux/macOS)
# Paths are resolved from this script's own location, so it works regardless
# of the current working directory.
set -e

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PY="$(command -v python3 || command -v python)"

echo "=== Compiling INI (input/games/*.json -> build/ini/*.ini) ==="
"$PY" "$DIR/msop_hooker_ini_compiler.py"

echo
echo "Done."
