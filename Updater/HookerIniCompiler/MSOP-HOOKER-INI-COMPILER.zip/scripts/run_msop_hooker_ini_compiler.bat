@echo off
REM MSOP Hooker INI Compiler - launcher (Windows)
REM %~dp0 = this scripts\ folder, so it works regardless of the current
REM working directory.

echo === Compiling INI (input\games\*.json -^> output\ini\*.ini) ===
python "%~dp0msop_hooker_ini_compiler.py"
if errorlevel 1 goto :error

echo.
echo Done.
pause
exit /b 0

:error
echo.
echo Compile failed - see the output above.
pause
exit /b 1
