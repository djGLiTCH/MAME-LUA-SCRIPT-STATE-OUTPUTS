@echo off
echo Starting script...
python msop_hooker_ini_compiler.py
pause